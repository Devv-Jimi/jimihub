const colors = require('tailwindcss/colors');

const alphaVar = (type, value) => `rgb(var(--color-${type}-${value}) / <alpha-value>)`;
const variableColors = (type) =>
    [50, 100, 200, 300, 400, 500, 600, 700, 800, 900].reduce(
        (obj, item) => ({ ...obj, [item]: alphaVar(type, item) }),
        {}
    );

module.exports = {
    content: ['./resources/scripts/**/*.{js,ts,tsx}'],
    theme: {
        extend: {
            fontFamily: {
                sans: ['Inter', '"Helvetica Neue"', 'Helvetica', 'Arial', 'sans-serif'],
                header: ['Poppins', '"Helvetica Neue"', 'Helvetica', 'Arial', 'sans-serif'],
                mono: [
                    '"JetBrains Mono"',
                    'ui-monospace',
                    'SFMono-Regular',
                    'Menlo',
                    'Monaco',
                    'Consolas',
                    'monospace',
                ],
            },
            colors: {
                black: '#131a20',
                // "primary" and "neutral" are deprecated, prefer the use of "blue" and "gray"
                // in new code.
                primary: variableColors('blue'),
                blue: variableColors('blue'),
                gray: variableColors('gray'),
                neutral: variableColors('gray'),
                cyan: colors.cyan,
                rose: colors.rose,
            },
            fontSize: {
                '2xs': '0.625rem',
            },
            transitionDuration: {
                250: '250ms',
            },
            borderColor: (theme) => ({
                default: theme('colors.neutral.400', 'currentColor'),
            }),
        },
    },
    plugins: [
        require('@tailwindcss/forms')({
            strategy: 'class',
        }),
    ],
};
