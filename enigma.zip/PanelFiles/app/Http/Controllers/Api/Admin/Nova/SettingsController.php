<?php

namespace Pterodactyl\Http\Controllers\Api\Admin\Nova;

use Pterodactyl\Models\Egg;
use Illuminate\Http\Request;
use Pterodactyl\Models\Setting;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Log;
use Pterodactyl\Transformers\Api\Client\EggTransformer;
use Pterodactyl\Http\Controllers\Api\Admin\AdminApiController;
use Pterodactyl\Contracts\Repository\SettingsRepositoryInterface;
use Pterodactyl\Http\Requests\Api\Admin\Nova\UpdateSettingsRequest;

class SettingsController extends AdminApiController
{
    public function __construct(
        private SettingsRepositoryInterface $settings,
    )
    {
        parent::__construct();
    }

    public function getEggs(Request $request)
    {
        return $this->fractal->collection(Egg::all())
            ->transformWith($this->getTransformer(EggTransformer::class))
            ->toArray();
    }

    public function updateSettings(UpdateSettingsRequest $request): JsonResponse
    {
        foreach ($request->all() as $key => $value) {
            Log::debug("$key => $value");
            $this->settings->set('settings::nova:' . $key, $value);
        }

        return new JsonResponse([], JsonResponse::HTTP_ACCEPTED);
    }

    public function deleteSettings(): JsonResponse
    {
        Setting::all()->each(function (Setting $setting) {
            if (!str_starts_with($setting->key, 'settings::nova:')) return;
            $this->settings->forget($setting->key);
        });

        return new JsonResponse([], JsonResponse::HTTP_NO_CONTENT);
    }
}
