<?php

/*
 * © it's vic! 2024
 * Modification and redistribution, in part or in full, is strictly prohibited.
 */

namespace Pterodactyl\Http\Controllers\Api\Admin\Nova;

use Illuminate\Http\Request;
use Pterodactyl\Services\Helpers\NovaVersionService;
use Pterodactyl\Http\Controllers\Api\Admin\AdminApiController;

class VersionController extends AdminApiController
{
    public function __construct(
        private NovaVersionService $versionService,
    )
    {
        parent::__construct();
    }

    public function handle(Request $request) {
        return [
            'current' => $this->versionService->getCurrentVersion(),
            'latest' => $this->versionService->getLatestVersion(),
            'changelog' => $this->versionService->getChangelog(),
            'error' => $this->versionService->getErrorReason(),
        ];
    }
}
