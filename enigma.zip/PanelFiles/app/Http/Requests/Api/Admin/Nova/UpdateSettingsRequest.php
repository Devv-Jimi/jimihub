<?php

namespace Pterodactyl\Http\Requests\Api\Admin\Nova;

use Pterodactyl\Http\Requests\Api\Admin\AdminApiRequest;

class UpdateSettingsRequest extends AdminApiRequest
{
    public function rules(): array
    {
        $color = 'required|regex:/^#[a-f0-9]{6}$/i';
        return [
            'poweredFooter' => 'required|in:true,false',
            'alert:type' => 'required|in:none,info,success,warning,danger',
            'alert:message' => 'nullable|string',
            'colors:gray:50' => $color,
            'colors:gray:100' => $color,
            'colors:gray:200' => $color,
            'colors:gray:300' => $color,
            'colors:gray:400' => $color,
            'colors:gray:500' => $color,
            'colors:gray:600' => $color,
            'colors:gray:700' => $color,
            'colors:gray:800' => $color,
            'colors:gray:900' => $color,
            'colors:blue:50' => $color,
            'colors:blue:100' => $color,
            'colors:blue:200' => $color,
            'colors:blue:300' => $color,
            'colors:blue:400' => $color,
            'colors:blue:500' => $color,
            'colors:blue:600' => $color,
            'colors:blue:700' => $color,
            'colors:blue:800' => $color,
            'colors:blue:900' => $color,
            'sidebarLinks:support:name' => 'nullable|string',
            'sidebarLinks:support:url' => 'nullable|string',
            'sidebarLinks:discord:name' => 'nullable|string',
            'sidebarLinks:discord:url' => 'nullable|string',
            'sidebarBlurred' => 'required|in:true,false',
            'header' => 'required|in:text,icon,wordmark',
            'icon' => 'nullable|string',
            'wordmark' => 'nullable|string',
            'backgroundStyle' => 'required|in:simple,fade',
            'backgrounds' => 'required|json',
        ];
    }
}
