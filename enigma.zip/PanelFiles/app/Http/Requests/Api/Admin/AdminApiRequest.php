<?php

namespace Pterodactyl\Http\Requests\Api\Admin;

use Illuminate\Foundation\Http\FormRequest;

/**
 * @method \Pterodactyl\Models\User user($guard = null)
 */
class AdminApiRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()->root_admin;
    }
}
