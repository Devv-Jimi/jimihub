<?php

/*
 * This service is used for collecting Nova version information.
 * 
 * © it's vic! 2024
 * Modification and redistribution, in part or in full, is strictly prohibited.
 */

namespace Pterodactyl\Services\Helpers;

use GuzzleHttp\Client;
use Carbon\CarbonImmutable;
use Illuminate\Support\Arr;
use Illuminate\Contracts\Cache\Repository as CacheRepository;

class NovaVersionService
{
    private static array $result;

    public function __construct(
        protected CacheRepository $cache,
        protected Client $client
    ) {
        self::$result = $this->cacheVersionData();
    }

    public function getLatestVersion(): string
    {
        return Arr::get(self::$result, 'latest') ?? 'error';
    }

    public function getCurrentVersion(): string
    {
        return Arr::get(self::$result, 'current') ?? 'error';
    }

    public function getChangelog(): string
    {
        return Arr::get(self::$result, 'changelog') ?? 'error';
    }

    public function getErrorReason(): int
    {
        return Arr::get(self::$result, 'error') ?? 1;
    }

    protected function cacheVersionData() {
        return $this->cache->remember('nova:versionData', CarbonImmutable::now()->addMinutes(5), function() {
            try {
                $response = $this->client->request('POST', 'https://vanilla.getnova.zip/api/versions', [
                    'json' => [
                        'url' => config('app.url'),
                        'hn' => gethostname(),
                    ],
                ]);

                if ($response->getStatusCode() === 200) {
                    return json_decode($response->getBody(), true);
                }

                throw new \Exception();
            }
            catch (\Exception) {
                return [];
            }
        });
    }
}
