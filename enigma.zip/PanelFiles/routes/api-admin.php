<?php

use Illuminate\Support\Facades\Route;
use Pterodactyl\Http\Controllers\Api\Admin;

Route::group(['prefix' => '/nova'], function () {
    Route::get('/version', [Admin\Nova\VersionController::class, 'handle']);

    Route::get('/eggs', [Admin\Nova\SettingsController::class, 'getEggs']);

    Route::post('/settings', [Admin\Nova\SettingsController::class, 'updateSettings']);
    Route::delete('/settings', [Admin\Nova\SettingsController::class, 'deleteSettings']);
});
