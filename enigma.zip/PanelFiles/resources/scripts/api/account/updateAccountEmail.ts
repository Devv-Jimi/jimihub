import http from '@/api/http';

export default (
    firstName: string,
    lastName: string,
    username: string,
    email: string,
    password: string
): Promise<void> => {
    return new Promise((resolve, reject) => {
        http.put('/api/client/account/email', { name_first: firstName, name_last: lastName, username, email, password })
            .then(() => resolve())
            .catch(reject);
    });
};
