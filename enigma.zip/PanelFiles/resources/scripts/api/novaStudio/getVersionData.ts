import http from '@/api/http';

export enum VersionErrorCode {
    NONE,
    UNKNOWN,
    VERSION_FETCH_FAILED = 1000,
    VERSION_FETCH_FAILED_2,
}

export const humanVersionErrors: Record<VersionErrorCode, string> = {
    [VersionErrorCode.NONE]: '',
    [VersionErrorCode.UNKNOWN]: 'An error occurred while trying to reach our servers. They may be currently offline.',
    [VersionErrorCode.VERSION_FETCH_FAILED]:
        "Couldn't get the version data. Are you sure you installed Nova correctly?",
    [VersionErrorCode.VERSION_FETCH_FAILED_2]:
        "Couldn't get the version data. Are you sure you installed Nova correctly?",
};

export interface VersionData {
    current: string;
    latest: string;
    changelog: string;
    error: VersionErrorCode;
}

export default (): Promise<VersionData> => {
    return new Promise((resolve, reject) =>
        http
            .get('/api/admin/nova/version')
            .then((resp) => resolve(resp.data))
            .catch(reject)
    );
};
