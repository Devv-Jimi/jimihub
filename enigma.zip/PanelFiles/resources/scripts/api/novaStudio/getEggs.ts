import http from '@/api/http';

export interface Egg {
    internalId: number;
    uuid: string;
    name: string;
}

export const rawDataToEgg = (data: any): Egg => ({
    internalId: data.internal_id,
    uuid: data.uuid,
    name: data.name,
});

export default (): Promise<Egg[]> => {
    return new Promise((resolve, reject) => {
        http.get('/api/admin/nova/eggs')
            .then(({ data }) => resolve((data.data || []).map((d: any) => rawDataToEgg(d.attributes))))
            .catch(reject);
    });
};
