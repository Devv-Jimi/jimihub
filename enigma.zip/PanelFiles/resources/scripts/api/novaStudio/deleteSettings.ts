import http from '@/api/http';

export default (): Promise<void> => {
    return new Promise((resolve, reject) => {
        http.delete(`/api/admin/nova/settings`)
            .then(() => resolve())
            .catch(reject);
    });
};
