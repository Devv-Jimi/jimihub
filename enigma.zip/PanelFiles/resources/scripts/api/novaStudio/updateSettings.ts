import http from '@/api/http';
import { ThemeData, toRawTheme } from '@/state/themeData';

function flattenData(data: Record<string, any>, prefix = '') {
    let flattenedData: Record<string, any> = {};

    Object.keys(data).forEach((key) => {
        if (typeof data[key] === 'object') {
            flattenedData = {
                ...flattenedData,
                ...flattenData(data[key], prefix + key + ':'),
            };
        } else if (typeof data[key] === 'boolean') {
            flattenedData[prefix + key] = String(data[key]);
        } else {
            flattenedData[prefix + key] = data[key];
        }
    });

    return flattenedData;
}

export default (data: ThemeData): Promise<void> => {
    // we need to flatten theme data
    const flattenedData = flattenData(toRawTheme(data));
    return new Promise((resolve, reject) => {
        http.post(`/api/admin/nova/settings`, flattenedData)
            .then(() => resolve())
            .catch(reject);
    });
};
