/* This is a stub file for Blueprint for Nova. */
export const NavigationLinks = () => null;
export const NavigationRouter = () => null;
