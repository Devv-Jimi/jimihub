/* This is a stub file for Blueprint for Nova. */
export default () => null;
