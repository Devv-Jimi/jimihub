import React, { useEffect, useState } from 'react';
import TransitionRouter from '@/TransitionRouter';
import Spinner from '@/components/elements/Spinner';
import { Route, Switch, useLocation } from 'react-router';
import { NotFound } from '@/components/elements/ScreenBlock';
import routes from '@/routers/routes';
import NovaSidebar from '@/components/novaStudio/NovaSidebar';
import { NavLink } from 'react-router-dom';
import { NovaStudioContext } from '@/state/novaStudio';
import { State, useStoreState } from 'easy-peasy';
import { ApplicationStore } from '@/state';
import PreviewPane from '@/components/novaStudio/PreviewPane';
import { Panel, PanelGroup, PanelResizeHandle } from 'react-resizable-panels';
import styles from './styles.module.css';
import classNames from 'classnames';

const MakeSureContextHasEditedData = () => {
    const themeData = useStoreState((state: State<ApplicationStore>) => state.themeData.data);
    const editedData = NovaStudioContext.useStoreState((state) => state.editedData);
    const setEdited = NovaStudioContext.useStoreActions((actions) => actions.setEdited);
    const setEditedData = NovaStudioContext.useStoreActions((actions) => actions.setEditedData);

    if (themeData && !editedData) {
        setEditedData(themeData);
        setEdited(false);
    }

    return null;
};

export default () => {
    const location = useLocation();

    const [width, setWidth] = useState(window.innerWidth);
    useEffect(() => {
        const handleResize = () => setWidth(window.innerWidth);
        window.addEventListener('resize', handleResize);
        return () => window.removeEventListener('resize', handleResize);
    }, []);

    return (
        <NovaStudioContext.Provider>
            <MakeSureContextHasEditedData />
            <div className='flex w-full min-h-screen'>
                <NovaSidebar>
                    {routes.novaStudio
                        .filter((route) => !!route.name)
                        .map(({ path, name, exact = false, icon: Icon }) => (
                            <NavLink key={path} to={`/admin/nova/${path}`.replace('//', '/')} exact={exact}>
                                {Icon && <Icon />}
                                {name}
                            </NavLink>
                        ))}
                </NovaSidebar>
                <div className='flex-1 max-h-screen px-4 py-16 md:p-12 bg-gradient-to-b from-transparent to-gray-900/30'>
                    <PanelGroup direction={width < 1280 ? 'vertical' : 'horizontal'} autoSaveId='novaPreviewPanels'>
                        <Panel minSize={width < 1280 ? 0 : 25} className='pb-4 xl:pr-4'>
                            <TransitionRouter containerClassName='h-full'>
                                <React.Suspense fallback={<Spinner centered />}>
                                    <Switch location={location}>
                                        {routes.novaStudio.map(({ path, component: Component }) => (
                                            <Route key={path} path={`/admin/nova/${path}`.replace('//', '/')} exact>
                                                <Component />
                                            </Route>
                                        ))}
                                        <Route path={'*'}>
                                            <NotFound />
                                        </Route>
                                    </Switch>
                                </React.Suspense>
                            </TransitionRouter>
                        </Panel>
                        <PanelResizeHandle className={styles.resizeHandle}>
                            <div className={styles.dot} />
                            <div className={classNames(styles.dot, styles.mainDot)} />
                            <div className={styles.dot} />
                        </PanelResizeHandle>
                        <Panel collapsible={true} className='pt-4 xl:pl-4'>
                            <PreviewPane />
                        </Panel>
                    </PanelGroup>
                </div>
            </div>
        </NovaStudioContext.Provider>
    );
};
