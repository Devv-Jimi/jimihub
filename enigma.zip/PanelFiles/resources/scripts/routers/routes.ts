import React, { lazy } from 'react';
import ServerConsole from '@/components/server/console/ServerConsoleContainer';
import DatabasesContainer from '@/components/server/databases/DatabasesContainer';
import ScheduleContainer from '@/components/server/schedules/ScheduleContainer';
import UsersContainer from '@/components/server/users/UsersContainer';
import BackupContainer from '@/components/server/backups/BackupContainer';
import NetworkContainer from '@/components/server/network/NetworkContainer';
import StartupContainer from '@/components/server/startup/StartupContainer';
import FileManagerContainer from '@/components/server/files/FileManagerContainer';
import SettingsContainer from '@/components/server/settings/SettingsContainer';
import AccountOverviewContainer from '@/components/dashboard/AccountOverviewContainer';
import AccountApiContainer from '@/components/dashboard/AccountApiContainer';
import AccountSSHContainer from '@/components/dashboard/ssh/AccountSSHContainer';
import ActivityLogContainer from '@/components/dashboard/activity/ActivityLogContainer';
import ServerActivityLogContainer from '@/components/server/ServerActivityLogContainer';
import NovaSettingsPage from '@/components/novaStudio/settings/NovaSettingsPage';
import ColorsPage from '@/components/novaStudio/colors/ColorsPage';
import AlertsPage from '@/components/novaStudio/alerts/AlertsPage';
import SidebarPage from '@/components/novaStudio/sidebar/SidebarPage';
import BackgroundsPage from '@/components/novaStudio/backgrounds/BackgroundsPage';
import {
    ArchiveBoxIcon,
    CalendarDaysIcon,
    CircleStackIcon,
    ClipboardDocumentListIcon,
    CodeBracketIcon,
    Cog6ToothIcon,
    CommandLineIcon,
    FolderIcon,
    GlobeAltIcon,
    KeyIcon,
    MegaphoneIcon,
    PhotoIcon,
    PowerIcon,
    SwatchIcon,
    UserCircleIcon,
    UserGroupIcon,
    ViewColumnsIcon,
} from '@heroicons/react/24/solid';
import { Condition } from '@/lib/nova/conditions';

// [*] Uncomment the import below if you want to use conditions!
// import { isNest, isEgg, and, or } from '@/lib/nova/conditions';

// Each of the router files is already code split out appropriately — so
// all of the items above will only be loaded in when that router is loaded.
//
// These specific lazy loaded routes are to avoid loading in heavy screens
// for the server dashboard when they're only needed for specific instances.
const FileEditContainer = lazy(() => import('@/components/server/files/FileEditContainer'));
const ScheduleEditContainer = lazy(() => import('@/components/server/schedules/ScheduleEditContainer'));

interface RouteDefinition {
    path: string;
    // If undefined is passed this route is still rendered into the router itself
    // but no navigation link is displayed in the sub-navigation menu.
    name: string | undefined;
    component: React.ComponentType;
    icon?: React.ComponentType;
    exact?: boolean;
    condition?: Condition;
}

interface ServerRouteDefinition extends RouteDefinition {
    permission: string | string[] | null;
}

interface Routes {
    // All of the routes available under "/account"
    account: RouteDefinition[];
    // All of the routes available under "/server/:id"
    server: ServerRouteDefinition[];
    // All of the routes available under "/admin/nova"
    novaStudio: RouteDefinition[];
}

/**
 *     _   __
 *    / | / /___ _   ______ _
 *   /  |/ / __ \ | / / __ `/
 *  / /|  / /_/ / |/ / /_/ /
 * /_/ |_/\____/|___/\__,_/
 *
 *     == Route guide ==
 *
 * Nova replaces the traditional eggids/nestids system with route conditions.
 * You may have to uncomment the import from '@/lib/nova/conditions' first.
 * Here's a quick how-to on how to use them:
 *
 * Whenever you're instructed to add:
 *   eggids: [12, 34],
 * Instead, add:
 *   condition: isEgg(12, 34),
 *
 * Whenever you're instructed to add:
 *   nestids: [12, 34],
 * Instead, add:
 *   condition: isNest(12, 34),
 *
 * If you want to combine multiple conditions together, it's very easy to do so.
 * For example, to show a route only on servers with a nest ID of 1 and an egg ID of 2:
 *   condition: and(isNest(1), isEgg(2)),
 * Likewise, to show a route on servers with a nest ID of 1 /or/ with an egg ID of 2:
 *   condition: or(isNest(1), isEgg(2)),
 *
 * [*] If you want to create your own conditions, it is very easy to do so.
 * Conditions are functions that take in no arguments and which return a boolean.
 *
 * You can use any React hooks in a condition. For example, to show a route only on
 * servers whose name starts with an 'A', you could use the following condition:
 *  const onlyAs = () => ServerContext.useStoreState((state) => state.server.data?.name)?.startsWith('A') ?? false;
 * Then you can add this condition onto any route:
 *   condition: onlyAs,
 */

export default {
    account: [
        {
            path: '/',
            name: 'Account',
            component: AccountOverviewContainer,
            exact: true,
            icon: UserCircleIcon,
        },
        {
            path: '/api',
            name: 'API Credentials',
            component: AccountApiContainer,
            icon: CodeBracketIcon,
        },
        {
            path: '/ssh',
            name: 'SSH Keys',
            component: AccountSSHContainer,
            icon: KeyIcon,
        },
        {
            path: '/activity',
            name: 'Activity',
            component: ActivityLogContainer,
            icon: ClipboardDocumentListIcon,
        },
    ],
    server: [
        {
            path: '/',
            permission: null,
            name: 'Console',
            component: ServerConsole,
            exact: true,
            icon: CommandLineIcon,
        },
        {
            path: '/files',
            permission: 'file.*',
            name: 'Files',
            component: FileManagerContainer,
            icon: FolderIcon,
        },
        {
            path: '/files/:action(edit|new)',
            permission: 'file.*',
            name: undefined,
            component: FileEditContainer,
        },
        {
            path: '/databases',
            permission: 'database.*',
            name: 'Databases',
            component: DatabasesContainer,
            icon: CircleStackIcon,
        },
        {
            path: '/schedules',
            permission: 'schedule.*',
            name: 'Schedules',
            component: ScheduleContainer,
            icon: CalendarDaysIcon,
        },
        {
            path: '/schedules/:id',
            permission: 'schedule.*',
            name: undefined,
            component: ScheduleEditContainer,
        },
        {
            path: '/users',
            permission: 'user.*',
            name: 'Users',
            component: UsersContainer,
            icon: UserGroupIcon,
        },
        {
            path: '/backups',
            permission: 'backup.*',
            name: 'Backups',
            component: BackupContainer,
            icon: ArchiveBoxIcon,
        },
        {
            path: '/network',
            permission: 'allocation.*',
            name: 'Network',
            component: NetworkContainer,
            icon: GlobeAltIcon,
        },
        {
            path: '/startup',
            permission: 'startup.*',
            name: 'Startup',
            component: StartupContainer,
            icon: PowerIcon,
        },
        {
            path: '/settings',
            permission: ['settings.*', 'file.sftp'],
            name: 'Settings',
            component: SettingsContainer,
            icon: Cog6ToothIcon,
        },
        {
            path: '/activity',
            permission: 'activity.*',
            name: 'Activity',
            component: ServerActivityLogContainer,
            icon: ClipboardDocumentListIcon,
        },
    ],
    novaStudio: [
        {
            path: '/',
            name: 'General Settings',
            component: NovaSettingsPage,
            icon: Cog6ToothIcon,
            exact: true,
        },
        {
            path: '/colors',
            name: 'Colors',
            component: ColorsPage,
            icon: SwatchIcon,
        },
        {
            path: '/alerts',
            name: 'Alerts',
            component: AlertsPage,
            icon: MegaphoneIcon,
        },
        {
            path: '/sidebar',
            name: 'Sidebar',
            component: SidebarPage,
            icon: ViewColumnsIcon,
        },
        {
            path: '/backgrounds',
            name: 'Backgrounds',
            component: BackgroundsPage,
            icon: PhotoIcon,
        },
    ],
} as Routes;
