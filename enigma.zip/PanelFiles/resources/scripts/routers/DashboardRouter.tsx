import React from 'react';
import { NavLink, Route, Switch } from 'react-router-dom';
import DashboardContainer from '@/components/dashboard/DashboardContainer';
import { NotFound } from '@/components/elements/ScreenBlock';
import TransitionRouter from '@/TransitionRouter';
import { useLocation } from 'react-router';
import Spinner from '@/components/elements/Spinner';
import routes from '@/routers/routes';
import Sidebar from '@/components/Sidebar';
import { evalCondition } from '@/lib/nova/conditions';
import BackgroundDisplay from '@/components/elements/backgrounds/BackgroundDisplay';

import { NavigationLinks, NavigationRouter } from '@/blueprint/extends/routers/DashboardRouter';
import BeforeSubNavigation from '@/blueprint/components/Navigation/SubNavigation/BeforeSubNavigation';
import AdditionalAccountItems from '@/blueprint/components/Navigation/SubNavigation/AdditionalAccountItems';
import AfterSubNavigation from '@/blueprint/components/Navigation/SubNavigation/AfterSubNavigation';

export default () => {
    const location = useLocation();

    return (
        <>
            <BackgroundDisplay />
            <div className='flex w-full min-h-screen'>
                <Sidebar>
                    {location.pathname.startsWith('/account') && (
                        <>
                            <BeforeSubNavigation />
                            <h3>Account Settings</h3>
                            {routes.account
                                .filter((route) => !!route.name)
                                .filter((route) => evalCondition(route.condition))
                                .map(({ path, name, exact = false, icon: Icon }) => (
                                    <NavLink key={path} to={`/account/${path}`.replace('//', '/')} exact={exact}>
                                        {Icon && <Icon />}
                                        {name}
                                    </NavLink>
                                ))}
                            <NavigationLinks />
                            <AdditionalAccountItems />
                            <AfterSubNavigation />
                        </>
                    )}
                </Sidebar>
                <div className='relative flex-1 max-h-screen overflow-auto'>
                    <TransitionRouter>
                        <React.Suspense fallback={<Spinner centered />}>
                            <Switch location={location}>
                                <Route path={'/'} exact>
                                    <DashboardContainer />
                                </Route>
                                {routes.account
                                    .filter((route) => evalCondition(route.condition))
                                    .map(({ path, component: Component }) => (
                                        <Route key={path} path={`/account/${path}`.replace('//', '/')} exact>
                                            <Component />
                                        </Route>
                                    ))}
                                <Route path={'*'}>
                                    <NotFound />
                                </Route>
                                <NavigationRouter />
                            </Switch>
                        </React.Suspense>
                    </TransitionRouter>
                </div>
            </div>
        </>
    );
};
