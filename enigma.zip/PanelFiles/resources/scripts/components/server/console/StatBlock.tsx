import React from 'react';
import Icon from '@/components/elements/Icon';
import { IconDefinition } from '@fortawesome/free-solid-svg-icons';
import classNames from 'classnames';
import styles from './style.module.css';
import useFitText from 'use-fit-text';
import CopyOnClick from '@/components/elements/CopyOnClick';

type StatBlockProps = {
    title: string;
    copyOnClick?: string;
    alert?: null | 'warning' | 'error';
    children: React.ReactNode;
    background?: React.ReactNode;
    legend?: React.ReactNode;
} & (
    | {
          isFA?: false;
          icon: React.ReactNode;
      }
    | {
          isFA: true;
          icon: IconDefinition;
      }
);

export default ({ title, copyOnClick, children, alert, background, legend, ...props }: StatBlockProps) => {
    const { fontSize, ref } = useFitText({ minFontSize: 8, maxFontSize: 500 });

    return (
        <CopyOnClick text={copyOnClick}>
            <div className={classNames(styles.stat_block, 'relative overflow-hidden bg-gray-700')}>
                {background && <div className='pointer-events-none'>{background}</div>}
                <div
                    className={classNames(
                        'flex flex-col justify-between gap-4 z-10 px-6 py-4',
                        background && 'absolute top-0 left-0 w-full h-full'
                    )}
                >
                    <div className='flex justify-between items-start'>
                        <div
                            className={classNames(
                                'flex items-center gap-2 transition-[color,background-color,box-shadow] pl-4 pr-5 py-2 -ml-4 -my-2 rounded-full',
                                !alert && 'text-gray-300',
                                alert === 'warning' && 'shadow bg-amber-700 text-amber-200 font-semibold',
                                alert === 'error' && 'shadow bg-red-800 text-red-200 font-semibold'
                            )}
                        >
                            <div className={classNames(styles.icon, 'w-6 h-6')}>
                                {props.isFA ? <Icon icon={props.icon} /> : props.icon}
                            </div>
                            <span className='font-header'>{title}</span>
                        </div>
                        {legend}
                    </div>
                    <div
                        className={classNames(
                            'max-h-8 w-full font-semibold truncate transition-colors',
                            !alert && 'text-gray-100',
                            alert === 'warning' && 'text-amber-50',
                            alert === 'error' && 'text-red-50'
                        )}
                        ref={ref}
                        style={{ fontSize }}
                    >
                        {children}
                    </div>
                </div>
            </div>
        </CopyOnClick>
    );
};
