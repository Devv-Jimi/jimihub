import ServerContentBlock from '@/components/elements/ServerContentBlock';
import PowerButtons from '@/components/server/console/PowerButtons';
import Features from '@feature/Features';
import { ServerContext } from '@/state/server';
import React from 'react';
import isEqual from 'react-fast-compare';
import { Alert } from '@/components/elements/alert';
import ServerDetailsBlock from '@/components/server/console/ServerDetailsBlock';
import Console from '@/components/server/console/Console';
import PageHeader from '@/components/elements/PageHeader';

import BeforeContent from '@/blueprint/components/Server/Terminal/BeforeContent';
import AfterContent from '@/blueprint/components/Server/Terminal/AfterContent';

export type PowerAction = 'start' | 'stop' | 'restart' | 'kill';

export default () => {
    const name = ServerContext.useStoreState((state) => state.server.data!.name);
    const description = ServerContext.useStoreState((state) => state.server.data!.description);
    const eggFeatures = ServerContext.useStoreState((state) => state.server.data!.eggFeatures, isEqual);
    const isInstalling = ServerContext.useStoreState((state) => state.server.isInstalling);
    const isTransferring = ServerContext.useStoreState((state) => state.server.data!.isTransferring);
    const isNodeUnderMaintenance = ServerContext.useStoreState((state) => state.server.data!.isNodeUnderMaintenance);

    return (
        <ServerContentBlock title={'Console'} className='max-w-7xl mx-auto'>
            <PageHeader title={name} className='mb-4' renderRight={<PowerButtons className='grid grid-cols-3 gap-1' />}>
                {description && <p className={'text-sm mt-1'}>{description}</p>}
            </PageHeader>

            {(isNodeUnderMaintenance || isInstalling || isTransferring) && (
                <Alert type='warning' className='mb-4'>
                    {isNodeUnderMaintenance
                        ? 'The node that this server is hosted on is currently under maintenance and all actions are unavailable.'
                        : isInstalling
                        ? 'This server is currently being installed and most actions are unavailable.'
                        : 'This server is currently being transferred to another node and all actions are unavailable.'}
                </Alert>
            )}

            <BeforeContent />
            <div className='flex flex-col-reverse xl:flex-col gap-4'>
                <ServerDetailsBlock />
                <Console />
            </div>
            <AfterContent />

            <Features enabled={eggFeatures} />
        </ServerContentBlock>
    );
};
