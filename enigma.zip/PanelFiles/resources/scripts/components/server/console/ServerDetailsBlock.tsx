import UptimeDuration from '@/components/server/UptimeDuration';
import StatBlock from '@/components/server/console/StatBlock';
import StatGraphs from '@/components/server/console/StatGraphs';
import { SocketRequest, SocketEvent } from '@/components/server/events';
import { ip } from '@/lib/formatters';
import { capitalize } from '@/lib/strings';
import useWebsocketEvent from '@/plugins/useWebsocketEvent';
import { ServerContext } from '@/state/server';
import { ClockIcon, WifiIcon } from '@heroicons/react/24/solid';
import React, { useEffect, useState } from 'react';

import BeforeInformation from '@/blueprint/components/Server/Terminal/BeforeInformation';
import AfterInformation from '@/blueprint/components/Server/Terminal/AfterInformation';

type Stats = Record<'uptime', number>;

export default () => {
    const [stats, setStats] = useState<Stats>({ uptime: 0 });

    const status = ServerContext.useStoreState((state) => state.status.value);
    const connected = ServerContext.useStoreState((state) => state.socket.connected);
    const instance = ServerContext.useStoreState((state) => state.socket.instance);

    useEffect(() => {
        if (!connected || !instance) {
            return;
        }

        instance.send(SocketRequest.SEND_STATS);
    }, [instance, connected]);

    useWebsocketEvent(SocketEvent.STATS, (data) => {
        let stats: any = {};
        try {
            stats = JSON.parse(data);
        } catch (e) {
            return;
        }

        setStats({
            uptime: stats.uptime || 0,
        });
    });

    const allocation = ServerContext.useStoreState((state) => {
        const match = state.server.data!.allocations.find((allocation) => allocation.isDefault);

        return !match ? 'n/a' : `${match.alias || ip(match.ip)}:${match.port}`;
    });

    return (
        <div className='flex flex-col gap-4'>
            <div className='grid grid-cols-1 sm:grid-cols-2 gap-4'>
                <BeforeInformation />
                <StatBlock icon={<WifiIcon />} title='Address' copyOnClick={allocation}>
                    {allocation}
                </StatBlock>
                <StatBlock icon={<ClockIcon />} title='Uptime'>
                    {status === null ? (
                        'Offline'
                    ) : stats.uptime > 0 ? (
                        <UptimeDuration uptime={stats.uptime / 1000} />
                    ) : (
                        capitalize(status)
                    )}
                </StatBlock>
                <AfterInformation />
            </div>
            <div className='grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4'>
                <StatGraphs />
            </div>
        </div>
    );
};
