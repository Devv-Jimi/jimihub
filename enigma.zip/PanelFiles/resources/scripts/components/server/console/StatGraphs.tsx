import React, { useEffect, useMemo, useRef, useState } from 'react';
import { ServerContext } from '@/state/server';
import { SocketEvent } from '@/components/server/events';
import useWebsocketEvent from '@/plugins/useWebsocketEvent';
import { Line } from 'react-chartjs-2';
import { useChart, useChartTickLabel } from '@/components/server/console/chart';
import { hexToRgba } from '@/lib/helpers';
import { bytesToString, mbToBytes } from '@/lib/formatters';
import { CloudArrowDownIcon, CloudArrowUpIcon } from '@heroicons/react/20/solid';
import { theme } from 'twin.macro';
import Tooltip from '@/components/elements/tooltip/Tooltip';
import { CircleStackIcon, CpuChipIcon, GlobeAltIcon } from '@heroicons/react/24/solid';
import StatBlock from '@/components/server/console/StatBlock';
import { faMemory } from '@fortawesome/free-solid-svg-icons';

const Limit = ({ limit, children }: { limit: string | null; children: React.ReactNode }) => (
    <>
        {children}
        <span className='ml-1 opacity-80 text-[70%]'>/ {limit || <>&infin;</>}</span>
    </>
);

const getAlert = (current: number, limit: number): undefined | 'warning' | 'error' => {
    const delta = current / limit;
    if (delta >= 0.9) return 'error';
    if (delta >= 0.8) return 'warning';
    return undefined;
};

type Stats = Record<'memory' | 'cpu' | 'disk' | 'uptime' | 'rx' | 'tx', number>;

export default () => {
    const status = ServerContext.useStoreState((state) => state.status.value);
    const limits = ServerContext.useStoreState((state) => state.server.data!.limits);
    const previous = useRef<Record<'tx' | 'rx', number>>({ tx: -1, rx: -1 });
    const [stats, setStats] = useState<Stats>({ memory: 0, cpu: 0, disk: 0, uptime: 0, tx: 0, rx: 0 });

    const cpu = useChartTickLabel('CPU', limits.cpu, '%', 2);
    const memory = useChartTickLabel('Memory', limits.memory, 'MiB');
    const disk = useChart('Disk', {
        sets: 1,
        points: 20 * 6,
        options: {
            scales: {
                x: {
                    max: 20 * 6 - 1,
                },
                y: {
                    suggestedMax: limits.disk,
                },
            },
        },
    });
    const network = useChart(
        'Network',
        {
            sets: 2,
            options: {
                scales: {
                    y: {
                        ticks: {
                            callback(value) {
                                return bytesToString(typeof value === 'string' ? parseInt(value, 10) : value);
                            },
                        },
                    },
                },
            },
            callback(opts, index) {
                return {
                    ...opts,
                    label: !index ? 'Network In' : 'Network Out',
                    backgroundColor: hexToRgba(!index ? theme('colors.cyan.500') : theme('colors.yellow.500'), 0.5),
                };
            },
        },
        true
    );

    const textLimits = useMemo(
        () => ({
            cpu: limits?.cpu ? `${limits.cpu}%` : null,
            memory: limits?.memory ? bytesToString(mbToBytes(limits.memory)) : null,
            disk: limits?.disk ? bytesToString(mbToBytes(limits.disk)) : null,
        }),
        [limits]
    );

    useEffect(() => {
        if (status === 'offline') {
            cpu.clear();
            memory.clear();
            disk.clear();
            network.clear();
        }
    }, [status]);

    useWebsocketEvent(SocketEvent.STATS, (data: string) => {
        let values: any = {};
        try {
            values = JSON.parse(data);
        } catch (e) {
            return;
        }
        cpu.push(values.cpu_absolute);
        memory.push(Math.floor(values.memory_bytes / 1024 / 1024));
        disk.push(Math.floor(values.disk_bytes / 1024 / 1024));
        network.push([
            previous.current.tx < 0 ? 0 : Math.max(0, values.network.tx_bytes - previous.current.tx),
            previous.current.rx < 0 ? 0 : Math.max(0, values.network.rx_bytes - previous.current.rx),
        ]);

        previous.current = { tx: values.network.tx_bytes, rx: values.network.rx_bytes };

        setStats({
            memory: values.memory_bytes,
            cpu: values.cpu_absolute,
            disk: values.disk_bytes,
            tx: values.network.tx_bytes,
            rx: values.network.rx_bytes,
            uptime: values.uptime || 0,
        });
    });

    return (
        <>
            <StatBlock
                icon={<CpuChipIcon />}
                title={'CPU load'}
                background={<Line {...cpu.props} />}
                alert={getAlert(stats.cpu, limits.cpu)}
            >
                {status === 'offline' ? 'Offline' : <Limit limit={textLimits.cpu}>{stats.cpu.toFixed(2)}%</Limit>}
            </StatBlock>
            <StatBlock
                isFA
                icon={faMemory}
                title={'Memory'}
                background={<Line {...memory.props} />}
                alert={getAlert(stats.memory / 1000 / 1000, limits.memory)}
            >
                {status === 'offline' ? (
                    'Offline'
                ) : (
                    <Limit limit={textLimits.memory}>{bytesToString(stats.memory)}</Limit>
                )}
            </StatBlock>
            <StatBlock
                icon={<CircleStackIcon />}
                title={'Disk'}
                background={<Line {...disk.props} />}
                alert={getAlert(stats.disk / 1000 / 1000, limits.disk)}
            >
                <Limit limit={textLimits.disk}>{bytesToString(stats.disk)}</Limit>
            </StatBlock>
            <StatBlock
                icon={<GlobeAltIcon />}
                title={'Network'}
                background={<Line {...network.props} />}
                legend={
                    <div className='flex gap-2'>
                        <Tooltip arrow content={'Inbound'}>
                            <CloudArrowDownIcon className={'w-4 h-4 text-yellow-400'} />
                        </Tooltip>
                        <Tooltip arrow content={'Outbound'}>
                            <CloudArrowUpIcon className={'w-4 h-4 text-cyan-400'} />
                        </Tooltip>
                    </div>
                }
            >
                <div className='flex gap-2 justify-between'>
                    <span className='text-yellow-400'>{bytesToString(stats.rx)}</span>
                    <span className='text-cyan-400'>{bytesToString(stats.tx)}</span>
                </div>
            </StatBlock>
        </>
    );
};
