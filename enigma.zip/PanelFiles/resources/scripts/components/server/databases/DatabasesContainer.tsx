import React, { useEffect, useState } from 'react';
import getServerDatabases from '@/api/server/databases/getServerDatabases';
import { ServerContext } from '@/state/server';
import { httpErrorToHuman } from '@/api/http';
import FlashMessageRender from '@/components/FlashMessageRender';
import DatabaseRow from '@/components/server/databases/DatabaseRow';
import Spinner from '@/components/elements/Spinner';
import CreateDatabaseButton from '@/components/server/databases/CreateDatabaseButton';
import Can from '@/components/elements/Can';
import useFlash from '@/plugins/useFlash';
import ServerContentBlock from '@/components/elements/ServerContentBlock';
import { useDeepMemoize } from '@/plugins/useDeepMemoize';
import VicTable from '@/components/elements/table/VicTable';
import PageHeader from '@/components/elements/PageHeader';

import BeforeContent from '@/blueprint/components/Server/Databases/BeforeContent';
import AfterContent from '@/blueprint/components/Server/Databases/AfterContent';

export default () => {
    const uuid = ServerContext.useStoreState((state) => state.server.data!.uuid);
    const databaseLimit = ServerContext.useStoreState((state) => state.server.data!.featureLimits.databases);

    const { addError, clearFlashes } = useFlash();
    const [loading, setLoading] = useState(true);

    const databases = useDeepMemoize(ServerContext.useStoreState((state) => state.databases.data));
    const setDatabases = ServerContext.useStoreActions((state) => state.databases.setDatabases);

    useEffect(() => {
        setLoading(!databases.length);
        clearFlashes('databases');

        getServerDatabases(uuid)
            .then((databases) => setDatabases(databases))
            .catch((error) => {
                console.error(error);
                addError({ key: 'databases', message: httpErrorToHuman(error) });
            })
            .then(() => setLoading(false));
    }, []);

    return (
        <ServerContentBlock title={'Databases'} className='max-w-5xl mx-auto'>
            <PageHeader
                title='Databases'
                renderRight={<Can action={'database.create'}>{databaseLimit > 0 && <CreateDatabaseButton />}</Can>}
            >
                <p className='mt-1'>
                    {databases.length > 0
                        ? databaseLimit > 0 &&
                          `${databases.length} of ${databaseLimit} databases have been allocated to this server.`
                        : databaseLimit > 0
                        ? 'It looks like you have no databases.'
                        : 'Databases cannot be created for this server.'}
                </p>
            </PageHeader>
            <FlashMessageRender byKey={'databases'} className='mt-4' />
            <BeforeContent />
            {!databases.length && loading ? (
                <Spinner size={'large'} centered />
            ) : (
                !!databases.length && (
                    <VicTable className='mt-8'>
                        <thead>
                            <th>{/* Icon */}</th>
                            <th>Name</th>
                            <th className='hidden sm:table-cell'>Endpoint</th>
                            <th className='hidden sm:table-cell'>Username</th>
                            <th>{/* Buttons */}</th>
                        </thead>
                        <tbody>
                            {databases.map((database) => (
                                <DatabaseRow key={database.id} database={database} />
                            ))}
                        </tbody>
                    </VicTable>
                )
            )}
            <AfterContent />
        </ServerContentBlock>
    );
};
