import React, { useState } from 'react';
import { Form, Formik, FormikHelpers } from 'formik';
import Field from '@/components/elements/Field';
import { object, string } from 'yup';
import FlashMessageRender from '@/components/FlashMessageRender';
import { ServerContext } from '@/state/server';
import deleteServerDatabase from '@/api/server/databases/deleteServerDatabase';
import { httpErrorToHuman } from '@/api/http';
import RotatePasswordButton from '@/components/server/databases/RotatePasswordButton';
import Can from '@/components/elements/Can';
import { ServerDatabase } from '@/api/server/databases/getServerDatabases';
import useFlash from '@/plugins/useFlash';
import { Button } from '@/components/elements/button';
import Label from '@/components/elements/Label';
import Input from '@/components/elements/Input';
import CopyOnClick from '@/components/elements/CopyOnClick';
import { CircleStackIcon } from '@heroicons/react/24/solid';
import { EyeIcon, TrashIcon } from '@heroicons/react/20/solid';
import { Dialog } from '@/components/elements/dialog';
import SpinnerOverlay from '@/components/elements/SpinnerOverlay';

interface Props {
    database: ServerDatabase;
}

export default ({ database }: Props) => {
    const uuid = ServerContext.useStoreState((state) => state.server.data!.uuid);
    const { addError, clearFlashes } = useFlash();
    const [visible, setVisible] = useState(false);
    const [connectionVisible, setConnectionVisible] = useState(false);

    const appendDatabase = ServerContext.useStoreActions((actions) => actions.databases.appendDatabase);
    const removeDatabase = ServerContext.useStoreActions((actions) => actions.databases.removeDatabase);

    const jdbcConnectionString = `jdbc:mysql://${database.username}${
        database.password ? `:${encodeURIComponent(database.password)}` : ''
    }@${database.connectionString}/${database.name}`;

    const schema = object().shape({
        confirm: string()
            .required('The database name must be provided.')
            .oneOf([database.name.split('_', 2)[1], database.name], 'The database name must be provided.'),
    });

    const submit = (values: { confirm: string }, { setSubmitting }: FormikHelpers<{ confirm: string }>) => {
        clearFlashes();
        deleteServerDatabase(uuid, database.id)
            .then(() => {
                setVisible(false);
                setTimeout(() => removeDatabase(database.id), 150);
            })
            .catch((error) => {
                console.error(error);
                setSubmitting(false);
                addError({ key: 'database:delete', message: httpErrorToHuman(error) });
            });
    };

    return (
        <>
            <Formik onSubmit={submit} initialValues={{ confirm: '' }} validationSchema={schema} isInitialValid={false}>
                {({ isSubmitting, resetForm, handleSubmit }) => (
                    <Dialog.Confirm
                        open={visible}
                        onClose={() => {
                            setVisible(false);
                            resetForm();
                        }}
                        onConfirmed={() => handleSubmit()}
                        confirm='Delete Database'
                        title='Confirm database deletion'
                    >
                        <SpinnerOverlay visible={isSubmitting} />
                        <FlashMessageRender byKey={'database:delete'} className='mb-4' />
                        <p>
                            Deleting a database is a permanent action, it cannot be undone. This will permanently delete
                            the <strong>{database.name}</strong> database and remove all associated data.
                        </p>
                        <Form className='mt-4'>
                            <Field
                                type={'text'}
                                id={'confirm_name'}
                                name={'confirm'}
                                label={'Confirm Database Name'}
                                description={'Enter the database name to confirm deletion.'}
                            />
                        </Form>
                    </Dialog.Confirm>
                )}
            </Formik>
            <Dialog
                open={connectionVisible}
                onClose={() => setConnectionVisible(false)}
                title='Database connection details'
            >
                <FlashMessageRender byKey={'database-connection-modal'} className='mb-4' />
                <div>
                    <Label>Endpoint</Label>
                    <CopyOnClick text={database.connectionString}>
                        <Input type={'text'} readOnly value={database.connectionString} />
                    </CopyOnClick>
                </div>
                <div className='mt-4'>
                    <Label>Connections from</Label>
                    <Input type={'text'} readOnly value={database.allowConnectionsFrom} />
                </div>
                <div className='mt-4'>
                    <Label>Username</Label>
                    <CopyOnClick text={database.username}>
                        <Input type={'text'} readOnly value={database.username} />
                    </CopyOnClick>
                </div>
                <Can action={'database.view_password'}>
                    <div className='mt-4'>
                        <Label>Password</Label>
                        <CopyOnClick text={database.password} showInNotification={false}>
                            <Input type={'text'} readOnly value={database.password} />
                        </CopyOnClick>
                    </div>
                </Can>
                <div className='mt-4'>
                    <Label>JDBC Connection String</Label>
                    <CopyOnClick text={jdbcConnectionString} showInNotification={false}>
                        <Input type={'text'} readOnly value={jdbcConnectionString} />
                    </CopyOnClick>
                </div>
                <Dialog.Footer>
                    <Can action={'database.update'}>
                        <RotatePasswordButton databaseId={database.id} onUpdate={appendDatabase} />
                    </Can>
                    <Button.Text onClick={() => setConnectionVisible(false)}>Close</Button.Text>
                </Dialog.Footer>
            </Dialog>
            <tr>
                <td className='w-14'>
                    <div className='h-full flex justify-center items-center'>
                        <CircleStackIcon className='w-6 h-6' />
                    </div>
                </td>
                <td>
                    <CopyOnClick text={database.name}>
                        <p>{database.name}</p>
                    </CopyOnClick>
                </td>
                <td className='hidden sm:table-cell'>
                    <CopyOnClick text={database.connectionString}>
                        <p className='text-sm'>{database.connectionString}</p>
                    </CopyOnClick>
                </td>
                <td className='hidden sm:table-cell'>
                    <CopyOnClick text={database.username}>
                        <p className='text-sm'>{database.username}</p>
                    </CopyOnClick>
                </td>
                <td>
                    <div className='flex h-full items-center justify-end gap-2'>
                        <Button.Text
                            shape={Button.Shapes.IconSquare}
                            size={Button.Sizes.Small}
                            variant={Button.Variants.Secondary}
                            onClick={() => setConnectionVisible(true)}
                        >
                            <EyeIcon className='w-5 h-5' />
                        </Button.Text>
                        <Can action={'database.delete'}>
                            <Button.Danger
                                shape={Button.Shapes.IconSquare}
                                size={Button.Sizes.Small}
                                variant={Button.Variants.Secondary}
                                onClick={() => setVisible(true)}
                            >
                                <TrashIcon className='w-5 h-5' />
                            </Button.Danger>
                        </Can>
                    </div>
                </td>
            </tr>
        </>
    );
};
