import React, { useState } from 'react';
import { Form, Formik, FormikHelpers } from 'formik';
import Field from '@/components/elements/Field';
import { object, string } from 'yup';
import createServerDatabase from '@/api/server/databases/createServerDatabase';
import { ServerContext } from '@/state/server';
import { httpErrorToHuman } from '@/api/http';
import FlashMessageRender from '@/components/FlashMessageRender';
import useFlash from '@/plugins/useFlash';
import { Button } from '@/components/elements/button';
import tw from 'twin.macro';
import { Dialog } from '@/components/elements/dialog';
import SpinnerOverlay from '@/components/elements/SpinnerOverlay';

interface Values {
    databaseName: string;
    connectionsFrom: string;
}

const schema = object().shape({
    databaseName: string()
        .required('A database name must be provided.')
        .min(3, 'Database name must be at least 3 characters.')
        .max(48, 'Database name must not exceed 48 characters.')
        .matches(
            /^[\w\-.]{3,48}$/,
            'Database name should only contain alphanumeric characters, underscores, dashes, and/or periods.'
        ),
    connectionsFrom: string().matches(/^[\w\-/.%:]+$/, 'A valid host address must be provided.'),
});

export default () => {
    const uuid = ServerContext.useStoreState((state) => state.server.data!.uuid);
    const { addError, clearFlashes } = useFlash();
    const [visible, setVisible] = useState(false);

    const appendDatabase = ServerContext.useStoreActions((actions) => actions.databases.appendDatabase);

    const submit = (values: Values, { setSubmitting }: FormikHelpers<Values>) => {
        clearFlashes('database:create');
        createServerDatabase(uuid, {
            databaseName: values.databaseName,
            connectionsFrom: values.connectionsFrom || '%',
        })
            .then((database) => {
                appendDatabase(database);
                setVisible(false);
            })
            .catch((error) => {
                addError({ key: 'database:create', message: httpErrorToHuman(error) });
                setSubmitting(false);
            });
    };

    return (
        <>
            <Formik
                onSubmit={submit}
                initialValues={{ databaseName: '', connectionsFrom: '' }}
                validationSchema={schema}
            >
                {({ isSubmitting, resetForm, handleSubmit }) => (
                    <Dialog
                        open={visible}
                        onClose={() => {
                            resetForm();
                            setVisible(false);
                        }}
                        title='Create new database'
                    >
                        <SpinnerOverlay visible={isSubmitting} />
                        <FlashMessageRender byKey={'database:create'} css={tw`mb-6`} />
                        <Form>
                            <Field
                                type={'string'}
                                id={'database_name'}
                                name={'databaseName'}
                                label={'Database name'}
                                description={'A descriptive name for your database instance.'}
                            />
                            <div className='mt-4'>
                                <Field
                                    type={'string'}
                                    id={'connections_from'}
                                    name={'connectionsFrom'}
                                    label={'Connections from'}
                                    description={
                                        'Where connections should be allowed from. Leave blank to allow connections from anywhere.'
                                    }
                                />
                            </div>
                            <Dialog.Footer>
                                <Button.Text type={'button'} onClick={() => setVisible(false)}>
                                    Cancel
                                </Button.Text>
                                <Button onClick={() => handleSubmit()}>Create database</Button>
                            </Dialog.Footer>
                        </Form>
                    </Dialog>
                )}
            </Formik>
            <Button onClick={() => setVisible(true)}>New database</Button>
        </>
    );
};
