import React from 'react';
import { ServerContext } from '@/state/server';
import { useStoreState } from 'easy-peasy';
import RenameServerBox from '@/components/server/settings/RenameServerBox';
import FlashMessageRender from '@/components/FlashMessageRender';
import Can from '@/components/elements/Can';
import ReinstallServerBox from '@/components/server/settings/ReinstallServerBox';
import Input from '@/components/elements/Input';
import Label from '@/components/elements/Label';
import ServerContentBlock from '@/components/elements/ServerContentBlock';
import isEqual from 'react-fast-compare';
import CopyOnClick from '@/components/elements/CopyOnClick';
import { ip } from '@/lib/formatters';
import { Button } from '@/components/elements/button/index';
import HeaderedContent from '@/components/elements/HeaderedContent';

import BeforeContent from '@/blueprint/components/Server/Settings/BeforeContent';
import AfterContent from '@/blueprint/components/Server/Settings/AfterContent';

export default () => {
    const username = useStoreState((state) => state.user.data!.username);
    const id = ServerContext.useStoreState((state) => state.server.data!.id);
    const uuid = ServerContext.useStoreState((state) => state.server.data!.uuid);
    const node = ServerContext.useStoreState((state) => state.server.data!.node);
    const sftp = ServerContext.useStoreState((state) => state.server.data!.sftpDetails, isEqual);

    return (
        <ServerContentBlock title={'Settings'} className='max-w-5xl mx-auto'>
            <h1 className='text-3xl font-bold text-gray-50'>Server Settings</h1>
            <FlashMessageRender byKey={'settings'} className='mt-4' />

            <BeforeContent />

            <Can action={'settings.rename'}>
                <RenameServerBox />
            </Can>

            <Can action={'file.sftp'}>
                <HeaderedContent
                    title='SFTP details'
                    description="You can use apps such as Filezilla or WinSCP to manage your server's files without the browser. Your SFTP password is the same as the password you use to access the panel."
                    className='mt-16'
                >
                    <div>
                        <Label>Server Address</Label>
                        <CopyOnClick text={`sftp://${ip(sftp.ip)}:${sftp.port}`}>
                            <Input type={'text'} value={`sftp://${ip(sftp.ip)}:${sftp.port}`} readOnly />
                        </CopyOnClick>
                    </div>
                    <div className='mt-4'>
                        <Label>Username</Label>
                        <CopyOnClick text={`${username}.${id}`}>
                            <Input type={'text'} value={`${username}.${id}`} readOnly />
                        </CopyOnClick>
                    </div>
                    <div className='mt-6 text-right'>
                        <a href={`sftp://${username}.${id}@${ip(sftp.ip)}:${sftp.port}`}>
                            <Button.Text>Launch SFTP</Button.Text>
                        </a>
                    </div>
                </HeaderedContent>
            </Can>

            <HeaderedContent
                title={'Debug information'}
                description='This information contains details that may be useful for support staff.'
                className='mt-16'
            >
                <div className='text-sm mb-4'>
                    <p className='mb-2'>Node</p>
                    <code className='font-mono bg-gray-700 rounded py-1 px-2'>{node}</code>
                </div>
                <CopyOnClick text={uuid}>
                    <div className='text-sm'>
                        <p className='mb-2'>Server ID</p>
                        <code className='font-mono bg-gray-700 rounded py-1 px-2'>{uuid}</code>
                    </div>
                </CopyOnClick>
            </HeaderedContent>

            <Can action={'settings.reinstall'}>
                <ReinstallServerBox />
            </Can>

            <AfterContent />
        </ServerContentBlock>
    );
};
