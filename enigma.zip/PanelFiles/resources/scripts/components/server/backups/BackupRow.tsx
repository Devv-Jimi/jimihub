import React from 'react';
import { format, formatDistanceToNow } from 'date-fns';
import Spinner from '@/components/elements/Spinner';
import { bytesToString } from '@/lib/formatters';
import Can from '@/components/elements/Can';
import useWebsocketEvent from '@/plugins/useWebsocketEvent';
import BackupContextMenu from '@/components/server/backups/BackupContextMenu';
import getServerBackups from '@/api/swr/getServerBackups';
import { ServerBackup } from '@/api/server/types';
import { SocketEvent } from '@/components/server/events';
import { ArchiveBoxIcon, LockClosedIcon } from '@heroicons/react/20/solid';

interface Props {
    backup: ServerBackup;
}

export default ({ backup }: Props) => {
    const { mutate } = getServerBackups();

    useWebsocketEvent(`${SocketEvent.BACKUP_COMPLETED}:${backup.uuid}` as SocketEvent, (data) => {
        try {
            const parsed = JSON.parse(data);

            mutate(
                (data) => ({
                    ...data,
                    items: data.items.map((b) =>
                        b.uuid !== backup.uuid
                            ? b
                            : {
                                  ...b,
                                  isSuccessful: parsed.is_successful || true,
                                  checksum: (parsed.checksum_type || '') + ':' + (parsed.checksum || ''),
                                  bytes: parsed.file_size || 0,
                                  completedAt: new Date(),
                              }
                    ),
                }),
                false
            );
        } catch (e) {
            console.warn(e);
        }
    });

    return (
        <tr>
            <td className='p-2'>
                {backup.completedAt !== null ? (
                    backup.isLocked ? (
                        <LockClosedIcon className='w-5 h-5 text-amber-500' />
                    ) : (
                        <ArchiveBoxIcon className='w-5 h-5' />
                    )
                ) : (
                    <Spinner size='small' />
                )}
            </td>

            <td>
                <div className='flex flex-col justify-center'>
                    <div className='flex gap-2 items-center'>
                        {backup.name}
                        {backup.completedAt !== null && !backup.isSuccessful && (
                            <span className='bg-red-600 py-px px-2 rounded-full text-red-50 text-xs'>Failed</span>
                        )}
                    </div>
                    <p title={format(backup.createdAt, 'MMMM do, yyyy HH:mm:ss')} className='text-xs'>
                        Created {formatDistanceToNow(backup.createdAt, { includeSeconds: true, addSuffix: true })}
                    </p>
                </div>
            </td>
            <td>{bytesToString(backup.bytes)}</td>
            <td className='text-sm font-mono hidden lg:table-cell'>{backup.checksum}</td>

            <td>
                <Can action={['backup.download', 'backup.restore', 'backup.delete']} matchAny>
                    <div>{backup.completedAt && <BackupContextMenu backup={backup} />}</div>
                </Can>
            </td>
        </tr>
    );
};
