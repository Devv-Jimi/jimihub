import React, { useState } from 'react';
import { Subuser } from '@/state/server/subusers';
import RemoveSubuserButton from '@/components/server/users/RemoveSubuserButton';
import EditSubuserModal from '@/components/server/users/EditSubuserModal';
import Can from '@/components/elements/Can';
import { useStoreState } from 'easy-peasy';
import tw from 'twin.macro';
import Avatar from '@/components/Avatar';
import { LockClosedIcon, LockOpenIcon, PencilIcon } from '@heroicons/react/20/solid';
import Tooltip from '@/components/elements/tooltip/Tooltip';
import { Button } from '@/components/elements/button';

interface Props {
    subuser: Subuser;
}

export default ({ subuser }: Props) => {
    const uuid = useStoreState((state) => state.user!.data!.uuid);
    const [visible, setVisible] = useState(false);

    return (
        <tr>
            <EditSubuserModal subuser={subuser} open={visible} onClose={() => setVisible(false)} />
            <td className='col-start-1 w-10'>
                <div className='size-10 rounded-full overflow-hidden'>
                    {subuser.avatarHash ? (
                        <img src={`/storage/${subuser.avatarHash}`} />
                    ) : (
                        <Avatar name={subuser.uuid} size={10 * 4} />
                    )}
                </div>
            </td>
            <td className='md:pl-4'>
                <p className='font-semibold'>
                    {subuser.firstName} {subuser.lastName}
                </p>
                <p css={tw`text-sm truncate`}>{subuser.email}</p>
            </td>
            <td className='col-start-2 md:pl-8'>
                <Tooltip arrow content={subuser.twoFactorEnabled ? '2FA enabled' : '2FA disabled'}>
                    {subuser.twoFactorEnabled ? (
                        <LockClosedIcon className='w-5 h-5' />
                    ) : (
                        <LockOpenIcon className='w-5 h-5 text-rose-400' />
                    )}
                </Tooltip>
            </td>
            <td className='col-start-2 md:w-full md:pl-8'>
                <p>
                    <span className='font-semibold'>
                        {subuser.permissions.filter((permission) => permission !== 'websocket.connect').length}
                    </span>{' '}
                    permissions
                </p>
            </td>
            {subuser.uuid !== uuid && (
                <td className='col-start-3 row-start-1'>
                    <div className='h-full flex gap-2 justify-end items-center'>
                        <Can action={'user.update'}>
                            <Button.Text
                                type={'button'}
                                aria-label={'Edit subuser'}
                                size={Button.Sizes.Small}
                                variant={Button.Variants.Secondary}
                                shape={Button.Shapes.IconSquare}
                                onClick={() => setVisible(true)}
                            >
                                <PencilIcon className='w-5 h-5' />
                            </Button.Text>
                        </Can>
                        <Can action={'user.delete'}>
                            <RemoveSubuserButton subuser={subuser} />
                        </Can>
                    </div>
                </td>
            )}
        </tr>
    );
};
