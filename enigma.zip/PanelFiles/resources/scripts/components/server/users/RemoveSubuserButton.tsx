import React, { useState } from 'react';
import { ServerContext } from '@/state/server';
import { Subuser } from '@/state/server/subusers';
import deleteSubuser from '@/api/server/users/deleteSubuser';
import { Actions, useStoreActions } from 'easy-peasy';
import { ApplicationStore } from '@/state';
import { httpErrorToHuman } from '@/api/http';
import { Button } from '@/components/elements/button';
import { TrashIcon } from '@heroicons/react/20/solid';
import { Dialog } from '@/components/elements/dialog';
import SpinnerOverlay from '@/components/elements/SpinnerOverlay';

export default ({ subuser }: { subuser: Subuser }) => {
    const [loading, setLoading] = useState(false);
    const [showConfirmation, setShowConfirmation] = useState(false);

    const uuid = ServerContext.useStoreState((state) => state.server.data!.uuid);
    const removeSubuser = ServerContext.useStoreActions((actions) => actions.subusers.removeSubuser);
    const { addError, clearFlashes } = useStoreActions((actions: Actions<ApplicationStore>) => actions.flashes);

    const doDeletion = () => {
        setLoading(true);
        clearFlashes('users');
        deleteSubuser(uuid, subuser.uuid)
            .then(() => {
                setLoading(false);
                removeSubuser(subuser.uuid);
            })
            .catch((error) => {
                console.error(error);
                addError({ key: 'users', message: httpErrorToHuman(error) });
                setShowConfirmation(false);
            });
    };

    return (
        <>
            <Dialog.Confirm
                title={'Delete this subuser?'}
                confirm={'Remove subuser'}
                open={showConfirmation}
                onConfirmed={() => doDeletion()}
                onClose={() => setShowConfirmation(false)}
            >
                <SpinnerOverlay visible={loading} />
                Are you sure you wish to remove this subuser? They will have all access to this server revoked
                immediately.
            </Dialog.Confirm>
            <Button.Danger
                type={'button'}
                aria-label={'Delete subuser'}
                size={Button.Sizes.Small}
                variant={Button.Variants.Secondary}
                shape={Button.Shapes.IconSquare}
                onClick={() => setShowConfirmation(true)}
            >
                <TrashIcon className='w-5 h-5' />
            </Button.Danger>
        </>
    );
};
