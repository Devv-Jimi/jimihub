import React, { useEffect, useState } from 'react';
import { ServerContext } from '@/state/server';
import { Actions, useStoreActions, useStoreState } from 'easy-peasy';
import { ApplicationStore } from '@/state';
import Spinner from '@/components/elements/Spinner';
import AddSubuserButton from '@/components/server/users/AddSubuserButton';
import UserRow from '@/components/server/users/UserRow';
import FlashMessageRender from '@/components/FlashMessageRender';
import getServerSubusers from '@/api/server/users/getServerSubusers';
import { httpErrorToHuman } from '@/api/http';
import Can from '@/components/elements/Can';
import ServerContentBlock from '@/components/elements/ServerContentBlock';
import styles from './styles.module.css';

import BeforeContent from '@/blueprint/components/Server/Users/BeforeContent';
import AfterContent from '@/blueprint/components/Server/Users/AfterContent';

export default () => {
    const [loading, setLoading] = useState(true);

    const uuid = ServerContext.useStoreState((state) => state.server.data!.uuid);
    const subusers = ServerContext.useStoreState((state) => state.subusers.data);
    const setSubusers = ServerContext.useStoreActions((actions) => actions.subusers.setSubusers);

    const permissions = useStoreState((state: ApplicationStore) => state.permissions.data);
    const getPermissions = useStoreActions((actions: Actions<ApplicationStore>) => actions.permissions.getPermissions);
    const { addError, clearFlashes } = useStoreActions((actions: Actions<ApplicationStore>) => actions.flashes);

    useEffect(() => {
        clearFlashes('users');
        getServerSubusers(uuid)
            .then((subusers) => {
                setSubusers(subusers);
                setLoading(false);
            })
            .catch((error) => {
                console.error(error);
                addError({ key: 'users', message: httpErrorToHuman(error) });
            });
    }, []);

    useEffect(() => {
        getPermissions().catch((error) => {
            addError({ key: 'users', message: httpErrorToHuman(error) });
            console.error(error);
        });
    }, []);

    if (!subusers.length && (loading || !Object.keys(permissions).length)) {
        return <Spinner size={'large'} centered />;
    }

    return (
        <ServerContentBlock title={'Users'} className='max-w-5xl mx-auto'>
            <div className='flex flex-wrap justify-center items-start'>
                <div className='flex-1'>
                    <h1 className='text-3xl font-bold text-gray-50'>Users</h1>
                    {!subusers.length && <p className='mt-1'>It looks like you don&apos;t have any subusers.</p>}
                </div>
                <Can action={'user.create'}>
                    <AddSubuserButton />
                </Can>
            </div>
            <FlashMessageRender byKey={'users'} className='mt-4' />
            <BeforeContent />
            {!!subusers.length && (
                <table className={styles.userTable}>
                    <tbody>
                        {subusers.map((subuser) => (
                            <UserRow key={subuser.uuid} subuser={subuser} />
                        ))}
                    </tbody>
                </table>
            )}
            <AfterContent />
        </ServerContentBlock>
    );
};
