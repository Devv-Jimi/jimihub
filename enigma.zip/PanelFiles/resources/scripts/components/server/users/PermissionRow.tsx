import React, { useRef } from 'react';
import { useStoreState } from 'easy-peasy';
import Checkbox from '@/components/elements/inputs/Checkbox';
import { useField } from 'formik';

interface Props {
    permission: string;
    disabled: boolean;
}

const PermissionRow = ({ permission, disabled }: Props) => {
    const [key, pkey] = permission.split('.', 2);
    const permissions = useStoreState((state) => state.permissions.data);
    const inputRef = useRef<HTMLInputElement | null>(null);

    const [{ value }, , { setValue }] = useField<string[]>('permissions');

    const onClicked = () => {
        if (inputRef.current?.checked) {
            setValue(value.filter((p) => p !== permission));
        } else {
            setValue([...value, permission]);
        }
    };

    return (
        <div onClick={onClicked} className='flex items-center gap-4 cursor-pointer mt-2'>
            <div className='flex-1'>
                <p className='font-medium capitalize'>{pkey.replace(/[-_]/g, ' ')}</p>
                {permissions[key].keys[pkey].length > 0 && (
                    <p className='text-xs text-gray-300 mt-1'>{permissions[key].keys[pkey]}</p>
                )}
            </div>
            <Checkbox
                ref={inputRef}
                name={'permissions'}
                value={permission}
                checked={value.includes(permission)}
                disabled={disabled}
            />
        </div>
    );
};

export default PermissionRow;
