import React, { memo, useCallback } from 'react';
import { useField } from 'formik';
import isEqual from 'react-fast-compare';
import Checkbox from '@/components/elements/inputs/Checkbox';

interface Props {
    isEditable: boolean;
    title: string;
    description: string;
    permissions: string[];
    className?: string;
}

const PermissionTitleBox: React.FC<Props> = memo(({ isEditable, title, description, permissions, children }) => {
    const [{ value }, , { setValue }] = useField<string[]>('permissions');

    const onCheckboxClicked = useCallback(
        (e: React.ChangeEvent<HTMLInputElement>) => {
            if (e.currentTarget.checked) {
                setValue([...value, ...permissions.filter((p) => !value.includes(p))]);
            } else {
                setValue(value.filter((p) => !permissions.includes(p)));
            }
        },
        [permissions, value]
    );

    return (
        <div className='py-6 first:pt-0'>
            <div className='flex gap-4 items-start mb-4'>
                <div className='flex-1'>
                    <h2 className='text-lg font-header font-bold capitalize'>{title} Permissions</h2>
                    <p className='text-gray-300 text-xs'>{description}</p>
                </div>
                {isEditable && (
                    <Checkbox checked={permissions.every((p) => value.includes(p))} onChange={onCheckboxClicked} />
                )}
            </div>
            {children}
        </div>
    );
}, isEqual);

export default PermissionTitleBox;
