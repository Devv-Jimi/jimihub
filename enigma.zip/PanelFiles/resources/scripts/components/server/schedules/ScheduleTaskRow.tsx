import React, { useState } from 'react';
import { Schedule, Task } from '@/api/server/schedules/getServerSchedules';
import deleteScheduleTask from '@/api/server/schedules/deleteScheduleTask';
import { httpErrorToHuman } from '@/api/http';
import SpinnerOverlay from '@/components/elements/SpinnerOverlay';
import TaskDetailsModal from '@/components/server/schedules/TaskDetailsModal';
import Can from '@/components/elements/Can';
import useFlash from '@/plugins/useFlash';
import { ServerContext } from '@/state/server';
import { ArchiveBoxIcon, CodeBracketIcon, PowerIcon, QuestionMarkCircleIcon } from '@heroicons/react/24/solid';
import styles from './styles.module.css';
import { ArrowDownCircleIcon, ClockIcon } from '@heroicons/react/16/solid';
import { PencilIcon, TrashIcon } from '@heroicons/react/20/solid';
import { Button } from '@/components/elements/button';
import { Dialog } from '@/components/elements/dialog';

interface Props {
    schedule: Schedule;
    task: Task;
}

const getActionDetails = (action: string): [string, React.ReactNode] => {
    switch (action) {
        case 'command':
            return ['Send Command', <CodeBracketIcon key={'command'} />];
        case 'power':
            return ['Send Power Action', <PowerIcon key={'power'} />];
        case 'backup':
            return ['Create Backup', <ArchiveBoxIcon key={'archive'} />];
        default:
            return ['Unknown Action', <QuestionMarkCircleIcon key={'what'} />];
    }
};

export default ({ schedule, task }: Props) => {
    const uuid = ServerContext.useStoreState((state) => state.server.data!.uuid);
    const { clearFlashes, addError } = useFlash();
    const [visible, setVisible] = useState(false);
    const [isLoading, setIsLoading] = useState(false);
    const [isEditing, setIsEditing] = useState(false);
    const appendSchedule = ServerContext.useStoreActions((actions) => actions.schedules.appendSchedule);

    const onConfirmDeletion = () => {
        setIsLoading(true);
        clearFlashes('schedules');
        deleteScheduleTask(uuid, schedule.id, task.id)
            .then(() =>
                appendSchedule({
                    ...schedule,
                    tasks: schedule.tasks.filter((t) => t.id !== task.id),
                })
            )
            .catch((error) => {
                console.error(error);
                setIsLoading(false);
                addError({ message: httpErrorToHuman(error), key: 'schedules' });
            });
    };

    const [title, icon] = getActionDetails(task.action);

    return (
        <div className='flex items-center py-4 border-t border-gray-700 first:border-t-0'>
            <SpinnerOverlay visible={isLoading} fixed size={'large'} />
            <TaskDetailsModal schedule={schedule} task={task} open={isEditing} onClose={() => setIsEditing(false)} />
            <Dialog.Confirm
                title={'Confirm task deletion'}
                confirm={'Delete Task'}
                onConfirmed={onConfirmDeletion}
                open={visible}
                onClose={() => setVisible(false)}
            >
                Are you sure you want to delete this task? This action cannot be undone.
            </Dialog.Confirm>
            <div className={styles.taskIcon}>{icon}</div>
            <div className='flex-1 overflow-x-auto'>
                <p className='font-semibold'>{title}</p>
                {task.payload && (
                    <div className='mt-1'>
                        {task.action === 'backup' && <p className='text-xs mb-1'>Ignoring files & folders:</p>}
                        <div className='font-mono bg-gray-700 rounded py-1 px-2 text-sm w-auto inline-block whitespace-pre-wrap break-all'>
                            {task.payload}
                        </div>
                    </div>
                )}
            </div>
            <div className='flex items-center gap-2'>
                {task.continueOnFailure && (
                    <div className='flex mr-2 gap-2 items-center pl-2 pr-3 py-1 bg-amber-500 text-amber-900 text-sm rounded-full'>
                        <ArrowDownCircleIcon className='w-4 h-4' />
                        Continues on Failure
                    </div>
                )}
                {task.sequenceId > 1 && task.timeOffset > 0 && (
                    <div className='flex mr-2 gap-2 items-center pl-2 pr-3 py-1 bg-gray-700 text-gray-200 text-sm rounded-full'>
                        <ClockIcon className='w-4 h-4' />
                        {task.timeOffset}s later
                    </div>
                )}
                <Can action={'schedule.update'}>
                    <Button.Text
                        type={'button'}
                        aria-label={'Edit scheduled task'}
                        variant={Button.Variants.Secondary}
                        shape={Button.Shapes.IconSquare}
                        size={Button.Sizes.Small}
                        onClick={() => setIsEditing(true)}
                    >
                        <PencilIcon className='w-5 h-5' />
                    </Button.Text>
                </Can>
                <Can action={'schedule.update'}>
                    <Button.Text
                        type={'button'}
                        aria-label={'Delete scheduled task'}
                        variant={Button.Variants.Secondary}
                        shape={Button.Shapes.IconSquare}
                        size={Button.Sizes.Small}
                        onClick={() => setVisible(true)}
                    >
                        <TrashIcon className='w-5 h-5' />
                    </Button.Text>
                </Can>
            </div>
        </div>
    );
};
