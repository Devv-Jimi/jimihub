import React, { useEffect, useState } from 'react';
import getServerSchedules from '@/api/server/schedules/getServerSchedules';
import { ServerContext } from '@/state/server';
import Spinner from '@/components/elements/Spinner';
import { useHistory, useRouteMatch } from 'react-router-dom';
import FlashMessageRender from '@/components/FlashMessageRender';
import ScheduleRow from '@/components/server/schedules/ScheduleRow';
import { httpErrorToHuman } from '@/api/http';
import EditScheduleModal from '@/components/server/schedules/EditScheduleModal';
import Can from '@/components/elements/Can';
import useFlash from '@/plugins/useFlash';
import { Button } from '@/components/elements/button/index';
import ServerContentBlock from '@/components/elements/ServerContentBlock';
import styles from './styles.module.css';

import BeforeContent from '@/blueprint/components/Server/Schedules/List/BeforeContent';
import AfterContent from '@/blueprint/components/Server/Schedules/List/AfterContent';

export default () => {
    const match = useRouteMatch();
    const history = useHistory();

    const uuid = ServerContext.useStoreState((state) => state.server.data!.uuid);
    const { clearFlashes, addError } = useFlash();
    const [loading, setLoading] = useState(true);
    const [visible, setVisible] = useState(false);

    const schedules = ServerContext.useStoreState((state) => state.schedules.data);
    const setSchedules = ServerContext.useStoreActions((actions) => actions.schedules.setSchedules);

    useEffect(() => {
        clearFlashes('schedules');
        getServerSchedules(uuid)
            .then((schedules) => setSchedules(schedules))
            .catch((error) => {
                addError({ message: httpErrorToHuman(error), key: 'schedules' });
                console.error(error);
            })
            .then(() => setLoading(false));
    }, []);

    return (
        <ServerContentBlock title={'Schedules'} className='max-w-5xl mx-auto'>
            <div className='flex flex-wrap justify-center items-start'>
                <div className='flex-1'>
                    <h1 className='text-3xl font-bold text-gray-50'>Schedules</h1>
                    {!schedules.length && <p className='mt-1'>There are no schedules configured for this server.</p>}
                </div>
                <Can action={'schedule.create'}>
                    <EditScheduleModal open={visible} onClose={() => setVisible(false)} />
                    <Button onClick={() => setVisible(true)}>Create schedule</Button>
                </Can>
            </div>
            <FlashMessageRender byKey={'schedules'} className='mt-4' />
            {!schedules.length && loading ? (
                <Spinner size={'large'} centered />
            ) : (
                <>
                    <BeforeContent />
                    {schedules.length !== 0 && (
                        <table className={styles.schedulesTable}>
                            <thead>
                                <tr>
                                    <th>{/* Icon */}</th>
                                    <th>Name</th>
                                    <th className='hidden sm:table-cell'>Schedule</th>
                                    <th>{/* Active badge */}</th>
                                </tr>
                            </thead>
                            <tbody>
                                {schedules.map((schedule) => (
                                    <a
                                        key={schedule.id}
                                        href={`${match.url}/${schedule.id}`}
                                        onClick={(e: any) => {
                                            e.preventDefault();
                                            history.push(`${match.url}/${schedule.id}`);
                                        }}
                                    >
                                        <ScheduleRow schedule={schedule} />
                                    </a>
                                ))}
                            </tbody>
                        </table>
                    )}
                    <AfterContent />
                </>
            )}
        </ServerContentBlock>
    );
};
