import React from 'react';
import { Schedule } from '@/api/server/schedules/getServerSchedules';
import { format } from 'date-fns';
import ScheduleCronRow from '@/components/server/schedules/ScheduleCronRow';
import { CalendarDaysIcon } from '@heroicons/react/24/solid';
import classNames from 'classnames';

export default ({ schedule }: { schedule: Schedule }) => (
    <>
        <td>
            <div className='flex h-full justify-center items-center pr-2'>
                <CalendarDaysIcon className='w-6 h-6' />
            </div>
        </td>
        <td>
            <p>{schedule.name}</p>
            <p className='text-xs text-neutral-400'>
                Last run {schedule.lastRunAt ? 'at ' + format(schedule.lastRunAt, "MMM do 'at' h:mma") : 'never'}
            </p>
        </td>
        <td className='hidden sm:table-cell'>
            <ScheduleCronRow cron={schedule.cron} />
        </td>
        <td>
            <div className='flex justify-end h-full items-center'>
                <p
                    className={classNames(
                        'py-1 px-3 rounded text-xs text-white',
                        schedule.isActive && !schedule.isProcessing ? 'bg-emerald-600' : 'bg-gray-600'
                    )}
                >
                    {schedule.isProcessing ? 'Processing' : schedule.isActive ? 'Active' : 'Inactive'}
                </p>
            </div>
        </td>
    </>
);
