import React, { useState } from 'react';
import deleteSchedule from '@/api/server/schedules/deleteSchedule';
import { ServerContext } from '@/state/server';
import { Actions, useStoreActions } from 'easy-peasy';
import { ApplicationStore } from '@/state';
import { httpErrorToHuman } from '@/api/http';
import { Dialog } from '@/components/elements/dialog';
import SpinnerOverlay from '@/components/elements/SpinnerOverlay';

interface Props {
    scheduleId: number;
    onDeleted: () => void;
    open: boolean;
    onClose: () => void;
}

export default ({ scheduleId, onDeleted, open, onClose }: Props) => {
    const [isLoading, setIsLoading] = useState(false);
    const uuid = ServerContext.useStoreState((state) => state.server.data!.uuid);
    const { addError, clearFlashes } = useStoreActions((actions: Actions<ApplicationStore>) => actions.flashes);

    const onDelete = () => {
        setIsLoading(true);
        clearFlashes('schedules');
        deleteSchedule(uuid, scheduleId)
            .then(() => {
                setIsLoading(false);
                onDeleted();
            })
            .catch((error) => {
                console.error(error);

                addError({ key: 'schedules', message: httpErrorToHuman(error) });
                setIsLoading(false);
                onClose();
            });
    };

    return (
        <Dialog.Confirm
            open={open}
            onClose={onClose}
            title={'Delete schedule?'}
            confirm={'Delete'}
            onConfirmed={onDelete}
        >
            <SpinnerOverlay visible={isLoading} />
            All tasks will be removed and any running processes will be terminated.
        </Dialog.Confirm>
    );
};
