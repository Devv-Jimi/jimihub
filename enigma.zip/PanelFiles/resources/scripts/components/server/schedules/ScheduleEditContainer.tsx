import React, { useCallback, useEffect, useState } from 'react';
import { useHistory, useParams } from 'react-router-dom';
import getServerSchedule from '@/api/server/schedules/getServerSchedule';
import Spinner from '@/components/elements/Spinner';
import FlashMessageRender from '@/components/FlashMessageRender';
import EditScheduleModal from '@/components/server/schedules/EditScheduleModal';
import Can from '@/components/elements/Can';
import useFlash from '@/plugins/useFlash';
import { ServerContext } from '@/state/server';
import PageContentBlock from '@/components/elements/PageContentBlock';
import { Button } from '@/components/elements/button/index';
import ScheduleTaskRow from '@/components/server/schedules/ScheduleTaskRow';
import isEqual from 'react-fast-compare';
import { format } from 'date-fns';
import RunScheduleButton from '@/components/server/schedules/RunScheduleButton';
import classNames from 'classnames';
import DropdownMenu, { DropdownButtonRow } from '@/components/elements/DropdownMenu';
import { ClockIcon, EllipsisVerticalIcon, PencilIcon, TrashIcon } from '@heroicons/react/20/solid';
import DeleteScheduleModal from '@/components/server/schedules/DeleteScheduleModal';
import TaskDetailsModal from '@/components/server/schedules/TaskDetailsModal';

import BeforeEdit from '@/blueprint/components/Server/Schedules/Edit/BeforeEdit';
import AfterEdit from '@/blueprint/components/Server/Schedules/Edit/AfterEdit';

interface Params {
    id: string;
}

const CronBox = ({ title, value }: { title: string; value: string }) => (
    <div className='bg-gray-700 rounded p-1.5 sm:p-3 text-center flex flex-col justify-center'>
        <p className='sm:text-2xl font-medium text-gray-100'>{value}</p>
        <p className='text-gray-300 text-xs sm:text-sm'>{title}</p>
    </div>
);

const StatusPill = ({ active, processing }: { active: boolean; processing?: boolean }) => (
    <span
        className={classNames([
            'px-4 py-1 rounded-full flex gap-2 font-semibold text-xs',
            processing || !active ? 'bg-gray-700' : 'bg-emerald-600',
        ])}
    >
        {processing ? (
            <>
                <Spinner size='small' />
                Processing...
            </>
        ) : active ? (
            'Active'
        ) : (
            'Inactive'
        )}
    </span>
);

export default () => {
    const history = useHistory();
    const { id: scheduleId } = useParams<Params>();

    const id = ServerContext.useStoreState((state) => state.server.data!.id);
    const uuid = ServerContext.useStoreState((state) => state.server.data!.uuid);

    const { clearFlashes, clearAndAddHttpError } = useFlash();
    const [isLoading, setIsLoading] = useState(true);
    const [showEditModal, setShowEditModal] = useState(false);
    const [deleteOpen, setDeleteOpen] = useState(false);
    const [newTaskOpen, setNewTaskOpen] = useState(false);

    const schedule = ServerContext.useStoreState(
        (st) => st.schedules.data.find((s) => s.id === Number(scheduleId)),
        isEqual
    );
    const appendSchedule = ServerContext.useStoreActions((actions) => actions.schedules.appendSchedule);

    useEffect(() => {
        if (schedule?.id === Number(scheduleId)) {
            setIsLoading(false);
            return;
        }

        clearFlashes('schedules');
        getServerSchedule(uuid, Number(scheduleId))
            .then((schedule) => appendSchedule(schedule))
            .catch((error) => {
                console.error(error);
                clearAndAddHttpError({ error, key: 'schedules' });
            })
            .then(() => setIsLoading(false));
    }, [scheduleId]);

    const toggleEditModal = useCallback(() => {
        setShowEditModal((s) => !s);
    }, []);

    return (
        <PageContentBlock title={'Schedules'} className='max-w-5xl mx-auto'>
            <FlashMessageRender byKey={'schedules'} className='mb-4' />
            {!schedule || isLoading ? (
                <Spinner size={'large'} centered />
            ) : (
                <>
                    <DeleteScheduleModal
                        scheduleId={schedule.id}
                        open={deleteOpen}
                        onClose={() => setDeleteOpen(false)}
                        onDeleted={() => history.push(`/server/${id}/schedules`)}
                    />
                    <EditScheduleModal
                        open={showEditModal}
                        schedule={schedule}
                        onClose={() => setShowEditModal(false)}
                    />
                    <TaskDetailsModal open={newTaskOpen} onClose={() => setNewTaskOpen(false)} schedule={schedule} />

                    <div className='flex justify-between items-start'>
                        <div className='flex-1'>
                            <div className='flex gap-4 items-center'>
                                <h1 className='text-3xl font-bold text-gray-50'>{schedule.name}</h1>
                                <StatusPill active={schedule.isActive} processing={schedule.isProcessing} />
                            </div>
                            <p className='mt-1 text-sm'>
                                Last run at:{' '}
                                {schedule.lastRunAt ? format(schedule.lastRunAt, "MMM do 'at' h:mma") : 'n/a'}
                            </p>
                            <p className='mt-0.5 text-sm'>
                                Next run at:{' '}
                                {schedule.nextRunAt ? format(schedule.nextRunAt, "MMM do 'at' h:mma") : 'n/a'}
                            </p>
                        </div>
                        <div>
                            <DropdownMenu
                                renderToggle={(onClick) => (
                                    <Button.Text
                                        variant={Button.Variants.Secondary}
                                        shape={Button.Shapes.IconSquare}
                                        size={Button.Sizes.Small}
                                        onClick={onClick}
                                    >
                                        <EllipsisVerticalIcon className='w-5 h-5' />
                                    </Button.Text>
                                )}
                            >
                                <DropdownButtonRow onClick={() => setNewTaskOpen(true)}>
                                    <ClockIcon />
                                    Add a new task
                                </DropdownButtonRow>
                                <Can action={'schedule.update'}>
                                    <DropdownButtonRow onClick={toggleEditModal}>
                                        <PencilIcon />
                                        Edit schedule
                                    </DropdownButtonRow>
                                </Can>
                                {schedule.tasks.length > 0 && (
                                    <Can action={'schedule.update'}>
                                        <RunScheduleButton schedule={schedule} />
                                    </Can>
                                )}
                                <Can action={'schedule.delete'}>
                                    <DropdownButtonRow onClick={() => setDeleteOpen(true)} danger>
                                        <TrashIcon />
                                        Delete schedule
                                    </DropdownButtonRow>
                                </Can>
                            </DropdownMenu>
                        </div>
                    </div>

                    <BeforeEdit />
                    <div className='flex flex-col-reverse sm:flex-col gap-4 mt-4'>
                        <div className='grid grid-cols-5 gap-2 sm:gap-4'>
                            <CronBox title={'Minute'} value={schedule.cron.minute} />
                            <CronBox title={'Hour'} value={schedule.cron.hour} />
                            <CronBox title={'Day (Month)'} value={schedule.cron.dayOfMonth} />
                            <CronBox title={'Month'} value={schedule.cron.month} />
                            <CronBox title={'Day (Week)'} value={schedule.cron.dayOfWeek} />
                        </div>
                        <div>
                            {schedule.tasks.length > 0
                                ? schedule.tasks
                                      .sort((a, b) =>
                                          a.sequenceId === b.sequenceId ? 0 : a.sequenceId > b.sequenceId ? 1 : -1
                                      )
                                      .map((task) => (
                                          <ScheduleTaskRow
                                              key={`${schedule.id}_${task.id}`}
                                              task={task}
                                              schedule={schedule}
                                          />
                                      ))
                                : null}
                        </div>
                    </div>
                    <AfterEdit />
                </>
            )}
        </PageContentBlock>
    );
};
