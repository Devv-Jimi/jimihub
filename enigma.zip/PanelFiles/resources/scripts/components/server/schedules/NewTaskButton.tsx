import { Schedule } from '@/api/server/schedules/getServerSchedules';

interface Props {
    schedule: Schedule;
}

// Nova doesn't use this file, it's a stub only so that Webpack won't kick and scream.
// Sorry 🙃
export default (_: Props) => null;
