import { FileObject } from '@/api/server/files/loadDirectory';
import SelectFileCheckbox from '@/components/server/files/SelectFileCheckbox';
import { ArchiveBoxIcon, DocumentArrowUpIcon, DocumentTextIcon, FolderIcon } from '@heroicons/react/24/solid';
import React, { memo } from 'react';
import styles from './style.module.css';
import { bytesToString } from '@/lib/formatters';
import { differenceInHours, format, formatDistanceToNow } from 'date-fns';
import { encodePathSegments } from '@/helpers';
import { usePermissions } from '@/plugins/usePermissions';
import isEqual from 'react-fast-compare';
import { ServerContext } from '@/state/server';
import { join } from 'path';
import { useRouteMatch } from 'react-router';
import { NavLink } from 'react-router-dom';
import FileDropdownMenu from '@/components/server/files/FileDropdownMenu';

const Clickable: React.FC<{ file: FileObject; onContextMenu: React.MouseEventHandler }> = memo(
    ({ file, children, onContextMenu }) => {
        const [canRead] = usePermissions(['file.read']);
        const [canReadContents] = usePermissions(['file.read-content']);
        const directory = ServerContext.useStoreState((state) => state.files.directory);

        const match = useRouteMatch();

        return (file.isFile && (!file.isEditable() || !canReadContents)) || (!file.isFile && !canRead) ? (
            <div onContextMenu={onContextMenu} className={styles.details}>
                {children}
            </div>
        ) : (
            <NavLink
                onContextMenu={onContextMenu}
                className={styles.details}
                to={`${match.url}${file.isFile ? '/edit' : ''}#${encodePathSegments(join(directory, file.name))}`}
            >
                {children}
            </NavLink>
        );
    },
    isEqual
);

export default ({ file }: { file: FileObject }) => (
    <Clickable
        file={file}
        onContextMenu={(e) => {
            e.preventDefault();
            window.dispatchEvent(
                new CustomEvent(`pterodactyl:files:ctx:${file.key}`, { detail: { x: e.clientX, y: e.clientY } })
            );
        }}
    >
        <td className='w-10 sm:w-12' onClick={(e) => e.stopPropagation()}>
            <div className='flex justify-start items-center'>
                <SelectFileCheckbox name={file.name} />
            </div>
        </td>
        <td>
            <div className='h-full flex items-center gap-2'>
                <div className={styles.iconContainer}>
                    {file.isFile ? (
                        file.isSymlink ? (
                            <DocumentArrowUpIcon />
                        ) : file.isArchiveType() ? (
                            <ArchiveBoxIcon />
                        ) : (
                            <DocumentTextIcon />
                        )
                    ) : (
                        <FolderIcon />
                    )}
                </div>
                <div className='truncate max-w-[50vw] md:max-w-[20vw]'>{file.name}</div>
            </div>
        </td>
        <td className='hidden sm:table-cell'>{file.isFile && bytesToString(file.size)}</td>
        <td className='hidden md:table-cell' title={file.modifiedAt.toString()}>
            {Math.abs(differenceInHours(file.modifiedAt, new Date())) > 48
                ? format(file.modifiedAt, 'MMM do, yyyy h:mma')
                : formatDistanceToNow(file.modifiedAt, { addSuffix: true })}
        </td>
        <td className='w-4'>
            <div className='flex justify-center'>
                <FileDropdownMenu file={file} />
            </div>
        </td>
    </Clickable>
);
