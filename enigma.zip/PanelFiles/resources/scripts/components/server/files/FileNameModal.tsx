import React from 'react';
import { Form, Formik, FormikHelpers } from 'formik';
import { object, string } from 'yup';
import Field from '@/components/elements/Field';
import { ServerContext } from '@/state/server';
import { join } from 'path';
import { Button } from '@/components/elements/button';
import { Dialog } from '@/components/elements/dialog';

type Props = {
    visible: boolean;
    onDismissed: () => void;
    onFileNamed: (name: string) => void;
};

interface Values {
    fileName: string;
}

export default ({ onFileNamed, onDismissed, ...props }: Props) => {
    const directory = ServerContext.useStoreState((state) => state.files.directory);

    const submit = (values: Values, { setSubmitting }: FormikHelpers<Values>) => {
        onFileNamed(join(directory, values.fileName));
        setSubmitting(false);
    };

    return (
        <Formik
            onSubmit={submit}
            initialValues={{ fileName: '' }}
            validationSchema={object().shape({
                fileName: string().required().min(1),
            })}
        >
            {({ resetForm, submitForm }) => (
                <Dialog
                    open={props.visible}
                    onClose={() => {
                        resetForm();
                        onDismissed();
                    }}
                    title='Create a file'
                >
                    <Form>
                        <Field
                            id={'fileName'}
                            name={'fileName'}
                            label={'File Name'}
                            description={'Enter the name that this file should be saved as.'}
                            autoFocus
                        />
                    </Form>
                    <Dialog.Footer>
                        <Button.Text
                            onClick={() => {
                                resetForm();
                                onDismissed();
                            }}
                        >
                            Cancel
                        </Button.Text>
                        <Button onClick={() => submitForm()}>Create file</Button>
                    </Dialog.Footer>
                </Dialog>
            )}
        </Formik>
    );
};
