import { FileObject } from '@/api/server/files/loadDirectory';
import ServerContentBlock from '@/components/elements/ServerContentBlock';
import Spinner from '@/components/elements/Spinner';
import VicTable from '@/components/elements/table/VicTable';
import FileObjectRow from '@/components/server/files/FileObjectRow';
import MassActionsBar from '@/components/server/files/MassActionsBar';
import { ServerError } from '@/components/elements/ScreenBlock';
import { hashToPath } from '@/helpers';
import useFileManagerSwr from '@/plugins/useFileManagerSwr';
import { useStoreActions } from '@/state/hooks';
import { ServerContext } from '@/state/server';
import React, { useEffect } from 'react';
import { useLocation } from 'react-router';
import { httpErrorToHuman } from '@/api/http';
import Checkbox from '@/components/elements/inputs/Checkbox';
import Can from '@/components/elements/Can';
import FileManagerStatus from '@/components/server/files/FileManagerStatus';
import FileManagerBreadcrumbs from '@/components/server/files/FileManagerBreadcrumbs';
import NewDirectoryButton from '@/components/server/files/NewDirectoryButton';
import UploadButton from '@/components/server/files/UploadButton';
import { NavLink } from 'react-router-dom';
import { Button } from '@/components/elements/button';
import PageHeader from '@/components/elements/PageHeader';

import BeforeContent from '@/blueprint/components/Server/Files/Browse/BeforeContent';
import FileButtons from '@/blueprint/components/Server/Files/Browse/FileButtons';
import AfterContent from '@/blueprint/components/Server/Files/Browse/AfterContent';

const sortFiles = (files: FileObject[]): FileObject[] => {
    const sortedFiles: FileObject[] = files
        .sort((a, b) => a.name.localeCompare(b.name))
        .sort((a, b) => (a.isFile === b.isFile ? 0 : a.isFile ? 1 : -1));
    return sortedFiles.filter((file, index) => index === 0 || file.name !== sortedFiles[index - 1].name);
};

export default () => {
    const id = ServerContext.useStoreState((state) => state.server.data!.id);
    const { hash } = useLocation();
    const { data: files, error, mutate } = useFileManagerSwr();
    const directory = ServerContext.useStoreState((state) => state.files.directory);
    const clearFlashes = useStoreActions((actions) => actions.flashes.clearFlashes);
    const setDirectory = ServerContext.useStoreActions((actions) => actions.files.setDirectory);

    const setSelectedFiles = ServerContext.useStoreActions((actions) => actions.files.setSelectedFiles);
    const selectedFilesLength = ServerContext.useStoreState((state) => state.files.selectedFiles.length);

    useEffect(() => {
        clearFlashes('files');
        setSelectedFiles([]);
        setDirectory(hashToPath(hash));
    }, [hash]);

    useEffect(() => {
        mutate();
    }, [directory]);

    const onSelectAllClick = (e: React.ChangeEvent<HTMLInputElement>) => {
        setSelectedFiles(e.currentTarget.checked ? files?.map((file) => file.name) || [] : []);
    };

    if (error) {
        return <ServerError message={httpErrorToHuman(error)} onRetry={() => mutate()} />;
    }

    return (
        <ServerContentBlock title='Files' className='max-w-5xl mx-auto'>
            <PageHeader
                title='Files'
                renderRight={
                    <Can action='file.create'>
                        <div className='flex gap-2'>
                            <FileManagerStatus />
                            <FileButtons />
                            <NewDirectoryButton />
                            <UploadButton />
                            <NavLink to={`/server/${id}/files/new${window.location.hash}`}>
                                <Button>New file</Button>
                            </NavLink>
                        </div>
                    </Can>
                }
            >
                <FileManagerBreadcrumbs />
            </PageHeader>
            <BeforeContent />
            {!files ? (
                <Spinner size='large' centered />
            ) : !files.length ? (
                <p className='mt-1'>This directory seems to be empty.</p>
            ) : (
                <>
                    <div className='mt-8'>
                        <VicTable>
                            <thead>
                                <th className='w-10 sm:w-12'>
                                    <div className='flex justify-start items-center'>
                                        <Checkbox
                                            checked={selectedFilesLength === (files?.length === 0 ? -1 : files?.length)}
                                            onChange={onSelectAllClick}
                                        />
                                    </div>
                                </th>
                                <th>Name</th>
                                <th className='hidden sm:table-cell'>Size</th>
                                <th className='hidden md:table-cell'>Last modified at</th>
                            </thead>
                            <tbody>
                                {sortFiles(files.slice(0, 250)).map((file) => (
                                    <FileObjectRow key={file.key} file={file} />
                                ))}
                            </tbody>
                        </VicTable>
                    </div>
                    <MassActionsBar />
                </>
            )}
            <AfterContent />
        </ServerContentBlock>
    );
};
