import React, { useEffect, useState } from 'react';
import Spinner from '@/components/elements/Spinner';
import { useFlashKey } from '@/plugins/useFlash';
import ServerContentBlock from '@/components/elements/ServerContentBlock';
import { ServerContext } from '@/state/server';
import AllocationRow from '@/components/server/network/AllocationRow';
import { Button } from '@/components/elements/button';
import createServerAllocation from '@/api/server/network/createServerAllocation';
import Can from '@/components/elements/Can';
import SpinnerOverlay from '@/components/elements/SpinnerOverlay';
import getServerAllocations from '@/api/swr/getServerAllocations';
import isEqual from 'react-fast-compare';
import { useDeepCompareEffect } from '@/plugins/useDeepCompareEffect';
import styles from './styles.module.css';
import PageHeader from '@/components/elements/PageHeader';

import BeforeContent from '@/blueprint/components/Server/Network/BeforeContent';
import AfterContent from '@/blueprint/components/Server/Network/AfterContent';

const NetworkContainer = () => {
    const [loading, setLoading] = useState(false);
    const uuid = ServerContext.useStoreState((state) => state.server.data!.uuid);
    const allocationLimit = ServerContext.useStoreState((state) => state.server.data!.featureLimits.allocations);
    const allocations = ServerContext.useStoreState((state) => state.server.data!.allocations, isEqual);
    const setServerFromState = ServerContext.useStoreActions((actions) => actions.server.setServerFromState);

    const { clearFlashes, clearAndAddHttpError } = useFlashKey('server:network');
    const { data, error, mutate } = getServerAllocations();

    useEffect(() => {
        mutate(allocations);
    }, []);

    useEffect(() => {
        clearAndAddHttpError(error);
    }, [error]);

    useDeepCompareEffect(() => {
        if (!data) return;

        setServerFromState((state) => ({ ...state, allocations: data }));
    }, [data]);

    const onCreateAllocation = () => {
        clearFlashes();

        setLoading(true);
        createServerAllocation(uuid)
            .then((allocation) => {
                setServerFromState((s) => ({ ...s, allocations: s.allocations.concat(allocation) }));
                return mutate(data?.concat(allocation), false);
            })
            .catch((error) => clearAndAddHttpError(error))
            .then(() => setLoading(false));
    };

    return (
        <ServerContentBlock showFlashKey={'server:network'} title={'Network'} className='max-w-5xl mx-auto'>
            <SpinnerOverlay visible={loading} />
            <PageHeader
                title='Network'
                className='mb-8'
                renderRight={
                    data &&
                    allocationLimit > data.length && (
                        <Can action={'allocation.create'}>
                            <Button onClick={onCreateAllocation}>Create allocation</Button>
                        </Can>
                    )
                }
            >
                {data && allocationLimit > 0 && (
                    <Can action={'allocation.create'}>
                        <p>
                            You are currently using {data.length} of {allocationLimit} allowed allocations for this
                            server.
                        </p>
                    </Can>
                )}
            </PageHeader>
            {!data ? (
                <Spinner size={'large'} centered />
            ) : (
                <>
                    <BeforeContent />
                    <table className={styles.networkTable}>
                        <thead>
                            <tr>
                                <th>{/* Icon */}</th>
                                <th>Hostname</th>
                                <th>Port</th>
                                <th className='hidden md:table-cell'>{/* Notes */}</th>
                                <th>{/* Primary / Buttons */}</th>
                            </tr>
                        </thead>
                        <tbody>
                            {data.map((allocation) => (
                                <AllocationRow key={`${allocation.ip}:${allocation.port}`} allocation={allocation} />
                            ))}
                        </tbody>
                    </table>
                    <AfterContent />
                </>
            )}
        </ServerContentBlock>
    );
};

export default NetworkContainer;
