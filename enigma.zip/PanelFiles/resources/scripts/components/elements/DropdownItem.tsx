import tw, { styled } from 'twin.macro';

export default styled.div<{ $danger?: boolean }>`
    ${tw`flex text-sm items-center gap-2 w-full p-2 rounded`};
    ${tw`transition-colors`};
    ${(props) => (props.$danger ? tw`hover:bg-rose-700 text-rose-50` : tw`hover:bg-gray-600`)};

    & > svg {
        ${tw`w-5 h-5`};
    }
`;
