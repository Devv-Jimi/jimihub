import React from 'react';
import PageContentBlock from '@/components/elements/PageContentBlock';
import { ExclamationTriangleIcon, QuestionMarkCircleIcon } from '@heroicons/react/24/solid';
import { Button } from '@/components/elements/button';
import { ArrowLeftIcon, ArrowPathIcon } from '@heroicons/react/20/solid';
import styles from './styles.module.css';
import classNames from 'classnames';

interface BaseProps {
    title: string;
    icon: React.ComponentType;
    message: string;
    onRetry?: () => void;
    onBack?: () => void;
}

interface PropsWithRetry extends BaseProps {
    onRetry?: () => void;
    onBack?: never;
}

interface PropsWithBack extends BaseProps {
    onBack?: () => void;
    onRetry?: never;
}

export type ScreenBlockProps = PropsWithBack | PropsWithRetry;

const ScreenBlock = ({ title, icon: Icon, message, onBack, onRetry }: ScreenBlockProps) => (
    <PageContentBlock className='max-w-5xl mx-auto'>
        <div className={classNames(styles.screenBlock, 'flex justify-between')}>
            <h1 className='text-4xl font-bold text-gray-50 flex gap-3 items-center'>
                <Icon />
                {title}
            </h1>
            {(typeof onBack === 'function' || typeof onRetry === 'function') && (
                <Button.Text onClick={() => (onRetry ? onRetry() : onBack ? onBack() : null)}>
                    {onRetry ? (
                        <>
                            <ArrowPathIcon className='size-5 mr-2' />
                            Retry
                        </>
                    ) : (
                        <>
                            <ArrowLeftIcon className='size-5 mr-2' />
                            Go back
                        </>
                    )}
                </Button.Text>
            )}
        </div>
        <p className='mt-4'>{message}</p>
    </PageContentBlock>
);

type ServerErrorProps = (Omit<PropsWithBack, 'icon' | 'title'> | Omit<PropsWithRetry, 'icon' | 'title'>) & {
    title?: string;
};

const ServerError = ({ title, ...props }: ServerErrorProps) => (
    <ScreenBlock title={title || 'Something went wrong'} icon={ExclamationTriangleIcon} {...props} />
);

const NotFound = ({ title, message, onBack }: Partial<Pick<ScreenBlockProps, 'title' | 'message' | 'onBack'>>) => (
    <ScreenBlock
        title={title || 'Not Found'}
        icon={QuestionMarkCircleIcon}
        message={message || "The requested page does not exist. Are you sure you're in the right place?"}
        onBack={onBack}
    />
);

export { ServerError, NotFound };
export default ScreenBlock;
