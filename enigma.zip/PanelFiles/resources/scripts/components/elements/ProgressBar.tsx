import React, { useEffect, useRef, useState } from 'react';
import { useStoreActions, useStoreState } from 'easy-peasy';
import { randomInt } from '@/helpers';
import { AnimatePresence, motion } from 'framer-motion';

// const BarFill = styled.div`
//     ${tw`h-full bg-blue-400`};
//     transition: 250ms ease-in-out;
//     box-shadow: 0 2px 10px 2px rgb(var(--color-blue-600));
// `;

type Timer = ReturnType<typeof setTimeout>;

export default () => {
    const interval = useRef<Timer>(null) as React.MutableRefObject<Timer>;
    const timeout = useRef<Timer>(null) as React.MutableRefObject<Timer>;
    const [visible, setVisible] = useState(false);
    const progress = useStoreState((state) => state.progress.progress);
    const continuous = useStoreState((state) => state.progress.continuous);
    const setProgress = useStoreActions((actions) => actions.progress.setProgress);

    useEffect(() => {
        return () => {
            timeout.current && clearTimeout(timeout.current);
            interval.current && clearInterval(interval.current);
        };
    }, []);

    useEffect(() => {
        setVisible((progress || 0) > 0);

        if (progress === 100) {
            timeout.current = setTimeout(() => setProgress(undefined), 500);
        }
    }, [progress]);

    useEffect(() => {
        if (!continuous) {
            interval.current && clearInterval(interval.current);
            return;
        }

        if (!progress || progress === 0) {
            setProgress(randomInt(20, 30));
        }
    }, [continuous]);

    useEffect(() => {
        if (continuous) {
            interval.current && clearInterval(interval.current);
            if ((progress || 0) >= 90) {
                setProgress(90);
            } else {
                interval.current = setTimeout(() => setProgress((progress || 0) + randomInt(1, 5)), 500);
            }
        }
    }, [progress, continuous]);

    return (
        <div className='h-[2px] w-full fixed bottom-0 z-50'>
            <AnimatePresence>
                {visible && (
                    <motion.div
                        initial={{ opacity: 0, width: 0 }}
                        animate={{
                            opacity: 1,
                            width: progress === undefined ? '100%' : `${progress}%`,
                            transition: { duration: 0.25 },
                        }}
                        exit={{ opacity: 0 }}
                        className='bg-blue-400 h-full shadow-[0_2px_10px_2px_rgb(var(--color-blue-600))]'
                    />
                )}
            </AnimatePresence>
        </div>
    );
};
