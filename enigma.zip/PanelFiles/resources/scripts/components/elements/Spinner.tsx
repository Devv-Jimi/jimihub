import React, { Suspense } from 'react';
import ErrorBoundary from '@/components/elements/ErrorBoundary';
import styles from './spinner/style.module.css';
import classNames from 'classnames';

export type SpinnerSize = 'small' | 'base' | 'large' | 'icon';

interface Props {
    size?: SpinnerSize;
    centered?: boolean;
    isBlue?: boolean;
}

interface Spinner extends React.FC<Props> {
    Size: Record<'SMALL' | 'BASE' | 'LARGE' | 'ICON', SpinnerSize>;
    Suspense: React.FC<Props>;
}

const Spinner: Spinner = ({ centered, ...props }) =>
    centered ? (
        <div className={classNames('flex justify-center items-center', props.size === 'large' ? 'm-20' : 'm-6')}>
            <div
                className={classNames(
                    styles.spinner,
                    props.size === 'small' && styles.small,
                    props.size === 'large' && styles.large,
                    props.size === 'icon' && styles.icon
                )}
            >
                <div className={styles.innerSpinner} />
            </div>
        </div>
    ) : (
        <div
            className={classNames(
                styles.spinner,
                props.size === 'small' && styles.small,
                props.size === 'large' && styles.large,
                props.size === 'icon' && styles.icon
            )}
        >
            <div className={styles.innerSpinner} />
        </div>
    );
Spinner.displayName = 'Spinner';

Spinner.Size = {
    SMALL: 'small',
    BASE: 'base',
    LARGE: 'large',
    ICON: 'icon',
};

Spinner.Suspense = ({ children, centered = true, size = Spinner.Size.LARGE, ...props }) => (
    <Suspense fallback={<Spinner centered={centered} size={size} {...props} />}>
        <ErrorBoundary>{children}</ErrorBoundary>
    </Suspense>
);
Spinner.Suspense.displayName = 'Spinner.Suspense';

export default Spinner;
