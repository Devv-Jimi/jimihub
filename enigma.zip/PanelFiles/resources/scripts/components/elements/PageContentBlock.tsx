import React, { useEffect } from 'react';
import { CSSTransition } from 'react-transition-group';
import tw from 'twin.macro';
import FlashMessageRender from '@/components/FlashMessageRender';
import { State, useStoreState } from 'easy-peasy';
import { ApplicationStore } from '@/state';
import classNames from 'classnames';

export interface PageContentBlockProps {
    title?: string;
    className?: string;
    showFlashKey?: string;
}

const PageContentBlock: React.FC<PageContentBlockProps> = ({ title, showFlashKey, className, children }) => {
    useEffect(() => {
        if (title) {
            document.title = title;
        }
    }, [title]);

    const poweredFooter = useStoreState((state: State<ApplicationStore>) => state.themeData.data!.poweredFooter);

    return (
        <CSSTransition timeout={150} classNames={'fade'} appear in>
            <div className='px-4 py-16 md:p-12 min-h-screen flex flex-col'>
                <div className={classNames(className, 'w-full flex-1')}>
                    {showFlashKey && <FlashMessageRender byKey={showFlashKey} css={tw`mb-4`} />}
                    {children}
                </div>
                <p className='mt-8 text-center text-neutral-500 text-xs'>
                    <a
                        rel={'noopener nofollow noreferrer'}
                        href={'https://pterodactyl.io'}
                        target={'_blank'}
                        className='no-underline text-neutral-500 hover:text-neutral-300'
                    >
                        Pterodactyl&reg;
                    </a>
                    &nbsp;&copy; 2015 - {new Date().getFullYear()}
                </p>
                {poweredFooter && (
                    <p className='mt-1 text-center text-neutral-500 text-xs'>
                        <a
                            rel={'noopener nofollow noreferrer'}
                            href={`https://getnova.zip/?utm_source=${location.hostname}&utm_campaign=powered-by-nova`}
                            target={'_blank'}
                            className='no-underline text-neutral-500 hover:text-neutral-300'
                        >
                            Powered by Nova
                        </a>
                    </p>
                )}
            </div>
        </CSSTransition>
    );
};

export default PageContentBlock;
