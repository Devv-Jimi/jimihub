// React port of https://github.com/itsvic-dev/nova-landing/blob/master/components/BlurredImage.vue
import React, { useEffect, useRef } from 'react';

type Props = {
    src: string;
    className?: string;
    direction: 'up' | 'down';
};

const BlurredImage = (props: Props) => {
    const displayCanvas = useRef<HTMLCanvasElement>(null);
    const offscreenCanvas = useRef(document.createElement('canvas'));

    const image = useRef(new Image());
    image.current.src = props.src;

    useEffect(() => {
        const render = () => {
            if (!displayCanvas.current || !offscreenCanvas.current || !image.current.complete) return;
            const displayContext = displayCanvas.current?.getContext('2d');
            const offscreenContext = offscreenCanvas.current.getContext('2d');
            if (!displayContext || !offscreenContext) throw new Error('failed to init context');

            const width = (displayCanvas.current.width = offscreenCanvas.current.width = window.innerWidth);
            const height = (displayCanvas.current.height = offscreenCanvas.current.height = window.innerHeight);

            // create gradient
            let gradient = displayContext.createRadialGradient(
                width / 2,
                props.direction === 'down' ? 0 : height,
                0,
                width / 2,
                props.direction === 'down' ? 0 : height,
                height
            );
            gradient.addColorStop(0, 'black');
            gradient.addColorStop(1, 'transparent');

            // put it on display gradient as mask
            displayContext.fillStyle = gradient;
            displayContext.fillRect(0, 0, width, height);

            // calculate the image size to cover the canvas
            const scale = Math.max(width / image.current.width, height / image.current.height);

            const imgWidth = image.current.width * scale;
            const imgHeight = image.current.height * scale;

            // draw the image
            displayContext.globalCompositeOperation = 'source-in';
            displayContext.drawImage(image.current, (width - imgWidth) / 2, 0, imgWidth, imgHeight);

            // copy the faded image to the offscreen context with a blur
            offscreenContext.filter = 'blur(16px)';
            offscreenContext.drawImage(displayCanvas.current, 0, 0, width, height);

            // redraw the image but fading out faster
            gradient = displayContext.createRadialGradient(
                width / 2,
                props.direction === 'down' ? 0 : height,
                0,
                width / 2,
                props.direction === 'down' ? 0 : height,
                height * 0.75
            );
            gradient.addColorStop(0, 'black');
            gradient.addColorStop(1, 'transparent');

            displayContext.globalCompositeOperation = 'copy';
            displayContext.fillStyle = gradient;
            displayContext.fillRect(0, 0, width, height);

            displayContext.globalCompositeOperation = 'source-in';
            displayContext.drawImage(image.current, (width - imgWidth) / 2, 0, imgWidth, imgHeight);

            // copy the blurred image back to the display context
            displayContext.globalCompositeOperation = 'destination-atop';
            displayContext.drawImage(offscreenCanvas.current, 0, 0, width, height);
        };

        window.addEventListener('resize', render);
        image.current.addEventListener('load', render);
        render();

        return () => window.removeEventListener('resize', render);
    }, [displayCanvas, offscreenCanvas]);

    return <canvas ref={displayCanvas} className={props.className} />;
};

export default BlurredImage;
