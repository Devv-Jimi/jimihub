import BlurredImage from '@/components/elements/backgrounds/BlurredImage';
import classNames from 'classnames';
import { useStoreState } from 'easy-peasy';
import React from 'react';

const BackgroundDisplay = ({ eggId }: { eggId?: number }) => {
    const backgroundStyle = useStoreState((state) => state.themeData.data!.backgroundStyle);
    const backgrounds = useStoreState((state) => state.themeData.data!.backgrounds);
    const eggBackground = !eggId ? undefined : backgrounds[eggId];

    const sharedStyles = '-z-10 fixed top-0 left-0 w-full h-full';

    return (
        <>
            {/* Default gradient background */}
            <div className={classNames(sharedStyles, 'bg-gradient-to-b from-transparent to-gray-900/30')} />

            {/* Background image */}
            {(backgrounds.global || eggBackground) &&
                (backgroundStyle === 'simple' ? (
                    <div
                        className={classNames(sharedStyles, 'opacity-30 bg-cover bg-center')}
                        style={{ backgroundImage: `url(${eggBackground || backgrounds.global})` }}
                    />
                ) : (
                    <BlurredImage
                        className={classNames(sharedStyles, 'opacity-30')}
                        src={eggBackground || backgrounds.global || ''}
                        direction='down'
                    />
                ))}
        </>
    );
};

export default BackgroundDisplay;
