import React from 'react';
import styles from './styles.module.css';
import classNames from 'classnames';

export default (props: { children?: React.ReactNode; className?: string }) => (
    <table className={classNames(styles.table, props.className)}>{props.children}</table>
);
