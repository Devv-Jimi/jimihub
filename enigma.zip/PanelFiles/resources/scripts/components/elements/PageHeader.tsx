import classNames from 'classnames';
import React from 'react';

type PageHeaderProps = {
    title: string;
    children?: React.ReactNode;
    renderRight?: React.ReactNode;
    className?: string;
};

export default (props: PageHeaderProps) => (
    <div className={classNames('flex flex-wrap justify-center gap-4 items-start', props.className)}>
        <div className='flex-grow'>
            <h1 className='text-3xl font-bold text-gray-50'>{props.title}</h1>
            {props.children}
        </div>
        {props.renderRight}
    </div>
);
