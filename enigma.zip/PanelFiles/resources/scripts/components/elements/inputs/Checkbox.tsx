import React, { forwardRef } from 'react';
import classNames from 'classnames';
import { CheckIcon } from '@heroicons/react/16/solid';
import styles from './styles.module.css';

type Props = {
    id?: string;
    name?: string;
    value?: string;
    className?: string;
    checked?: boolean;
    disabled?: boolean;
    onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
};

export default forwardRef<HTMLInputElement, Props>(({ className, ...props }, ref) => {
    return (
        <>
            <label className={classNames(styles.checkbox_label, className)}>
                <input className='hidden' ref={ref} type={'checkbox'} {...props} />
                <CheckIcon />
            </label>
        </>
    );
});
