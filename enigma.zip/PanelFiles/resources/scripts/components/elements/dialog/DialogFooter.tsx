import React, { useContext } from 'react';
import { DialogContext } from './';
import { useDeepCompareEffect } from '@/plugins/useDeepCompareEffect';

export default ({ children }: { children: React.ReactNode }) => {
    const { setFooter } = useContext(DialogContext);

    useDeepCompareEffect(() => {
        setFooter(
            <div className={'p-3 bg-gray-900 flex items-center justify-end space-x-3 rounded-b'}>{children}</div>
        );
    }, [children]);

    return null;
};
