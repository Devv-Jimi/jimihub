import * as React from 'react';
import FlashMessageRender from '@/components/FlashMessageRender';
import classNames from 'classnames';

const HeaderedContent = ({
    title,
    description,
    showFlashes,
    children,
    className,
}: {
    title: string;
    description: string;
    showFlashes?: string | boolean;
    children?: React.ReactNode;
    className?: string;
}) => (
    <>
        <div className={classNames('flex flex-col md:grid grid-cols-7 gap-8', className || 'mt-16')}>
            <div className='col-span-3'>
                <h2 className='text-xl font-bold text-gray-100'>{title}</h2>
                <p className='mt-1'>{description}</p>
            </div>
            <div className='col-span-4'>
                {showFlashes && (
                    <FlashMessageRender
                        byKey={typeof showFlashes === 'string' ? showFlashes : undefined}
                        className='mb-4'
                    />
                )}
                {children}
            </div>
        </div>
    </>
);

export default HeaderedContent;
