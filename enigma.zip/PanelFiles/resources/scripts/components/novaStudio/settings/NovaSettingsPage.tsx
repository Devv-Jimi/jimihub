import deleteSettings from '@/api/novaStudio/deleteSettings';
import Input from '@/components/elements/Input';
import Switch from '@/components/elements/Switch';
import { Button } from '@/components/elements/button';
import { Dialog } from '@/components/elements/dialog';
import StudioPage from '@/components/novaStudio/StudioPage';
import VersionSection from '@/components/novaStudio/settings/VersionSection';
import { NovaStudioContext } from '@/state/novaStudio';
import React, { useState } from 'react';

export default () => {
    const poweredFooter = NovaStudioContext.useStoreState((state) => state.editedData!.poweredFooter);
    const icon = NovaStudioContext.useStoreState((state) => state.editedData!.icon);
    const updateEditedData = NovaStudioContext.useStoreActions((actions) => actions.updateEditedData);

    const [resetOpen, setResetOpen] = useState(false);

    return (
        <StudioPage title='General Settings'>
            <h1 className='text-3xl font-bold text-gray-50'>General Settings</h1>
            <p className='mt-1'>Configure Nova to your liking.</p>

            <div className='mt-6'>
                <Switch
                    name='poweredFooter'
                    label='"Powered by Nova" footer'
                    description='Controls whether the page footer should contain "Powered by Nova".'
                    defaultChecked={poweredFooter}
                    onChange={(e) => {
                        updateEditedData({ poweredFooter: e.currentTarget.checked });
                    }}
                />
            </div>

            <div className='mt-6'>
                <p className='text-sm mb-1'>Path to the icon image</p>
                <Input type='text' value={icon} onChange={(e) => updateEditedData({ icon: e.currentTarget.value })} />
                <p className='text-xs mt-1'>
                    This should be a PNG file inside of the &quot;public&quot; directory of the panel. It will be shown
                    on the sidebar and used as the icon shown by the browser.
                </p>
            </div>

            <div className='mt-12' id='version'>
                <h2 className='text-xl font-bold text-gray-50 mb-2'>Updates</h2>
                <VersionSection />
            </div>

            <div className='mt-12'>
                <h2 className='text-xl font-bold text-gray-50 mb-2'>Reset Nova to factory defaults</h2>
                <p className='mb-4'>
                    By resetting Nova to factory defaults, you will delete all of the customization done to the theme
                    and restore it to how it looks like on a brand new installation.{' '}
                    <b>You usually shouldn&apos;t need to do this.</b>
                </p>
                <Button.Danger onClick={() => setResetOpen(true)}>Reset to factory defaults</Button.Danger>

                <Dialog.Confirm
                    title='Reset Nova to factory defaults'
                    confirm='Reset'
                    open={resetOpen}
                    onClose={() => setResetOpen(false)}
                    onConfirmed={() => {
                        deleteSettings()
                            .then(() => {
                                location.reload();
                            })
                            .catch(console.error)
                            .then(() => setResetOpen(false));
                    }}
                >
                    Are you sure you want to reset Nova to factory defaults? <b>You will lose all of your changes.</b>
                </Dialog.Confirm>
            </div>
        </StudioPage>
    );
};
