import getVersionData, { humanVersionErrors } from '@/api/novaStudio/getVersionData';
import { Alert } from '@/components/elements/alert';
import React from 'react';
import useSWR from 'swr';
import { lt } from 'semver';
import Markdown from 'markdown-to-jsx';
import styles from '@/components/elements/standardMarkdown.module.css';
import { Button } from '@/components/elements/button';

export default () => {
    const { data, isValidating } = useSWR('nova:versionData', getVersionData);

    if (isValidating || !data) {
        return <div>Loading...</div>;
    }

    if (data.error) {
        return (
            <Alert type='danger'>
                {humanVersionErrors[data.error]} (code {data.error})
            </Alert>
        );
    }

    // if the current version is < latest version, it needs an update
    const needsUpdate = lt(data.current, data.latest);

    return (
        <div>
            <p>
                You are running Nova {data.current}.{' '}
                {needsUpdate ? <b>There is an update available!</b> : <>Your panel is up to date!</>}
            </p>
            <h3 className='mt-2 text-lg font-semibold'>What&apos;s new in Nova {data.latest}?</h3>
            <div className={styles.markdownContent}>
                <Markdown>{data.changelog}</Markdown>
            </div>
            {needsUpdate && (
                <>
                    <p className='mt-4 font-bold'>Download the latest update from the following platforms:</p>
                    <div className='grid grid-cols-2 gap-2 mt-2'>
                        <a href='https://bbyb.it/40094'>
                            <Button.Text className='w-full'>BuiltByBit</Button.Text>
                        </a>
                        <a href='https://sourcexchange.net/products/nova'>
                            <Button.Text className='w-full'>sourceXchange</Button.Text>
                        </a>
                    </div>
                </>
            )}
        </div>
    );
};
