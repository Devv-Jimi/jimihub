import React, { useEffect, useRef } from 'react';
import { NovaStudioContext } from '@/state/novaStudio';

export default () => {
    const ref = useRef<HTMLIFrameElement>(null);
    const editedData = NovaStudioContext.useStoreState((state) => state.editedData);

    useEffect(() => {
        if (!ref.current || !editedData) return;

        const event = new CustomEvent('nova:themeDataUpdate', {
            detail: editedData,
        });
        ref.current.contentWindow?.dispatchEvent(event);
    }, [ref, editedData]);

    return (
        <div className='flex flex-col gap-2 h-full'>
            <p>Preview</p>
            <iframe
                src='/'
                className='w-full flex-1 border border-gray-600 rounded-xl overflow-auto 2xl:col-span-2'
                ref={ref}
            />
        </div>
    );
};
