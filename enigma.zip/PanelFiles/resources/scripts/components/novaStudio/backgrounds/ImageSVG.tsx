import { useStoreState } from 'easy-peasy';
import React from 'react';

export default (props: React.SVGProps<SVGSVGElement> & { active?: boolean }) => (
    <svg {...props} viewBox='0 0 140 90' fill='none' xmlns='http://www.w3.org/2000/svg'>
        <g clipPath='url(#clip0_53_98)'>
            <path
                d='M36.3457 33.0611L2.5 58V81.5458C2.5 82.82 2.39209 83.3381 3.0989 84.3983C4.29592 86.1939 6.79619 88 8.95416 88H110.036C117.819 88 120.835 78.2795 114.289 74.0697C87.9347 57.1202 56.4562 39.0483 44.972 32.5272C42.24 30.9758 38.875 31.1974 36.3457 33.0611Z'
                fill={useStoreState((state) => state.themeData.data!.colors[props.active ? 'blue' : 'gray'][300])}
            />
            <path
                d='M88.9382 40.9371L10.5 88H129.818C131.855 88 133.809 87.1907 135.25 85.75C136.691 84.3093 137.5 82.3554 137.5 80.318V64.5L97.0899 40.8896C94.5678 39.416 91.443 39.4342 88.9382 40.9371Z'
                fill={useStoreState((state) => state.themeData.data!.colors[props.active ? 'blue' : 'gray'][200])}
            />
            <rect
                x='2'
                y='2'
                width='136'
                height='86'
                rx='6'
                stroke={useStoreState((state) => state.themeData.data!.colors[props.active ? 'blue' : 'gray'][100])}
                strokeWidth='4'
            />
            <circle
                cx='115'
                cy='22'
                r='10'
                fill={useStoreState((state) => state.themeData.data!.colors[props.active ? 'blue' : 'gray'][200])}
            />
        </g>
        <defs>
            <clipPath id='clip0_53_98'>
                <rect width='140' height='90' fill='white' />
            </clipPath>
        </defs>
    </svg>
);
