import React, { useState } from 'react';
import StudioPage from '@/components/novaStudio/StudioPage';
import { NovaStudioContext } from '@/state/novaStudio';
import Input from '@/components/elements/Input';
import useSWR from 'swr';
import getEggs from '@/api/novaStudio/getEggs';
import { Button } from '@/components/elements/button';
import { PlusIcon } from '@heroicons/react/20/solid';
import Spinner from '@/components/elements/Spinner';
import { Dialog } from '@/components/elements/dialog';
import Label from '@/components/elements/Label';
import { TrashIcon } from '@heroicons/react/24/solid';
import ImageSVG from '@/components/novaStudio/backgrounds/ImageSVG';
import classNames from 'classnames';

// hell
const removeKey = (k: any, { [k]: _, ...o }) => o;

export default () => {
    const [addEgg, setAddEgg] = useState(false);
    const backgroundStyle = NovaStudioContext.useStoreState((state) => state.editedData!.backgroundStyle);
    const backgrounds = NovaStudioContext.useStoreState((state) => state.editedData!.backgrounds);
    const updateEditedData = NovaStudioContext.useStoreActions((actions) => actions.updateEditedData);
    const addedEggs = Object.keys(backgrounds).filter((k) => k !== 'global');

    const { data: eggs, isValidating } = useSWR(['novaStudio:eggs'], getEggs, { revalidateOnFocus: false });

    const eggsToAdd = eggs?.filter((egg) => !addedEggs.includes(egg.internalId.toString())) ?? [];

    return (
        <StudioPage title='Backgrounds'>
            <Dialog open={addEgg} onClose={() => setAddEgg(false)} title='Add a new egg background'>
                <div className='flex flex-wrap gap-4'>
                    {eggsToAdd.map((egg) => (
                        <Button.Text
                            key={egg.uuid}
                            onClick={() => {
                                updateEditedData({ backgrounds: { ...backgrounds, [egg.internalId]: '' } });
                                setAddEgg(false);
                            }}
                        >
                            <span className='text-xs text-gray-300 mr-2'>{egg.internalId}</span> {egg.name}
                        </Button.Text>
                    ))}
                </div>
            </Dialog>

            <h1 className='text-3xl font-bold text-gray-50'>Backgrounds</h1>
            <p className='mt-1'>Give your panel a personal touch.</p>

            <h2 className='text-xl font-bold text-gray-50 mt-6 mb-2'>Background style</h2>
            <div className='grid grid-cols-2 gap-4 grid-rows-[10rem]'>
                <div className='flex flex-col'>
                    <button
                        className={classNames(
                            'size-full flex items-center justify-center rounded-lg overflow-clip transition-colors duration-300',
                            backgroundStyle === 'simple' ? 'bg-blue-500 text-blue-50' : 'bg-gray-700 text-gray-50'
                        )}
                        onClick={() => updateEditedData({ backgroundStyle: 'simple' })}
                    >
                        <ImageSVG
                            className={classNames(
                                'transition-opacity duration-300',
                                backgroundStyle === 'simple' ? 'opacity-30' : 'opacity-50'
                            )}
                            style={{ maxWidth: '70%', maxHeight: '70%' }}
                        />
                    </button>
                    <p className={classNames('mt-1', backgroundStyle === 'simple' && 'font-bold')}>Simple</p>
                </div>

                <div className='flex flex-col'>
                    <button
                        className={classNames(
                            'size-full relative rounded-lg overflow-visible transition-colors duration-300',
                            backgroundStyle === 'fade' ? 'bg-blue-500 text-blue-50' : 'bg-gray-700 text-gray-50'
                        )}
                        onClick={() => updateEditedData({ backgroundStyle: 'fade' })}
                    >
                        <div
                            className='top-0 left-0 size-full absolute flex justify-center items-center'
                            style={{
                                maskImage: 'radial-gradient(farthest-side at top center, black 0%, transparent 100%)',
                            }}
                        >
                            <ImageSVG
                                className={classNames(
                                    'transition-opacity duration-300',
                                    backgroundStyle === 'simple' ? 'opacity-30' : 'opacity-50'
                                )}
                                style={{ maxWidth: '70%', maxHeight: '70%' }}
                            />
                        </div>
                        <div
                            className='top-0 left-0 size-full absolute backdrop-blur-lg rounded-lg'
                            style={{
                                maskImage: 'radial-gradient(farthest-side at top center, transparent 0%, black 100%)',
                            }}
                        ></div>
                    </button>
                    <p className={classNames('mt-1', backgroundStyle === 'fade' && 'font-bold')}>Blurry fade</p>
                </div>
            </div>

            <h2 className='text-xl font-bold text-gray-50 mt-6'>Global background</h2>
            <p className='mt-1'>The background used by all pages.</p>
            <Input
                className='mt-1'
                type='text'
                value={backgrounds.global ?? ''}
                onChange={(e) => updateEditedData({ backgrounds: { ...backgrounds, global: e.currentTarget.value } })}
            />

            <div className='grid grid-cols-[1fr_auto] gap-4 mt-6'>
                <div>
                    <h2 className='text-xl font-bold text-gray-50'>Per-egg backgrounds</h2>
                    {!addedEggs.length && (
                        <p className='mt-1'>There are no per-egg backgrounds added yet. Try adding one!</p>
                    )}
                </div>

                <Button.Text
                    aria-label='Add a new egg background'
                    onClick={() => setAddEgg(true)}
                    size={Button.Sizes.Small}
                    shape={Button.Shapes.IconSquare}
                >
                    <PlusIcon className='size-5' />
                </Button.Text>
            </div>
            {isValidating && <Spinner centered />}
            {eggs && !!addedEggs.length && (
                <div className='mt-2 grid gap-4'>
                    {addedEggs
                        .map((k) => eggs.find((egg) => egg.internalId.toString() === k))
                        .map((egg) =>
                            !egg ? null : (
                                <div>
                                    <Label htmlFor={egg.uuid}>{egg.name}</Label>
                                    <div className='grid grid-cols-[1fr_auto] gap-3 items-center'>
                                        <Input
                                            id={egg.uuid}
                                            type='text'
                                            value={backgrounds[egg.internalId] ?? ''}
                                            onChange={(e) =>
                                                updateEditedData({
                                                    backgrounds: {
                                                        ...backgrounds,
                                                        [egg.internalId]: e.currentTarget.value,
                                                    },
                                                })
                                            }
                                        />
                                        <Button.Danger
                                            variant={Button.Variants.Secondary}
                                            shape={Button.Shapes.IconSquare}
                                            size={Button.Sizes.Small}
                                            onClick={() =>
                                                updateEditedData({
                                                    backgrounds: removeKey(egg.internalId, backgrounds),
                                                })
                                            }
                                        >
                                            <TrashIcon className='size-5' />
                                        </Button.Danger>
                                    </div>
                                </div>
                            )
                        )}
                </div>
            )}
        </StudioPage>
    );
};
