import Select from '@/components/elements/Select';
import { Button } from '@/components/elements/button';
import StudioPage from '@/components/novaStudio/StudioPage';
import { getShades, hexToInt } from '@/lib/nova/monetShades';
import { NovaStudioContext } from '@/state/novaStudio';
import { Colors } from '@/state/themeData';
import classNames from 'classnames';
import React, { useState } from 'react';
import { blue, slate, zinc } from 'tailwindcss/colors';

const ColorBox = ({
    colorKey,
    className,
    ...props
}: React.InputHTMLAttributes<HTMLInputElement> & { colorKey: string }) => {
    return (
        <div>
            <p className='text-gray-300 text-xs mb-1'>{colorKey}</p>
            <input
                type='color'
                {...props}
                className={classNames(
                    'w-full h-8 rounded-md overflow-hidden outline-offset-0 outline-1 outline-white/20',
                    className
                )}
            />
        </div>
    );
};

enum Style {
    TONAL_SPOT,
    VIBRANT,
    EXPRESSIVE,
}

const bgChromas: Record<Style, number> = {
    [Style.TONAL_SPOT]: 6,
    [Style.VIBRANT]: 10,
    [Style.EXPRESSIVE]: 8,
};

const primaryChromas: Record<Style, number> = {
    [Style.TONAL_SPOT]: 36,
    [Style.VIBRANT]: 130,
    [Style.EXPRESSIVE]: 40,
};

// unwieldy types but whatever
const getColorsWithoutExtras = (colors: Colors) =>
    ['50', '100', '200', '300', '400', '500', '600', '700', '800', '900'].reduce(
        (obj, item) => ({ ...obj, [item]: (colors as Record<string, string>)[item] }),
        {}
    ) as Colors;

export default () => {
    const colors = NovaStudioContext.useStoreState((state) => state.editedData!.colors);
    const updateEditedData = NovaStudioContext.useStoreActions((state) => state.updateEditedData);

    const [seedColor, setSeedColor] = useState('#ff007b');
    const [style, setStyle] = useState(Style.TONAL_SPOT);

    const onColorEdit = (type: 'gray' | 'blue', colorKey: number) => (event: React.ChangeEvent<HTMLInputElement>) => {
        updateEditedData({
            colors: {
                ...colors,
                [type]: {
                    ...colors[type],
                    [colorKey]: event.currentTarget.value,
                },
            },
        });
    };

    const updateMonetColors = ({ seedColor, style }: { seedColor: string; style: Style }) => {
        const bgShades = getShades(hexToInt(seedColor), bgChromas[style]);
        const primaryShades = getShades(hexToInt(seedColor), primaryChromas[style]);
        updateEditedData({
            colors: {
                gray: {
                    '50': bgShades[0],
                    '100': bgShades[1],
                    '200': bgShades[2],
                    '300': bgShades[3],
                    '400': bgShades[4],
                    '500': bgShades[5],
                    '600': bgShades[7],
                    '700': bgShades[8],
                    '800': bgShades[9],
                    '900': bgShades[10],
                },
                blue: {
                    '50': primaryShades[0],
                    '100': primaryShades[1],
                    '200': primaryShades[2],
                    '300': primaryShades[3],
                    '400': primaryShades[4],
                    '500': primaryShades[5],
                    '600': primaryShades[7],
                    '700': primaryShades[8],
                    '800': primaryShades[9],
                    '900': primaryShades[10],
                },
            },
        });
    };

    return (
        <StudioPage title='Colors'>
            <h1 className='text-3xl font-bold text-gray-50'>Colors</h1>
            <p className='mt-1'>Paint your own vision onto Nova.</p>

            <h2 className='text-xl text-gray-50 font-bold mt-4 mb-2'>Pick a theme...</h2>
            <div className='grid grid-cols-2 gap-4'>
                <Button
                    onClick={() =>
                        updateEditedData({
                            colors: { gray: getColorsWithoutExtras(slate), blue: getColorsWithoutExtras(blue) },
                        })
                    }
                >
                    Slate
                </Button>
                <Button.Text
                    onClick={() =>
                        updateEditedData({
                            colors: { gray: getColorsWithoutExtras(zinc), blue: getColorsWithoutExtras(blue) },
                        })
                    }
                >
                    Zinc
                </Button.Text>
            </div>

            <h2 className='text-xl text-gray-50 font-bold mt-8 mb-2'>...generate one...</h2>
            <div className='grid grid-cols-2 gap-4'>
                <ColorBox
                    colorKey='Seed color'
                    value={seedColor}
                    onChange={(e) => {
                        setSeedColor(e.currentTarget.value);
                        updateMonetColors({ seedColor: e.currentTarget.value, style });
                    }}
                />
                <div>
                    <p className='text-gray-300 text-xs mb-1'>Style</p>
                    <Select
                        value={style}
                        onChange={(e) => {
                            setStyle(parseInt(e.currentTarget.value));
                            updateMonetColors({ seedColor, style: parseInt(e.currentTarget.value) });
                        }}
                    >
                        {/* TODO: might be worth to rename these, or at least TONAL_SPOT */}
                        <option value={Style.TONAL_SPOT}>Tonal Spot</option>
                        <option value={Style.EXPRESSIVE}>Expressive</option>
                        <option value={Style.VIBRANT}>Vibrant</option>
                    </Select>
                </div>
            </div>

            <h2 className='text-xl text-gray-50 font-bold mt-8 mb-2'>...or enter your own color swatches.</h2>
            {/* padded because of the outlines */}
            <p className='mb-2'>Background colors</p>
            <div className='grid grid-cols-5 gap-4 p-[1px]'>
                {Object.keys(colors.gray).map((key) => (
                    <ColorBox
                        key={key}
                        colorKey={key}
                        value={(colors.gray as { [k: string]: string })[key]}
                        onChange={onColorEdit('gray', parseInt(key))}
                    />
                ))}
            </div>
            <p className='mt-4 mb-2'>Accent colors</p>
            <div className='grid grid-cols-5 gap-4 p-[1px]'>
                {Object.keys(colors.blue).map((key) => (
                    <ColorBox
                        key={key}
                        colorKey={key}
                        value={(colors.blue as { [k: string]: string })[key]}
                        onChange={onColorEdit('blue', parseInt(key))}
                    />
                ))}
            </div>
        </StudioPage>
    );
};
