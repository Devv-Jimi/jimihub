import React, { useState } from 'react';
import tw, { styled } from 'twin.macro';
import { ArrowLeftIcon, LightBulbIcon } from '@heroicons/react/24/solid';
import { Bars3Icon } from '@heroicons/react/20/solid';
import classNames from 'classnames';
import { Button } from '@/components/elements/button';
import { AnimatePresence, motion } from 'framer-motion';
import { NovaStudioContext } from '@/state/novaStudio';
import { useStoreActions } from 'easy-peasy';
import updateSettings from '@/api/novaStudio/updateSettings';

type Props = {
    children?: React.ReactNode;
};

const Navigation = styled.div`
    ${tw`flex flex-col flex-1 overflow-auto`};

    & > a {
        ${tw`flex gap-2 items-center w-full text-gray-200 px-8 py-3`};
        ${tw`transition-all duration-150`};

        &.active {
            ${tw`font-bold text-blue-50 bg-blue-700`};
        }

        &:hover:not(.active) {
            ${tw`bg-blue-700/50`};
        }

        & > svg {
            ${tw`w-6 h-6`};
        }
    }

    & > h3 {
        ${tw`mt-4 mb-2 px-8 text-gray-400 text-sm`};
    }
`;

const SidebarBody = (props: Props) => {
    const edited = NovaStudioContext.useStoreState((state) => state.edited);
    const setEdited = NovaStudioContext.useStoreActions((actions) => actions.setEdited);
    const editedData = NovaStudioContext.useStoreState((state) => state.editedData!);
    const setThemeData = useStoreActions((actions) => actions.themeData.setData);
    const [isLoading, setIsLoading] = useState(false);

    const onSavePressed = () => {
        setIsLoading(true);
        updateSettings(editedData)
            .then(() => {
                setThemeData(editedData);
                setEdited(false);
            })
            .catch(console.error)
            .then(() => setIsLoading(false));
    };

    return (
        <>
            <h1 className='text-2xl font-header font-bold text-neutral-200 hover:text-neutral-50 px-4 py-6 flex justify-center items-center'>
                <svg
                    className='size-[1.25em] mr-3'
                    width='32'
                    height='32'
                    viewBox='0 0 32 32'
                    fill='none'
                    xmlns='http://www.w3.org/2000/svg'
                >
                    <g clipPath='url(#clip0_23_93)'>
                        <path
                            fillRule='evenodd'
                            clipRule='evenodd'
                            d='M16 32C24.8366 32 32 24.8366 32 16C32 7.16344 24.8366 0 16 0C7.16344 0 0 7.16344 0 16C0 16.233 0.00497998 16.4648 0.0148393 16.6954C6.02846 12.5985 18.1846 8.76964 23.9999 13.1311C12.9494 14.2266 7.26524 21.977 4.37363 26.9922C7.29022 30.076 11.4204 32 16 32Z'
                            fill='rgb(var(--color-blue-400))'
                        />
                    </g>
                    <defs>
                        <clipPath id='clip0_23_93'>
                            <rect width='32' height='32' fill='white' />
                        </clipPath>
                    </defs>
                </svg>
                Nova Studio
            </h1>
            <Navigation>
                {props.children}
                <a href='https://github.com/itsvic-dev/Nova/issues/new/choose' target='_blank' rel='noreferrer'>
                    <LightBulbIcon />
                    Suggestions
                </a>
                <a href='/admin'>
                    <ArrowLeftIcon />
                    Back to Admin Panel
                </a>
            </Navigation>
            <div className='overflow-hidden'>
                <AnimatePresence>
                    {edited && (
                        <motion.div
                            initial={{
                                opacity: 0,
                                y: '100%',
                            }}
                            animate={{
                                opacity: 1,
                                y: 0,
                            }}
                            exit={{
                                opacity: 0,
                                y: '100%',
                            }}
                            className='py-6 flex justify-center items-center'
                        >
                            <Button disabled={isLoading} onClick={onSavePressed}>
                                Save changes
                            </Button>
                        </motion.div>
                    )}
                </AnimatePresence>
            </div>
        </>
    );
};

export default (props: Props) => {
    const [open, setOpen] = useState(false);
    return (
        <>
            <div className='hidden md:flex bg-gray-900 w-64 h-full min-h-screen max-h-screen flex-col'>
                <SidebarBody {...props} />
            </div>
            <button
                onClick={() => setOpen(true)}
                className='md:hidden fixed top-0 left-0 z-[49] bg-gray-900 p-3 rounded-br-md shadow'
            >
                <Bars3Icon className='w-5 h-5' />
            </button>
            <div
                className={classNames(
                    'fixed top-0 left-0 w-full h-full z-50 bg-black/50 backdrop-blur-lg',
                    'transition-all duration-300',
                    !open && 'opacity-0 pointer-events-none'
                )}
                onClick={(ev) =>
                    (ev.target === ev.currentTarget || (ev.target as Element).localName === 'a') && setOpen(false)
                }
            >
                <div
                    className={classNames(
                        'flex bg-gray-900 w-full max-w-[min(16rem,80vw)] h-full min-h-screen max-h-screen flex-col',
                        'transition-transform duration-300',
                        !open && '-translate-x-full'
                    )}
                >
                    <SidebarBody {...props} />
                </div>
            </div>
        </>
    );
};
