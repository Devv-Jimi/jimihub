import React, { useEffect } from 'react';
import FlashMessageRender from '@/components/FlashMessageRender';
import classNames from 'classnames';

export interface PageContentBlockProps {
    title?: string;
    className?: string;
    showFlashKey?: string;
}

const StudioPage: React.FC<PageContentBlockProps> = ({ title, showFlashKey, className, children }) => {
    useEffect(() => {
        if (title) {
            document.title = 'Nova Studio | ' + title;
        }
    }, [title]);

    return (
        <div className='overflow-auto flex flex-col h-full pr-2'>
            <div className={classNames(className, 'w-full flex-1')}>
                {showFlashKey && <FlashMessageRender byKey={showFlashKey} className='mb-4' />}
                {children}
            </div>
            <p className='mt-8 text-center text-neutral-500 text-xs'>
                <a
                    rel={'noopener nofollow noreferrer'}
                    href={'https://itsvic.dev'}
                    target={'_blank'}
                    className='no-underline text-neutral-500 hover:text-neutral-300'
                >
                    it&apos;s vic!
                </a>
                &nbsp;&copy; {new Date().getFullYear()}
            </p>
        </div>
    );
};

export default StudioPage;
