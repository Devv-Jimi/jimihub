import React from 'react';
import StudioPage from '@/components/novaStudio/StudioPage';
import { NovaStudioContext } from '@/state/novaStudio';
import Select from '@/components/elements/Select';
import { AlertType } from '@/state/themeData';
import Input from '@/components/elements/Input';
import { AnimatePresence, motion } from 'framer-motion';

export default () => {
    const alertData = NovaStudioContext.useStoreState((state) => state.editedData!.alert);
    const updateEditedData = NovaStudioContext.useStoreActions((actions) => actions.updateEditedData);

    return (
        <StudioPage title='Alerts'>
            <h1 className='text-3xl font-bold text-gray-50'>Alerts</h1>
            <p className='mt-1'>Leave a message on the dashboard.</p>

            <p className='mt-4 text-sm mb-1'>Type</p>
            <Select
                value={alertData.type}
                onChange={(e) =>
                    updateEditedData({
                        alert: {
                            type: e.currentTarget.value as AlertType,
                            message: alertData.message,
                        },
                    })
                }
            >
                <option value='none'>Disabled</option>
                <option value='info'>Information</option>
                <option value='success'>Success</option>
                <option value='warning'>Warning</option>
                <option value='danger'>Danger</option>
            </Select>

            <AnimatePresence>
                {alertData.type !== 'none' && (
                    <motion.div
                        className='mt-4'
                        initial={{ opacity: 0, y: '100%' }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: '100%' }}
                    >
                        <p className='text-sm mb-1'>Message</p>
                        <Input
                            type='text'
                            value={alertData.message}
                            onChange={(e) =>
                                updateEditedData({
                                    alert: {
                                        type: alertData.type,
                                        message: e.currentTarget.value,
                                    },
                                })
                            }
                        />
                        <p className='text-sm mt-1'>
                            You can enter Markdown here to make things **bolder** or *italic*.
                        </p>
                    </motion.div>
                )}
            </AnimatePresence>
        </StudioPage>
    );
};
