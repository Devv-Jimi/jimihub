import React from 'react';
import StudioPage from '@/components/novaStudio/StudioPage';
import { LayoutGroup, motion } from 'framer-motion';
import LinkField from '@/components/novaStudio/sidebar/LinkField';
import { NovaStudioContext } from '@/state/novaStudio';
import classNames from 'classnames';
import Input from '@/components/elements/Input';
import Switch from '@/components/elements/Switch';

type HeaderStyleButtonProps = {
    children?: React.ReactNode;
    title: string;
    active: boolean;
} & React.ButtonHTMLAttributes<HTMLButtonElement>;

const HeaderStyleButton = ({ title, active, children, ...props }: HeaderStyleButtonProps) => (
    <div className='flex flex-col'>
        <button
            aria-label={`Button for the ${title} header style` + (active ? ', active' : '')}
            {...props}
            className={classNames(
                'flex-1 w-full p-4 flex justify-center items-center gap-3 transition-colors duration-300 rounded-full',
                'border border-white/10',
                active ? 'bg-blue-500 text-blue-50' : 'bg-gray-700 text-gray-500 hover:text-gray-300'
            )}
        >
            {children}
        </button>
        <p className={classNames('mt-2 transition-all duration-300', active && 'text-gray-50 font-bold')}>{title}</p>
    </div>
);

export default () => {
    const headerStyle = NovaStudioContext.useStoreState((state) => state.editedData!.header);
    const icon = NovaStudioContext.useStoreState((state) => state.editedData!.icon);
    const wordmark = NovaStudioContext.useStoreState((state) => state.editedData!.wordmark);
    const sidebarBlurred = NovaStudioContext.useStoreState((state) => state.editedData!.sidebarBlurred);
    const updateEditedData = NovaStudioContext.useStoreActions((actions) => actions.updateEditedData);

    return (
        <StudioPage title='Sidebar'>
            <h1 className='text-3xl font-bold text-gray-50'>Sidebar</h1>
            <p className='mt-1'>A safe haven for links and more links.</p>

            <div className='mt-6'>
                <h2 className='text-xl font-bold text-gray-50 mb-2'>Header style</h2>

                <div className='grid grid-rows-3 gap-4'>
                    <HeaderStyleButton
                        title='Text only'
                        active={headerStyle === 'text'}
                        onClick={() => updateEditedData({ header: 'text' })}
                    >
                        <div className='bg-current rounded-full w-full max-w-16 h-2'></div>
                    </HeaderStyleButton>
                    <HeaderStyleButton
                        title='Text with icon'
                        active={headerStyle === 'icon'}
                        onClick={() => updateEditedData({ header: 'icon' })}
                    >
                        <div className='bg-current rounded-full w-4 h-4'></div>
                        <div className='bg-current rounded-full w-full max-w-16 h-2'></div>
                    </HeaderStyleButton>
                    <HeaderStyleButton
                        title='Wordmark'
                        active={headerStyle === 'wordmark'}
                        onClick={() => updateEditedData({ header: 'wordmark' })}
                    >
                        <div className='bg-current rounded-sm w-full max-w-24 h-4'></div>
                    </HeaderStyleButton>
                </div>

                {headerStyle === 'icon' && (
                    <motion.div
                        layout
                        initial={{ y: '-100%', opacity: 0 }}
                        animate={{ opacity: 1, y: 0 }}
                        className='mt-6'
                    >
                        <p className='text-sm mb-1'>Path to the icon image</p>
                        <Input
                            type='text'
                            value={icon}
                            onChange={(e) => updateEditedData({ icon: e.currentTarget.value })}
                        />
                        <p className='text-xs mt-1'>
                            This should be a PNG file inside of the &quot;public&quot; directory of the panel. It will
                            also be used as the icon shown by the browser.
                        </p>
                    </motion.div>
                )}

                {headerStyle === 'wordmark' && (
                    <motion.div
                        layout
                        initial={{ y: '-100%', opacity: 0 }}
                        animate={{ opacity: 1, y: 0 }}
                        className='mt-6'
                    >
                        <p className='text-sm mb-1'>Path to the wordmark image</p>
                        <Input
                            type='text'
                            value={wordmark}
                            onChange={(e) => updateEditedData({ wordmark: e.currentTarget.value })}
                        />
                        <p className='text-xs mt-1'>
                            This should be an image file inside of the &quot;public&quot; directory of the panel.
                        </p>
                    </motion.div>
                )}
            </div>

            <motion.div layout className='mt-12'>
                <h2 className='text-xl font-bold text-gray-50 mb-2'>Translucent sidebar</h2>
                <Switch
                    name='sidebarBlurred'
                    label='Translucent sidebar'
                    description='Use a translucent sidebar on desktop. Works best with backgrounds.'
                    defaultChecked={sidebarBlurred}
                    onChange={(e) => {
                        updateEditedData({ sidebarBlurred: e.currentTarget.checked });
                    }}
                />
            </motion.div>

            <motion.div layout className='mt-12'>
                <h2 className='text-xl font-bold text-gray-50 mb-2'>Custom links</h2>
                <div className='space-y-4'>
                    <LayoutGroup>
                        <LinkField type='support' />
                        <LinkField type='discord' />
                    </LayoutGroup>
                </div>
            </motion.div>
        </StudioPage>
    );
};
