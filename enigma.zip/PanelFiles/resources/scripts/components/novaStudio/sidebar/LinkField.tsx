import React from 'react';
import { NovaStudioContext } from '@/state/novaStudio';
import { motion } from 'framer-motion';
import Input from '@/components/elements/Input';
import { sidebarIcons } from '@/components/Sidebar';

const LinkField = ({ type }: { type: 'support' | 'discord' }) => {
    const links = NovaStudioContext.useStoreState((state) => state.editedData!.sidebarLinks);
    const updateEditedData = NovaStudioContext.useStoreActions((actions) => actions.updateEditedData);
    const Icon = sidebarIcons[type];

    return (
        <>
            <motion.div layout className='flex gap-2 w-full'>
                <div className='size-[38px] aspect-square flex justify-center items-center rounded bg-gray-700 border border-white/10'>
                    <Icon />
                </div>
                <Input
                    type='text'
                    placeholder='Link name'
                    value={links[type].name}
                    onChange={(e) =>
                        updateEditedData({
                            sidebarLinks: {
                                ...links,
                                [type]: {
                                    name: e.currentTarget.value,
                                    url: links[type].url,
                                },
                            },
                        })
                    }
                />
            </motion.div>
            {links[type].name !== '' && (
                <motion.div initial={{ y: '-100%', opacity: 0 }} animate={{ y: 0, opacity: 1 }} layout className='mt-2'>
                    <Input
                        type='text'
                        placeholder='Link URL'
                        value={links[type].url}
                        onChange={(e) =>
                            updateEditedData({
                                sidebarLinks: {
                                    ...links,
                                    [type]: {
                                        name: links[type].name,
                                        url: e.currentTarget.value,
                                    },
                                },
                            })
                        }
                    />
                </motion.div>
            )}
        </>
    );
};

export default LinkField;
