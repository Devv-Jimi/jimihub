import React, { useRef, useState } from 'react';
import Avatar from '@/components/Avatar';
import { Actions, useStoreActions, useStoreState } from 'easy-peasy';
import { CameraIcon } from '@heroicons/react/24/outline';
import classNames from 'classnames';
import Spinner from '@/components/elements/Spinner';
import http from '@/api/http';
import { ApplicationStore } from '@/state';

export default () => {
    const hash = useStoreState((state) => state.user.data!.avatarHash);
    const input = useRef<HTMLInputElement>(null);
    const [loading, setLoading] = useState(false);
    const { clearAndAddHttpError } = useStoreActions((actions: Actions<ApplicationStore>) => actions.flashes);
    const { updateUserData } = useStoreActions((actions: Actions<ApplicationStore>) => actions.user);

    const handleUpload = async () => {
        if (!input.current) return;

        setLoading(true);

        const file = input.current.files![0];

        const data = new FormData();
        data.append('_method', 'PUT'); // the laravel gets a bit quirky at night
        data.append('avatar', file, file.name);

        http.post('/api/client/account/avatar', data, { headers: { 'content-type': 'multipart/form-data' } })
            .then((resp) => {
                updateUserData({ avatarHash: resp.data.avatarHash });
            })
            .catch((error) => clearAndAddHttpError({ error, key: 'account:avatar' }))
            .then(() => setLoading(false));
    };

    return (
        <div className='flex items-center gap-5'>
            <input
                onChange={() => handleUpload()}
                type='file'
                name='avatar'
                className='hidden'
                ref={input}
                aria-hidden
                accept='image/png, image/jpeg, image/webp'
            />
            <button
                onClick={() => input.current?.click()}
                aria-label='Change your avatar'
                className='size-14 flex-none relative cursor-pointer'
            >
                <div
                    className={classNames(
                        'absolute flex items-center justify-center transition-opacity top-0 left-0 size-full bg-cover rounded-full',
                        !loading && 'opacity-0 hover:opacity-100'
                    )}
                    style={{
                        backgroundImage: 'radial-gradient(circle at center, rgb(0 0 0 / 50%), rgb(0 0 0 / 75%))',
                    }}
                >
                    {loading ? <Spinner size={Spinner.Size.ICON} /> : <CameraIcon className='size-6' />}
                </div>
                {hash ? (
                    <img className='size-14 rounded-full' src={`/storage/${hash}`} />
                ) : (
                    <Avatar.User size={14 * 4} />
                )}
            </button>
            {hash ? (
                <p>You already have an avatar set, but you&apos;re still able to change it.</p>
            ) : (
                <p>
                    <b>You currently don&apos;t have an avatar set.</b> Click on the avatar on the left to change it!
                </p>
            )}
        </div>
    );
};
