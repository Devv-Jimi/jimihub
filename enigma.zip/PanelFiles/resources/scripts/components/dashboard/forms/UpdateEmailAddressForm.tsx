import React from 'react';
import { Actions, State, useStoreActions, useStoreState } from 'easy-peasy';
import { Form, Formik, FormikHelpers } from 'formik';
import * as Yup from 'yup';
import SpinnerOverlay from '@/components/elements/SpinnerOverlay';
import Field from '@/components/elements/Field';
import { httpErrorToHuman } from '@/api/http';
import { ApplicationStore } from '@/state';
import tw from 'twin.macro';
import { Button } from '@/components/elements/button/index';

interface Values {
    firstName: string;
    lastName: string;
    username: string;
    email: string;
    password: string;
}

const schema = Yup.object().shape({
    firstName: Yup.string().required(),
    lastName: Yup.string().required(),
    username: Yup.string().required(),
    email: Yup.string().email().required(),
    password: Yup.string().required('You must provide your current account password.'),
});

export default () => {
    const user = useStoreState((state: State<ApplicationStore>) => state.user.data);
    const updateEmail = useStoreActions((state: Actions<ApplicationStore>) => state.user.updateUserEmail);

    const { clearFlashes, addFlash } = useStoreActions((actions: Actions<ApplicationStore>) => actions.flashes);

    const submit = (values: Values, { resetForm, setSubmitting }: FormikHelpers<Values>) => {
        clearFlashes('account:email');

        updateEmail({ ...values })
            .then(() =>
                addFlash({
                    type: 'success',
                    key: 'account:email',
                    message: 'Your account details have been updated.',
                })
            )
            .catch((error) =>
                addFlash({
                    type: 'error',
                    key: 'account:email',
                    title: 'Error',
                    message: httpErrorToHuman(error),
                })
            )
            .then(() => {
                resetForm();
                setSubmitting(false);
            });
    };

    return (
        <Formik
            onSubmit={submit}
            validationSchema={schema}
            initialValues={{
                firstName: user!.firstName,
                lastName: user!.lastName,
                username: user!.username,
                email: user!.email,
                password: '',
            }}
        >
            {({ isSubmitting, isValid }) => (
                <React.Fragment>
                    <SpinnerOverlay size={'large'} visible={isSubmitting} />
                    <Form css={tw`m-0`}>
                        <div className='grid grid-cols-2 gap-6'>
                            <Field
                                id={'firstName'}
                                type={'text'}
                                name={'firstName'}
                                label={'First Name'}
                                autoComplete='given-name'
                            />
                            <Field
                                id={'lastName'}
                                type={'text'}
                                name={'lastName'}
                                label={'Last Name'}
                                autoComplete='family-name'
                            />
                        </div>
                        <div className='mt-4'>
                            <Field
                                id={'username'}
                                autoComplete='username'
                                type={'text'}
                                name={'username'}
                                label={'Username'}
                            />
                        </div>
                        <div className='mt-4'>
                            <Field
                                id={'current_email'}
                                autoComplete='email'
                                type={'email'}
                                name={'email'}
                                label={'E-mail'}
                            />
                        </div>
                        <div className='mt-4'>
                            <Field
                                id={'confirm_password'}
                                autoComplete='current-password'
                                type={'password'}
                                name={'password'}
                                label={'Confirm Password'}
                            />
                        </div>
                        <div className='mt-4'>
                            <Button disabled={isSubmitting || !isValid}>Update Details</Button>
                        </div>
                    </Form>
                </React.Fragment>
            )}
        </Formik>
    );
};
