import getVersionData from '@/api/novaStudio/getVersionData';
import { Alert } from '@/components/elements/alert';
import React from 'react';
import { Link } from 'react-router-dom';
import { lt } from 'semver';
import useSWR from 'swr';

export default () => {
    const { data, isValidating } = useSWR('nova:versionData', getVersionData);

    if (isValidating || !data || data.error || !lt(data.current, data.latest)) {
        return null;
    }

    return (
        <Alert type='warning' className='mb-4'>
            <p>
                <b>Update available!</b> You are running Nova {data.current}, but {data.latest} is available! Find out
                more in{' '}
                <Link to='/admin/nova' className='text-yellow-400 font-medium hover:underline'>
                    Nova Studio
                </Link>
                .
            </p>
        </Alert>
    );
};
