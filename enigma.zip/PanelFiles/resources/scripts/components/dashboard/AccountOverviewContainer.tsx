import * as React from 'react';
import UpdatePasswordForm from '@/components/dashboard/forms/UpdatePasswordForm';
import UpdateEmailAddressForm from '@/components/dashboard/forms/UpdateEmailAddressForm';
import ConfigureTwoFactorForm from '@/components/dashboard/forms/ConfigureTwoFactorForm';
import PageContentBlock from '@/components/elements/PageContentBlock';
import { useLocation } from 'react-router-dom';
import { useStoreState } from 'easy-peasy';
import { ApplicationStore } from '@/state';
import { Alert } from '@/components/elements/alert';
import HeaderedContent from '@/components/elements/HeaderedContent';
import PageHeader from '@/components/elements/PageHeader';
import UpdateAvatarForm from '@/components/dashboard/forms/UpdateAvatarForm';

import BeforeContent from '@/blueprint/components/Account/Overview/BeforeContent';
import AfterContent from '@/blueprint/components/Account/Overview/AfterContent';

export default () => {
    const { state } = useLocation<undefined | { twoFactorRedirect?: boolean }>();
    const totpIsEnabled = useStoreState((state: ApplicationStore) => state.user.data!.useTotp);

    return (
        <PageContentBlock title={'Account Overview'} className='max-w-5xl mx-auto'>
            {state?.twoFactorRedirect && (
                <Alert type={'danger'}>
                    Your account must have two-factor authentication enabled in order to continue.
                </Alert>
            )}

            <PageHeader title='Account Overview' />

            {!totpIsEnabled && (
                <Alert className='mt-4' type='warning'>
                    <span>
                        <b>2-factor authentication is not enabled.</b> 2-factor authentication is important for your
                        account&apos;s safety.
                    </span>
                </Alert>
            )}

            <BeforeContent />

            <HeaderedContent
                title={'Avatar'}
                description='Give your profile a touch of personality.'
                showFlashes={'account:avatar'}
                className='mt-8'
            >
                <UpdateAvatarForm />
            </HeaderedContent>
            <HeaderedContent
                title={'Personal Information'}
                description='Update your name and e-mail information here. Use a permanent address where you can receive e-mail.'
                showFlashes={'account:email'}
            >
                <UpdateEmailAddressForm />
            </HeaderedContent>
            <HeaderedContent
                title={'Update Password'}
                description='Update the password associated with your account.'
                showFlashes={'account:password'}
            >
                <UpdatePasswordForm />
            </HeaderedContent>
            <HeaderedContent
                title={'Two-Step Verification'}
                description={
                    totpIsEnabled
                        ? 'Two-step verification is currently enabled on your account'
                        : 'You do not currently have two-step verification enabled on your account. Click the button below to begin configuring it.'
                }
            >
                <ConfigureTwoFactorForm />
            </HeaderedContent>

            <AfterContent />
        </PageContentBlock>
    );
};
