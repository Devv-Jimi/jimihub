import { Server } from '@/api/server/getServer';
import getServerResourceUsage, { ServerStats } from '@/api/server/getServerResourceUsage';
import Spinner from '@/components/elements/Spinner';
import { bytesToString, ip, mbToBytes } from '@/lib/formatters';
import { faMemory } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { CircleStackIcon, CpuChipIcon } from '@heroicons/react/20/solid';
import classNames from 'classnames';
import { motion } from 'framer-motion';
import React, { useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';

type Timer = ReturnType<typeof setInterval>;

const isAlarmState = (current: number, limit: number): boolean => limit > 0 && current / (limit * 1024 * 1024) >= 0.9;

const MotionLink = motion(Link);

const Limit = ({
    limit,
    children,
    icon,
    alarm,
}: {
    limit: string;
    children: React.ReactNode;
    icon: React.ReactNode;
    alarm: boolean;
}) => (
    <div className={classNames('flex gap-2 text-sm justify-center items-center', alarm && 'text-amber-400')}>
        {icon}
        <div>
            <span className='mr-1'>{children}</span>
            <span className='inline-block text-xs text-gray-400'>/ {limit}</span>
        </div>
    </div>
);

export default ({ server, i }: { server: Server; i: number }) => {
    const interval = useRef<Timer>(null) as React.MutableRefObject<Timer>;
    const [isSuspended, setIsSuspended] = useState(server.status === 'suspended');
    const [stats, setStats] = useState<ServerStats | null>(null);

    const getStats = () =>
        getServerResourceUsage(server.uuid)
            .then((data) => setStats(data))
            .catch((error) => console.error(error));

    useEffect(() => {
        setIsSuspended(stats?.isSuspended || server.status === 'suspended');
    }, [stats?.isSuspended, server.status]);

    useEffect(() => {
        // Don't waste a HTTP request if there is nothing important to show to the user because
        // the server is suspended.
        if (isSuspended) return;

        getStats().then(() => {
            interval.current = setInterval(() => getStats(), 30000);
        });

        return () => {
            interval.current && clearInterval(interval.current);
        };
    }, [isSuspended]);

    const alarms = { cpu: false, memory: false, disk: false };
    if (stats) {
        alarms.cpu = server.limits.cpu === 0 ? false : stats.cpuUsagePercent >= server.limits.cpu * 0.9;
        alarms.memory = isAlarmState(stats.memoryUsageInBytes, server.limits.memory);
        alarms.disk = server.limits.disk === 0 ? false : isAlarmState(stats.diskUsageInBytes, server.limits.disk);
    }

    const diskLimit = server.limits.disk !== 0 ? bytesToString(mbToBytes(server.limits.disk)) : '∞';
    const memoryLimit = server.limits.memory !== 0 ? bytesToString(mbToBytes(server.limits.memory)) : '∞';
    const cpuLimit = server.limits.cpu !== 0 ? server.limits.cpu + ' %' : '∞';

    return (
        <MotionLink
            initial={{
                opacity: 0,
                y: 50,
            }}
            animate={{
                opacity: 1,
                y: 0,
            }}
            transition={{
                type: 'spring',
                bounce: 0.5,
                delay: i * 0.1,
            }}
            to={`/server/${server.id}`}
            className='flex flex-col justify-between shadow-md bg-gray-700 rounded-md outline outline-2 outline-transparent hover:outline-gray-400 transition-color duration-100'
        >
            <div className='px-6 py-4'>
                <h3 className='text-xl font-header font-medium'>{server.name}</h3>
                <p className='text-sm text-gray-300'>
                    {server.allocations[0].alias || ip(server.allocations[0].ip)}:{server.allocations[0].port}
                </p>
            </div>
            <div
                className={classNames(
                    'rounded-b-md p-4 grid',
                    stats && 'gap-2 sm:grid-cols-3',
                    isSuspended ? 'bg-red-600/40 text-red-50' : 'bg-gray-800/50'
                )}
            >
                {!stats || isSuspended ? (
                    isSuspended ? (
                        <div className='font-medium text-center text-sm'>Suspended</div>
                    ) : server.isTransferring || server.status ? (
                        <div className='font-medium text-center text-sm'>
                            {server.isTransferring
                                ? 'Transferring...'
                                : server.status === 'installing'
                                ? 'Installing...'
                                : server.status === 'restoring_backup'
                                ? 'Restoring backup...'
                                : 'Unavailable'}
                        </div>
                    ) : (
                        <div className='flex justify-center'>
                            <Spinner />
                        </div>
                    )
                ) : (
                    <>
                        <Limit limit={cpuLimit} icon={<CpuChipIcon className='w-5 h-5 flex-none' />} alarm={alarms.cpu}>
                            {stats.cpuUsagePercent.toFixed(2)}%
                        </Limit>
                        <Limit
                            limit={memoryLimit}
                            icon={<FontAwesomeIcon width={20} icon={faMemory} className='flex-none' />}
                            alarm={alarms.memory}
                        >
                            {bytesToString(stats.memoryUsageInBytes)}
                        </Limit>
                        <Limit
                            limit={diskLimit}
                            icon={<CircleStackIcon className='w-5 h-5 flex-none' />}
                            alarm={alarms.disk}
                        >
                            {bytesToString(stats.diskUsageInBytes)}
                        </Limit>
                    </>
                )}
            </div>
        </MotionLink>
    );
};
