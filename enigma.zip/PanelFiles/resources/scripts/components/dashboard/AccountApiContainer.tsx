import React, { useEffect, useState } from 'react';
import CreateApiKeyForm from '@/components/dashboard/forms/CreateApiKeyForm';
import getApiKeys, { ApiKey } from '@/api/account/getApiKeys';
import SpinnerOverlay from '@/components/elements/SpinnerOverlay';
import deleteApiKey from '@/api/account/deleteApiKey';
import FlashMessageRender from '@/components/FlashMessageRender';
import { format } from 'date-fns';
import PageContentBlock from '@/components/elements/PageContentBlock';
import { Dialog } from '@/components/elements/dialog';
import { useFlashKey } from '@/plugins/useFlash';
import Code from '@/components/elements/Code';
import { KeyIcon } from '@heroicons/react/24/solid';
import { TrashIcon } from '@heroicons/react/20/solid';
import { Button } from '@/components/elements/button';
import PageHeader from '@/components/elements/PageHeader';
import classNames from 'classnames';

import BeforeContent from '@/blueprint/components/Account/API/BeforeContent';
import AfterContent from '@/blueprint/components/Account/API/AfterContent';

export default () => {
    const [deleteIdentifier, setDeleteIdentifier] = useState('');
    const [keys, setKeys] = useState<ApiKey[]>([]);
    const [loading, setLoading] = useState(true);
    const { clearAndAddHttpError } = useFlashKey('account');

    useEffect(() => {
        getApiKeys()
            .then((keys) => setKeys(keys))
            .then(() => setLoading(false))
            .catch((error) => clearAndAddHttpError(error));
    }, []);

    const doDeletion = (identifier: string) => {
        setLoading(true);

        clearAndAddHttpError();
        deleteApiKey(identifier)
            .then(() => setKeys((s) => [...(s || []).filter((key) => key.identifier !== identifier)]))
            .catch((error) => clearAndAddHttpError(error))
            .then(() => {
                setLoading(false);
                setDeleteIdentifier('');
            });
    };

    return (
        <PageContentBlock title={'Account API'} className='max-w-5xl mx-auto'>
            <PageHeader
                title='API Keys'
                className='mb-4'
                renderRight={<CreateApiKeyForm onKeyCreated={(key) => setKeys((s) => [...s!, key])} />}
            />
            <FlashMessageRender byKey={'account'} />
            <SpinnerOverlay visible={loading} />
            <Dialog.Confirm
                title={'Delete API Key'}
                confirm={'Delete Key'}
                open={!!deleteIdentifier}
                onClose={() => setDeleteIdentifier('')}
                onConfirmed={() => doDeletion(deleteIdentifier)}
            >
                All requests using the <Code>{deleteIdentifier}</Code> key will be invalidated.
            </Dialog.Confirm>
            <BeforeContent />
            {keys.length === 0 ? (
                <p>{loading ? 'Loading...' : 'No API keys exist for this account.'}</p>
            ) : (
                <div className='flex flex-col'>
                    {keys.map((key, index) => (
                        <div
                            key={key.identifier}
                            className={classNames(
                                'flex gap-4 items-center py-4',
                                index > 0 && 'border-t border-gray-700'
                            )}
                        >
                            <KeyIcon className='w-6 h-6' />
                            <div className='flex-1 overflow-hidden'>
                                <p className='font-header font-medium break-words'>{key.description}</p>
                                <p className='text-xs text-neutral-300'>
                                    Last used:&nbsp;
                                    {key.lastUsedAt ? format(key.lastUsedAt, 'MMM do, yyyy HH:mm') : 'Never'}
                                </p>
                            </div>
                            <p className='text-sm hidden md:block'>
                                <code className='font-mono py-1 px-2 bg-neutral-900 rounded'>{key.identifier}</code>
                            </p>
                            <Button.Text
                                size={Button.Sizes.Small}
                                shape={Button.Shapes.IconSquare}
                                onClick={() => setDeleteIdentifier(key.identifier)}
                            >
                                <TrashIcon className='w-5 h-5' />
                            </Button.Text>
                        </div>
                    ))}
                </div>
            )}
            <AfterContent />
        </PageContentBlock>
    );
};
