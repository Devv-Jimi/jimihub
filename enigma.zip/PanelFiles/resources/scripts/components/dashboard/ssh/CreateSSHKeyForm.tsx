import React, { useState } from 'react';
import { Field, Form, Formik, FormikHelpers } from 'formik';
import { object, string } from 'yup';
import FormikFieldWrapper from '@/components/elements/FormikFieldWrapper';
import SpinnerOverlay from '@/components/elements/SpinnerOverlay';
import tw from 'twin.macro';
import { Button } from '@/components/elements/button';
import Input, { Textarea } from '@/components/elements/Input';
import styled from 'styled-components/macro';
import { useFlashKey } from '@/plugins/useFlash';
import { createSSHKey, useSSHKeys } from '@/api/account/ssh-keys';
import { Dialog } from '@/components/elements/dialog';

interface Values {
    name: string;
    publicKey: string;
}

const CustomTextarea = styled(Textarea)`
    ${tw`h-32`}
`;

type CreateKeyModalProps = {
    submit: (values: Values, helpers: FormikHelpers<Values>) => void;
    open: boolean;
    onClose: () => void;
};

const CreateKeyModal = ({ submit, open, onClose }: CreateKeyModalProps) => {
    return (
        <Formik
            onSubmit={submit}
            initialValues={{ name: '', publicKey: '' }}
            validationSchema={object().shape({
                name: string().required(),
                publicKey: string().required(),
            })}
        >
            {({ isSubmitting, submitForm }) => (
                <Dialog title='Create a new SSH key' open={open} onClose={onClose}>
                    <Form>
                        <SpinnerOverlay visible={isSubmitting} />
                        <FormikFieldWrapper label={'SSH Key Name'} name={'name'} css={tw`mb-2`}>
                            <Field name={'name'} as={Input} />
                        </FormikFieldWrapper>
                        <FormikFieldWrapper
                            label={'Public Key'}
                            name={'publicKey'}
                            description={'Enter your public SSH key.'}
                        >
                            <Field name={'publicKey'} as={CustomTextarea} />
                        </FormikFieldWrapper>
                    </Form>
                    <Dialog.Footer>
                        <Button.Text onClick={onClose}>Cancel</Button.Text>
                        <Button onClick={() => submitForm()}>Create</Button>
                    </Dialog.Footer>
                </Dialog>
            )}
        </Formik>
    );
};

export default () => {
    const { clearAndAddHttpError } = useFlashKey('account');
    const { mutate } = useSSHKeys();
    const [open, setOpen] = useState(false);

    const submit = (values: Values, { setSubmitting, resetForm }: FormikHelpers<Values>) => {
        clearAndAddHttpError();

        createSSHKey(values.name, values.publicKey)
            .then((key) => {
                resetForm();
                mutate((data) => (data || []).concat(key));
            })
            .catch((error) => clearAndAddHttpError(error))
            .then(() => setSubmitting(false));
    };

    return (
        <>
            <CreateKeyModal open={open} onClose={() => setOpen(false)} submit={submit} />
            <Button onClick={() => setOpen(true)}>Create a new SSH key</Button>
        </>
    );
};
