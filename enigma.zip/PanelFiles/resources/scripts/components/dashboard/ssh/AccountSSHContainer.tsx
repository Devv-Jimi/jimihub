import React, { useEffect } from 'react';
import SpinnerOverlay from '@/components/elements/SpinnerOverlay';
import FlashMessageRender from '@/components/FlashMessageRender';
import PageContentBlock from '@/components/elements/PageContentBlock';
import { useSSHKeys } from '@/api/account/ssh-keys';
import { useFlashKey } from '@/plugins/useFlash';
import { format } from 'date-fns';
import CreateSSHKeyForm from '@/components/dashboard/ssh/CreateSSHKeyForm';
import DeleteSSHKeyButton from '@/components/dashboard/ssh/DeleteSSHKeyButton';
import { KeyIcon } from '@heroicons/react/24/solid';
import PageHeader from '@/components/elements/PageHeader';
import classNames from 'classnames';

import BeforeContent from '@/blueprint/components/Account/SSH/BeforeContent';
import AfterContent from '@/blueprint/components/Account/SSH/AfterContent';

export default () => {
    const { clearAndAddHttpError } = useFlashKey('account');
    const { data, isValidating, error } = useSSHKeys({
        revalidateOnMount: true,
        revalidateOnFocus: false,
    });

    useEffect(() => {
        clearAndAddHttpError(error);
    }, [error]);

    return (
        <PageContentBlock title={'SSH Keys'} className='max-w-5xl mx-auto'>
            <PageHeader title='SSH Keys' className='mb-4' renderRight={<CreateSSHKeyForm />} />
            <FlashMessageRender byKey={'account'} />
            <SpinnerOverlay visible={!data && isValidating} />
            <BeforeContent />
            {!data || !data.length ? (
                <p>{!data ? 'Loading...' : 'No SSH Keys exist for this account.'}</p>
            ) : (
                <div className='flex flex-col'>
                    {data.map((key, index) => (
                        <div
                            key={key.fingerprint}
                            className={classNames(
                                'flex gap-4 items-center py-4',
                                index > 0 && 'border-t border-gray-700'
                            )}
                        >
                            <KeyIcon className='w-6 h-6' />
                            <div className='flex-1'>
                                <p className='font-header break-words font-medium'>{key.name}</p>
                                <p className='text-xs mt-1 font-mono truncate'>SHA256:{key.fingerprint}</p>
                                <p className='text-xs mt-1 text-neutral-300'>
                                    Added on:&nbsp;
                                    {format(key.createdAt, 'MMM do, yyyy HH:mm')}
                                </p>
                            </div>
                            <DeleteSSHKeyButton name={key.name} fingerprint={key.fingerprint} />
                        </div>
                    ))}
                </div>
            )}
            <AfterContent />
        </PageContentBlock>
    );
};
