// This file is unused by Nova and has been stubbed out.
export default () => null;
