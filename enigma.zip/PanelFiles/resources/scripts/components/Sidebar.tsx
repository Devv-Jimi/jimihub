import { ApplicationStore } from '@/state';
import { useStoreState } from 'easy-peasy';
import React, { useState } from 'react';
import { Link, NavLink } from 'react-router-dom';
import tw, { styled } from 'twin.macro';
import { Cog6ToothIcon, EllipsisHorizontalIcon, LifebuoyIcon, ServerStackIcon } from '@heroicons/react/24/solid';
import { Bars3Icon } from '@heroicons/react/20/solid';
import Avatar from './Avatar';
import DropdownMenu from '@/components/elements/DropdownMenu';
import { ArrowRightStartOnRectangleIcon, UserCircleIcon } from '@heroicons/react/20/solid';
import DropdownItem from '@/components/elements/DropdownItem';
import SpinnerOverlay from '@/components/elements/SpinnerOverlay';
import http from '@/api/http';
import classNames from 'classnames';

type Props = {
    children?: React.ReactNode;
    blurred: boolean;
};

const Navigation = styled.div<{ blurred: boolean }>`
    ${tw`flex flex-col flex-1 overflow-auto`};

    & > a {
        ${tw`flex gap-2 items-center w-full text-gray-200 px-8 py-3`};
        ${tw`transition-all duration-150`};

        &.active {
            ${tw`font-bold text-blue-50`};
            ${(props) => (props.blurred ? tw`bg-blue-600/65` : tw`bg-blue-700`)};
        }

        &:hover:not(.active) {
            ${(props) => (props.blurred ? tw`bg-blue-700/30` : tw`bg-blue-700/50`)};
        }

        & > svg {
            ${tw`w-6 h-6`};
        }
    }

    & > h3 {
        ${tw`mt-4 mb-2 px-8 text-gray-400 text-sm`};
    }
`;

const DivThatMakesSureTheAvatarIsRound = styled.div`
    & > svg {
        ${tw`rounded-full`};
    }
`;

export const sidebarIcons = {
    support: () => <LifebuoyIcon className='size-6' />,
    discord: () => (
        <svg className='size-6' role='img' viewBox='0 0 24 24' xmlns='http://www.w3.org/2000/svg' fill='currentColor'>
            <title>Discord</title>
            <path d='M20.317 4.3698a19.7913 19.7913 0 00-4.8851-1.5152.0741.0741 0 00-.0785.0371c-.211.3753-.4447.8648-.6083 1.2495-1.8447-.2762-3.68-.2762-5.4868 0-.1636-.3933-.4058-.8742-.6177-1.2495a.077.077 0 00-.0785-.037 19.7363 19.7363 0 00-4.8852 1.515.0699.0699 0 00-.0321.0277C.5334 9.0458-.319 13.5799.0992 18.0578a.0824.0824 0 00.0312.0561c2.0528 1.5076 4.0413 2.4228 5.9929 3.0294a.0777.0777 0 00.0842-.0276c.4616-.6304.8731-1.2952 1.226-1.9942a.076.076 0 00-.0416-.1057c-.6528-.2476-1.2743-.5495-1.8722-.8923a.077.077 0 01-.0076-.1277c.1258-.0943.2517-.1923.3718-.2914a.0743.0743 0 01.0776-.0105c3.9278 1.7933 8.18 1.7933 12.0614 0a.0739.0739 0 01.0785.0095c.1202.099.246.1981.3728.2924a.077.077 0 01-.0066.1276 12.2986 12.2986 0 01-1.873.8914.0766.0766 0 00-.0407.1067c.3604.698.7719 1.3628 1.225 1.9932a.076.076 0 00.0842.0286c1.961-.6067 3.9495-1.5219 6.0023-3.0294a.077.077 0 00.0313-.0552c.5004-5.177-.8382-9.6739-3.5485-13.6604a.061.061 0 00-.0312-.0286zM8.02 15.3312c-1.1825 0-2.1569-1.0857-2.1569-2.419 0-1.3332.9555-2.4189 2.157-2.4189 1.2108 0 2.1757 1.0952 2.1568 2.419 0 1.3332-.9555 2.4189-2.1569 2.4189zm7.9748 0c-1.1825 0-2.1569-1.0857-2.1569-2.419 0-1.3332.9554-2.4189 2.1569-2.4189 1.2108 0 2.1757 1.0952 2.1568 2.419 0 1.3332-.946 2.4189-2.1568 2.4189Z' />
        </svg>
    ),
};

type CustomIcon = keyof typeof sidebarIcons;

const SidebarBody = (props: Props) => {
    const name = useStoreState((state: ApplicationStore) => state.settings.data!.name);
    const rootAdmin = useStoreState((state: ApplicationStore) => state.user.data!.rootAdmin);
    const firstName = useStoreState((state: ApplicationStore) => state.user.data!.firstName);
    const lastName = useStoreState((state: ApplicationStore) => state.user.data!.lastName);
    const avatarHash = useStoreState((state: ApplicationStore) => state.user.data!.avatarHash);
    const sidebarLinks = useStoreState((state: ApplicationStore) => state.themeData.data!.sidebarLinks);
    const headerStyle = useStoreState((state: ApplicationStore) => state.themeData.data!.header);
    const icon = useStoreState((state: ApplicationStore) => state.themeData.data!.icon);
    const wordmark = useStoreState((state: ApplicationStore) => state.themeData.data!.wordmark);

    const [isLoggingOut, setIsLoggingOut] = useState(false);

    const onTriggerLogout = () => {
        setIsLoggingOut(true);
        http.post('/auth/logout').finally(() => {
            // @ts-expect-error this is valid
            window.location = '/';
        });
    };

    return (
        <>
            <SpinnerOverlay visible={isLoggingOut} />
            <Link
                to='/'
                className='text-2xl font-header font-bold text-neutral-200 hover:text-neutral-50 px-4 py-6 flex justify-center items-center'
            >
                {headerStyle === 'text' && <>{name}</>}
                {headerStyle === 'icon' && (
                    <>
                        <img src={icon} className='size-[1.25em] mr-3' />
                        {name}
                    </>
                )}
                {headerStyle === 'wordmark' && (
                    <>
                        <img src={wordmark} alt={name} className='max-w-full max-h-[1.5em]' />
                    </>
                )}
            </Link>
            <Navigation blurred={props.blurred}>
                <NavLink to='/' exact>
                    <ServerStackIcon />
                    Dashboard
                </NavLink>
                {['support', 'discord']
                    .filter((item) => !!sidebarLinks[item as CustomIcon].name)
                    .map((item) => (
                        <a key={item} href={sidebarLinks[item as CustomIcon].url} target='_blank' rel='noreferrer'>
                            {
                                sidebarIcons[
                                    item as CustomIcon
                                ]() /* this is probably cursed and illegal but it should work */
                            }
                            {sidebarLinks[item as CustomIcon].name}
                        </a>
                    ))}
                {rootAdmin && (
                    <a href='/admin'>
                        <Cog6ToothIcon />
                        Administration
                    </a>
                )}
                {props.children}
            </Navigation>
            <DivThatMakesSureTheAvatarIsRound className='flex gap-3 p-4 items-center'>
                {avatarHash ? (
                    <img src={`/storage/${avatarHash}`} className='size-8 rounded-full' />
                ) : (
                    <Avatar.User size={8 * 4} />
                )}
                <span className='flex-1 font-medium'>
                    {firstName} {lastName}
                </span>
                <div className='w-6 h-6'>
                    <DropdownMenu
                        renderToggle={(onClick) => (
                            <button onClick={onClick} className='w-6 h-6'>
                                <EllipsisHorizontalIcon className='w-6 h-6' />
                            </button>
                        )}
                    >
                        <Link to='/account' className='w-full block'>
                            <DropdownItem>
                                <UserCircleIcon />
                                Account Settings
                            </DropdownItem>
                        </Link>
                        <button onClick={onTriggerLogout} className='w-full block'>
                            <DropdownItem>
                                <ArrowRightStartOnRectangleIcon />
                                Sign Out
                            </DropdownItem>
                        </button>
                    </DropdownMenu>
                </div>
            </DivThatMakesSureTheAvatarIsRound>
        </>
    );
};

export default (props: Omit<Props, 'blurred'>) => {
    const [open, setOpen] = useState(false);
    const sidebarBlurred = useStoreState((state) => state.themeData.data!.sidebarBlurred);

    return (
        <>
            <div
                className={classNames(
                    'hidden md:flex w-64 h-full min-h-screen max-h-screen flex-col',
                    sidebarBlurred ? 'backdrop-blur-lg bg-gray-900/60' : 'bg-gray-900'
                )}
            >
                <SidebarBody blurred={sidebarBlurred} {...props} />
            </div>
            <button
                onClick={() => setOpen(true)}
                className='md:hidden fixed top-0 left-0 z-[49] bg-gray-900 p-3 rounded-br-md shadow'
            >
                <Bars3Icon className='w-5 h-5' />
            </button>
            <div
                className={classNames(
                    'fixed top-0 left-0 w-full h-full z-50 bg-black/50 backdrop-blur-lg',
                    'transition-all duration-300',
                    !open && 'opacity-0 pointer-events-none'
                )}
                onClick={(ev) =>
                    (ev.target === ev.currentTarget || (ev.target as Element).localName === 'a') && setOpen(false)
                }
            >
                <div
                    className={classNames(
                        'flex bg-gray-900 w-full max-w-[min(16rem,80vw)] h-full min-h-screen max-h-screen flex-col',
                        'transition-transform duration-300',
                        !open && '-translate-x-full'
                    )}
                >
                    <SidebarBody blurred={false} {...props} />
                </div>
            </div>
        </>
    );
};
