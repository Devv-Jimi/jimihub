import React, { useState } from 'react';
import { RouteComponentProps } from 'react-router';
import { Link } from 'react-router-dom';
import performPasswordReset from '@/api/auth/performPasswordReset';
import { httpErrorToHuman } from '@/api/http';
import LoginFormContainer from '@/components/auth/LoginFormContainer';
import { Actions, useStoreActions } from 'easy-peasy';
import { ApplicationStore } from '@/state';
import { Formik, FormikHelpers } from 'formik';
import { object, ref, string } from 'yup';
import Field from '@/components/elements/Field';
import Input from '@/components/elements/Input';
import { Button } from '@/components/elements/button';
import Label from '@/components/elements/Label';

interface Values {
    password: string;
    passwordConfirmation: string;
}

export default ({ match, location }: RouteComponentProps<{ token: string }>) => {
    const [email, setEmail] = useState('');

    const { clearFlashes, addFlash } = useStoreActions((actions: Actions<ApplicationStore>) => actions.flashes);

    const parsed = new URLSearchParams(location.search);
    if (email.length === 0 && parsed.get('email')) {
        setEmail(parsed.get('email') || '');
    }

    const submit = ({ password, passwordConfirmation }: Values, { setSubmitting }: FormikHelpers<Values>) => {
        clearFlashes();
        performPasswordReset(email, { token: match.params.token, password, passwordConfirmation })
            .then(() => {
                // @ts-expect-error this is valid
                window.location = '/';
            })
            .catch((error) => {
                console.error(error);

                setSubmitting(false);
                addFlash({ type: 'error', title: 'Error', message: httpErrorToHuman(error) });
            });
    };

    return (
        <Formik
            onSubmit={submit}
            initialValues={{
                password: '',
                passwordConfirmation: '',
            }}
            validationSchema={object().shape({
                password: string()
                    .required('A new password is required.')
                    .min(8, 'Your new password should be at least 8 characters in length.'),
                passwordConfirmation: string()
                    .required('Your new password does not match.')
                    // @ts-expect-error this is valid
                    .oneOf([ref('password'), null], 'Your new password does not match.'),
            })}
        >
            {({ isSubmitting, submitForm }) => (
                <LoginFormContainer title={'Reset your password.'}>
                    <div>
                        <Label>E-mail</Label>
                        <Input value={email} disabled />
                    </div>
                    <Field
                        label={'New password'}
                        name={'password'}
                        type={'password'}
                        description={'Passwords must be at least 8 characters in length.'}
                    />
                    <Field label={'Confirm new password'} name={'passwordConfirmation'} type={'password'} />
                    <div className='mt-2 flex flex-col gap-4 items-center'>
                        <Button onClick={() => submitForm()} disabled={isSubmitting}>
                            Reset password
                        </Button>
                        <Link to={'/auth/login'}>
                            <Button.Text variant={Button.Variants.Secondary}>Nevermind, sign me in</Button.Text>
                        </Link>
                    </div>
                </LoginFormContainer>
            )}
        </Formik>
    );
};
