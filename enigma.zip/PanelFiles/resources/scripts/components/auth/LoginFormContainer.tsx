import React, { forwardRef } from 'react';
import { Form } from 'formik';
import FlashMessageRender from '@/components/FlashMessageRender';
import { useStoreState } from 'easy-peasy';

import BeforeContent from '@/blueprint/components/Authentication/Container/BeforeContent';
import AfterContent from '@/blueprint/components/Authentication/Container/AfterContent';

type Props = React.DetailedHTMLProps<React.FormHTMLAttributes<HTMLFormElement>, HTMLFormElement> & {
    title?: string;
};

export default forwardRef<HTMLFormElement, Props>(({ title, ...props }, ref) => (
    <div className='bg-gray-800 max-w-lg mx-auto px-4 py-16 flex items-center min-h-screen'>
        <div className='w-full'>
            <h1 className='text-4xl font-bold text-gray-50'>{useStoreState((state) => state.settings.data!.name)}</h1>
            {title && <h2 className='text-2xl mt-2 font-bold text-gray-300'>{title}</h2>}
            <FlashMessageRender className='mt-4 px-1' />
            <BeforeContent />
            <Form {...props} ref={ref}>
                <div className='w-full mt-6 flex flex-col gap-4'>{props.children}</div>
            </Form>
            <AfterContent />
            <p className='text-center text-gray-500 text-xs mt-8'>
                &copy; 2015 - {new Date().getFullYear()}&nbsp;
                <a
                    rel={'noopener nofollow noreferrer'}
                    href={'https://pterodactyl.io'}
                    target={'_blank'}
                    className='no-underline hover:text-gray-300'
                >
                    Pterodactyl Software
                </a>
            </p>
        </div>
    </div>
));
