import { ServerContext } from '@/state/server';
import isEqual from 'react-fast-compare';

export type Condition = () => boolean;

/**
 * Evaluates a condition, if present, otherwise assumes the condition is true.
 *
 * @internal
 */
export const evalCondition = (condition?: Condition) => (condition !== undefined ? condition() : true);

/**
 * Returns true if the server uses one of the provided eggs.
 */
export const isEgg: (...eggs: number[]) => Condition =
    (...eggs) =>
    () => {
        const eggId = ServerContext.useStoreState((state) => state.server.data?.eggId);
        return !eggId ? false : eggs.includes(eggId);
    };

/**
 * Returns true if the server uses one of the provided nests.
 */
export const isNest: (...nests: number[]) => Condition =
    (...nests) =>
    () => {
        const nestId = ServerContext.useStoreState((state) => state.server.data?.nestId);
        return !nestId ? false : nests.includes(nestId);
    };

/**
 * Returns true if the server's egg has one of the provided features.
 */
export const hasFeature: (...features: string[]) => Condition =
    (...features) =>
    () => {
        const currentFeatures = ServerContext.useStoreState((state) => state.server.data?.eggFeatures, isEqual);
        return !currentFeatures ? false : features.some((feature) => currentFeatures.includes(feature));
    };

/**
 * Performs a boolean AND operation on the provided conditions.
 *
 * Example:
 * ```ts
 * if (isEgg(12) && isNest(2)) { ... }
 * // Becomes...
 * and(isEgg(12), isNest(2))
 * ```
 */
export const and: (...conditions: Condition[]) => Condition =
    (...conditions) =>
    () =>
        conditions.map((c) => c()).every(Boolean);

/**
 * Performs a boolean OR operation on the provided conditions.
 *
 * Example:
 * ```ts
 * if (isEgg(12) || isNest(2)) { ... }
 * // Becomes...
 * or(isEgg(12), isNest(2))
 * ```
 */
export const or: (...conditions: Condition[]) => Condition =
    (...conditions) =>
    () =>
        conditions.map((c) => c()).some(Boolean);

/**
 * Negates the provided condition.
 *
 * Example:
 * ```ts
 * if (!isEgg(12)) { ... }
 * // Becomes...
 * not(isEgg(12))
 * ```
 */
export const not: (condition: Condition) => Condition = (condition) => () => !condition();
