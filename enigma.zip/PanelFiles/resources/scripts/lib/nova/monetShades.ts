import { camToInt, intToRgb, linearized, rgbToInt } from '@/lib/nova/cam';

const MIDDLE_LSTAR = 49.6;

const of = (hue: number, chroma: number): number[] => {
    const shades: number[] = [];

    shades[0] = camToInt(hue, Math.min(40, chroma), 99);
    shades[1] = camToInt(hue, Math.min(40, chroma), 99);

    for (let i = 2; i < 12; i++) {
        const lStar = i === 6 ? MIDDLE_LSTAR : 100 - 10 * (i - 1);
        shades[i] = camToInt(hue, chroma, lStar);
    }

    return shades;
};

export const getHueFromRgb = (r: number, g: number, b: number) => {
    const cmin = Math.min(r, g, b),
        cmax = Math.max(r, g, b),
        delta = cmax - cmin;

    let h = 0;

    if (delta === 0) return 0;
    else if (cmax === r) {
        h = ((g - b) / delta) % 6;
    } else if (cmax === g) {
        h = (b - r) / delta + 2;
    } else {
        h = (r - g) / delta + 4;
    }

    h = Math.round(h * 60);
    if (h < 0) h += 360;

    return h;
};

const getHue = (rgb: number) => getHueFromRgb(...(intToRgb(rgb).map(linearized) as [number, number, number]));

export const hexToRgb = (hex: string): [number, number, number] => {
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    if (!result) throw new Error('Invalid hex string provided.');
    return [parseInt(result[1], 16), parseInt(result[2], 16), parseInt(result[3], 16)];
};

export const hexToInt = (hex: string) => rgbToInt(...hexToRgb(hex));
export const intToHex = (rgb: number) => `#${rgb.toString(16).padStart(6, '0')}`;

export const getShades = (rgb: number, chroma = 4) => of(getHue(rgb), chroma).map(intToHex);
