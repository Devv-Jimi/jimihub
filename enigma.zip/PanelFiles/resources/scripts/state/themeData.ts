import { Action, action } from 'easy-peasy';

export type Colors = {
    '50': string;
    '100': string;
    '200': string;
    '300': string;
    '400': string;
    '500': string;
    '600': string;
    '700': string;
    '800': string;
    '900': string;
};

export type AlertType = 'none' | 'warning' | 'danger' | 'success' | 'info';

type SidebarLink = {
    name: string;
    url: string;
};

export interface ThemeData {
    colors: {
        gray: Colors;
        blue: Colors;
    };
    poweredFooter: boolean;
    alert: {
        type: AlertType;
        message: string;
    };
    sidebarLinks: {
        support: SidebarLink;
        discord: SidebarLink;
    };
    sidebarBlurred: boolean;
    header: 'text' | 'icon' | 'wordmark';
    icon: string;
    wordmark: string;
    backgroundStyle: 'simple' | 'fade';
    backgrounds: {
        global?: string;
        [eggId: number]: string | undefined;
    };
}

export type RawThemeData = Omit<ThemeData, 'backgrounds'> & { backgrounds: string };

export const fromRawTheme = (data: RawThemeData): ThemeData => ({ ...data, backgrounds: JSON.parse(data.backgrounds) });

export const toRawTheme = (data: ThemeData): RawThemeData => ({
    ...data,
    backgrounds: JSON.stringify(data.backgrounds),
});

export interface ThemeDataStore {
    data?: ThemeData;
    setData: Action<ThemeDataStore, ThemeData>;
    updateData: Action<ThemeDataStore, Partial<ThemeData>>;
}

const themeData: ThemeDataStore = {
    data: undefined,

    setData: action((state, payload) => {
        state.data = payload;
    }),

    updateData: action((state, payload) => {
        // @ts-expect-error limitation of Typescript, can't do much about that currently unfortunately.
        state.data = { ...state.data, ...payload };
    }),
};

export default themeData;
