import { ThemeData } from '@/state/themeData';
import { Action, action, createContextStore } from 'easy-peasy';

export interface NovaStudioStore {
    edited: boolean;
    setEdited: Action<NovaStudioStore, boolean>;

    editedData?: ThemeData;
    setEditedData: Action<NovaStudioStore, ThemeData>;
    updateEditedData: Action<NovaStudioStore, Partial<ThemeData>>;

    iframePath: string;
    setIframePath: Action<NovaStudioStore, string>;
}

export const NovaStudioContext = createContextStore<NovaStudioStore>({
    edited: false,
    setEdited: action((state, payload) => {
        state.edited = payload;
    }),

    editedData: undefined,
    setEditedData: action((state, payload) => {
        state.edited = true;
        state.editedData = payload;
    }),
    updateEditedData: action((state, payload) => {
        state.edited = true;
        // @ts-expect-error limitation of Typescript, can't do much about that currently unfortunately.
        state.editedData = { ...state.editedData, ...payload };
    }),

    iframePath: '/',
    setIframePath: action((state, payload) => {
        state.iframePath = payload;
    }),
});
