<div style="width: 20px; display: inline-block; vertical-align: text-top">
    <svg width="14" height="14" viewBox="0 0 32 32" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
        <path fill-rule="evenodd" clip-rule="evenodd" d="M16 32C24.8366 32 32 24.8366 32 16C32 7.16344 24.8366 0 16 0C7.16344 0 0 7.16344 0 16C0 16.233 0.00497998 16.4648 0.0148393 16.6954C6.02846 12.5985 18.1846 8.76964 23.9999 13.1311C12.9494 14.2266 7.26524 21.977 4.37363 26.9922C7.29022 30.076 11.4204 32 16 32Z"/>
    </svg>
</div>
