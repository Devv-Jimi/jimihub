@include('blueprint.dashboard.dashboard')
@yield('blueprint.lib')

<!DOCTYPE html>
<html>
    <head>
        <title>{{ config('app.name', 'Pterodactyl') }}</title>

        @section('meta')
            <meta charset="utf-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
            <meta name="csrf-token" content="{{ csrf_token() }}">
            <meta name="robots" content="noindex">
            <link rel="icon" type="image/png" href="{{ config('nova.icon') }}">
            <meta name="theme-color" content="{{ config('nova.colors.gray.800') }}">
        @show

        @section('user-data')
            @if(!is_null(Auth::user()))
                <script>
                    window.PterodactylUser = {!! json_encode(Auth::user()->toVueObject()) !!};
                </script>
            @endif
            @if(!empty($siteConfiguration))
                <script>
                    window.SiteConfiguration = {!! json_encode($siteConfiguration) !!};
                </script>
            @endif
            <script>
                window.NovaConfig = {!! json_encode(config('nova')) !!};
            </script>
        @show
        <style>
            @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap');
            @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600&display=swap');
            @import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;700&display=swap');

            :root {
                --color-gray-50: {{ hex_to_rgb(config('nova.colors.gray.50')) }};
                --color-gray-100: {{ hex_to_rgb(config('nova.colors.gray.100')) }};
                --color-gray-200: {{ hex_to_rgb(config('nova.colors.gray.200')) }};
                --color-gray-300: {{ hex_to_rgb(config('nova.colors.gray.300')) }};
                --color-gray-400: {{ hex_to_rgb(config('nova.colors.gray.400')) }};
                --color-gray-500: {{ hex_to_rgb(config('nova.colors.gray.500')) }};
                --color-gray-600: {{ hex_to_rgb(config('nova.colors.gray.600')) }};
                --color-gray-700: {{ hex_to_rgb(config('nova.colors.gray.700')) }};
                --color-gray-800: {{ hex_to_rgb(config('nova.colors.gray.800')) }};
                --color-gray-900: {{ hex_to_rgb(config('nova.colors.gray.900')) }};

                --color-blue-50: {{ hex_to_rgb(config('nova.colors.blue.50')) }};
                --color-blue-100: {{ hex_to_rgb(config('nova.colors.blue.100')) }};
                --color-blue-200: {{ hex_to_rgb(config('nova.colors.blue.200')) }};
                --color-blue-300: {{ hex_to_rgb(config('nova.colors.blue.300')) }};
                --color-blue-400: {{ hex_to_rgb(config('nova.colors.blue.400')) }};
                --color-blue-500: {{ hex_to_rgb(config('nova.colors.blue.500')) }};
                --color-blue-600: {{ hex_to_rgb(config('nova.colors.blue.600')) }};
                --color-blue-700: {{ hex_to_rgb(config('nova.colors.blue.700')) }};
                --color-blue-800: {{ hex_to_rgb(config('nova.colors.blue.800')) }};
                --color-blue-900: {{ hex_to_rgb(config('nova.colors.blue.900')) }};
            }
        </style>

        @yield('assets')

        @include('layouts.scripts')
    </head>
    <body class="{{ $css['body'] ?? 'bg-neutral-50' }}">
        @section('content')
            @yield('above-container')
            @yield('container')
            @yield('below-container')

            @yield('blueprint.wrappers')
        @show
        @section('scripts')
            {!! $asset->js('main.js') !!}
        @show
    </body>
</html>
