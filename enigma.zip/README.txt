Thank you for purchasing the Nova theme!

For installation instructions, please view the online documentation:
https://getnova.zip/docs

Support is done through Discord: https://discord.gg/CkYF9Jm8rB

Copyright © it's vic! 2024
